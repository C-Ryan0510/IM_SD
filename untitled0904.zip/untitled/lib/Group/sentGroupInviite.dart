import 'package:flutter/material.dart';

import 'package:email_validator/email_validator.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class GroupInvitation extends StatefulWidget {
  const GroupInvitation({Key? key}) : super(key: key);

  @override
  State<GroupInvitation> createState() => _GroupInvitationState();
}

class _GroupInvitationState extends State<GroupInvitation> {
  TextEditingController _FriendMail = TextEditingController();
  final userID = FirebaseAuth.instance.currentUser!.email.toString();
  final authPath = FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser?.email.toString());

  Future<UserData?> getCurrentUserName() async {
    final snapshot = await authPath.get();

    if (snapshot.exists) {
      return UserData.fromJson(snapshot.data()!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pinkAccent.withOpacity(0.93),
      body: FutureBuilder<UserData?>(
        future: getCurrentUserName(),
        builder: (context, snapshot) {
          if(snapshot.hasError) {
            return Center(child: Text('Something went wrong!'),);
          } else if (snapshot.hasData) {
            final data = snapshot.data;

            return Stack(
              children: [
                Center(
                  child: Padding(
                    padding: EdgeInsets.all(15),
                    child: Container(width: double.infinity, height: 200, //color: Colors.grey,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        boxShadow: [BoxShadow(
                            color: Colors.black38,
                            offset: Offset(6.0, 6.0), //陰影y軸偏移量
                            blurRadius: 0, //陰影模糊程度
                            spreadRadius: 0 //陰影擴散程度
                        )],
                        borderRadius: BorderRadius.circular(18),
                        color: Colors.white, //
                      ),
                      child: Column(
                        children: [
                          Spacer(),
                          Padding(padding: EdgeInsets.all(20),
                            child: Container(
                              child: Column(
                                children: [
                                  TextFormField(
                                    controller: _FriendMail,
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(Icons.email),
                                      hintText: '請輸入對方信箱',
                                    ),
                                    autovalidateMode: AutovalidateMode.onUserInteraction,
                                    validator:(email)=>email!=null&&!EmailValidator.validate(email)?
                                    '該電子郵件地址為無效郵件':null,
                                  ),
                                  SizedBox(height: 15,),
                                  RaisedButton(
                                    color: Colors.pink[200],
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 50,),
                                      child: Text('Send Invitation',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20,
                                        ),
                                      ),
                                    ),
                                    onPressed: () {
                                      sendMail(data?.name,data?.groupID);
                                      // Navigator.pop(context);
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 40),
                  child: IconButton( //To put it on top of ListView so it can be onPressed
                    alignment: Alignment.bottomCenter,
                    icon: Icon(
                      Icons.arrow_back_ios_new, color: Colors.black, size: 40,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            );
          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }

  Future sendMail(String? name, String? targetID) async {
    final Email email = Email(
      body: '$name邀請您一起加入【Take care】的家庭。\n'
            '在家庭頁輸入[$targetID]，即可開始體驗我【Take care】的體驗',
      subject: '【Take care】誠摯地邀請您',
      recipients: [_FriendMail.text.trim()],
      isHTML: false,
    );
    String platformResponse;

    try {
      await FlutterEmailSender.send(email);
      platformResponse = 'success';

      await Future.delayed(Duration(seconds: 1));
      showDialog(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: Text('成功寄出邀請',),
          actions: [
            FlatButton(child: Text('確定'),
              onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
            ),
          ],
          elevation: 24,
        ),
        barrierDismissible: false, // tap outside of it to dismiss
      );
    } catch (e) {
      print(e);
      platformResponse = e.toString();
    }
    if (!mounted) return;
    // ScaffoldMessenger.of(context).showSnackBar(
    //   SnackBar(
    //     content: Text(platformResponse),
    //   ),
    // );
  }
}

class UserData {
  String? name;
  String? ID;
  String? groupID;

  UserData({
    required this.name,
    required this.ID,
    required this.groupID,
  });

  static UserData fromJson(Map<String, dynamic> json) => UserData(
    name: json['user_name'],
    ID: json['user_ID/account'],
    groupID: json['group_id'],
  );
}