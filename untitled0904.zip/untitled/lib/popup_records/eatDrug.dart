import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
// import 'package:health/health.dart';


class Drug extends StatefulWidget {
  const Drug ({Key? key}) : super(key: key);

  @override
  State<Drug> createState() => _DrugState();
}

// DocumentSnapshot snapshot; //Define snapshot

class _DrugState extends State<Drug> {

  final ThisTypeCollection = FirebaseFirestore.instance
      .collection('Health').doc('Record_types')
      .collection('InsulinTypes');

  // DocumentSnapshot snapshot; //Define snapshot
  final decro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.circular(50),);
  final Errordecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.circular(50),);
  final UPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final ErrorUPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final DWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);
  final ErrorDWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);

  String DateNow = DateFormat('yyyy-MM-dd – kk:mm').format(DateTime.now());

  String YEAR = DateTime.now().year.toString();
  String MONTH = DateTime.now().month.toString();
  String DAY = DateTime.now().day.toString();

  final Period = ['BeforeMeal', 'AfterMeal', 'Anytime','As_prescription'];

  // default test
  final DrugTypes = ['Prescription', 'Over-the-Counter', 'Injection', 'Traditional-Chinese'];

  TextEditingController Name = TextEditingController();
  TextEditingController DrugValue = TextEditingController();

  var _curPeriod;
  var _curType;

  // read Firestore Database
  Future createRecord({required String Time,required String Period,required String Drug,required String DrugType,required String DrugName,required String Year,required String Month,required String Day,}) async {
    final doc = FirebaseFirestore.instance.collection('Health').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .collection('Records');

    final data = DrugData(
      created: Time,
      year: Year,
      month: Month,
      day: Day,

      key_value: '$Drug pill(s)',
      Type: 'DrugRecord',
      name: DrugName,
      special: '[$Period] - $DrugType',
    );

    final json = data.toJson();
    await doc.add(json);
  }

  // stream<list<class>> function[stream]
  // read DOCs and make it to List
  Stream<List<DrugData>> readDrug(String category, String clas) =>
      ThisTypeCollection
          .snapshots()
          .map((snapshot) =>
          snapshot.docs.map((doc) =>
              DrugData.fromJson(doc.data())).toList()
      );
  // // read DOC w specify ID
  Future<DrugData?> DrugandInsulinDetail() async {
    final Detail = ThisTypeCollection.doc('test');
    final snapshot = await Detail.get();

    if (snapshot.exists) {
      return DrugData.fromJson(snapshot.data()!);
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.transparent,
      body: StreamBuilder (
        stream: ThisTypeCollection.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong! ${snapshot}');
          } else if (snapshot.hasData) {
            final detail = snapshot.data;

            return detail == null ?
            Center(child: Text('NoData'),) :
            Container(//border
              height: 500,
              decoration: BoxDecoration(
                border: Border.all(width:2.5,color: Color.fromRGBO(48, 92, 84, 100),),
                borderRadius: BorderRadius.only(topRight: Radius.circular(40),topLeft: Radius.circular(40),),
              ),
              child: Stack(
                children: [
                  //title for this record widget
                  Positioned(child: Text('用藥紀錄',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),top: 10,left: 18,),
                  Positioned(child: Text('紀錄時間',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 40,left: 20,),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                    child: ListView(
                      physics: NeverScrollableScrollPhysics(),
                      // mainAxisAlignment: MainAxisAlignment.end,
                      padding: EdgeInsets.only(top: 63),
                      children: [
                        TextFormField(enabled: false,
                          initialValue: DateNow,
                          decoration: InputDecoration(
                            enabledBorder: UPdecro,
                            disabledBorder: UPdecro,
                            prefixIcon  : Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: IconButton(
                                icon: Icon(Icons.date_range_rounded,color: Colors.black,),
                                color: Colors.black,
                                onPressed: null,
                              ),
                            ),
                          ),
                        ),
                        FormField<String>(
                          builder: (FormFieldState<String> Tstate) {
                            return InputDecorator(
                              decoration: InputDecoration(
                                enabledBorder: DWdecro,
                                disabledBorder: DWdecro,
                                prefixIcon  : Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  child: IconButton(
                                    icon: Icon(Icons.timer_outlined,color: Colors.black,),
                                    color: Colors.black,
                                    onPressed: null,
                                  ),
                                ),
                              ),
                              // isEmpty: _curPeriod == '早餐',
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: _curPeriod,
                                  isDense: true,
                                  onChanged: (newValue) {
                                    setState(() {
                                      _curPeriod = newValue;
                                      Tstate.didChange(newValue);
                                    });
                                  },
                                  items: Period.map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                ),
                              ),
                            );
                          },
                        ),
                        SizedBox(height: 5,),
                        Positioned(child: Text('藥物使用類型',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                        FormField<String>(
                          builder: (FormFieldState<String> Tstate) {
                            return InputDecorator(
                              decoration: InputDecoration(
                                enabledBorder: decro,
                                disabledBorder: decro,
                                prefixIcon  : Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  child: IconButton(
                                    icon: Icon(Icons.medication_liquid_sharp,color: Colors.black,),
                                    color: Colors.black,
                                    onPressed: null,
                                  ),
                                ),
                              ),
                              // isEmpty: _curPeriod == '早餐',
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: _curType,
                                  isDense: true,
                                  onChanged: (newValue) {
                                    setState(() {
                                      _curType = newValue;
                                      Tstate.didChange(newValue);
                                    });
                                  },
                                  items: DrugTypes.map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                ),
                              ),
                            );
                          },
                        ),
                        Positioned(child: Text('藥包名稱',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                        TextFormField(
                          controller: Name,
                          decoration: InputDecoration(
                            enabledBorder: UPdecro,     //UPdecro,
                            focusedBorder: UPdecro,     //UPdecro,
                            disabledBorder: ErrorUPdecro,
                            // labelText: '請輸入毫升ml',
                            hintText: '請輸入藥物名稱',
                            prefixIcon: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: IconButton(
                                icon: Icon(Icons.chat,color: Colors.black,),
                                color: Colors.black,
                                onPressed: null,
                              ),
                            ),
                          ),
                          textInputAction: TextInputAction.next,
                        ),
                        TextFormField(
                          controller: DrugValue,
                          decoration: InputDecoration(
                            enabledBorder: DWdecro, //UPdecro,
                            focusedBorder: DWdecro, //UPdecro,
                            disabledBorder: ErrorDWdecro,
                            hintText: '請輸入使用藥物分量',
                            prefixIcon: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: IconButton(
                                icon: Icon(Icons.medication_outlined,color: Colors.black,),
                                color: Colors.black,
                                onPressed: null,
                              ),
                            ),
                          ),
                          textInputAction: TextInputAction.done,
                        ),
                        SizedBox(height: 5,),
                        ElevatedButton(
                            child: const Text('儲存紀錄'),
                            onPressed: () => { // null
                              createRecord(
                                Time: DateNow,
                                Year: YEAR,
                                Month: MONTH,
                                Day: DAY,
                                Period: _curPeriod.toString(),
                                DrugType: _curType.toString(),
                                DrugName: Name.text.trim(),
                                Drug: DrugValue.text.trim(),
                              ),
                              Navigator.pop(context),
                            }
                          // addRecord(),
                          // addRecordwTime(),
                          // Navigator.pop(context),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
            // : buildF(detail);
          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }
}

class DrugData {
  String key_value;
  String Type;
  String? name;
  String? amoute;
  String? special;
  String year;
  String month;
  String day;
  String created; // DateTime

  DrugData({
    this.name,
    this.amoute,
    this.special,
    required this.created,
    required this.Type,
    required this.key_value,
    required this.year,
    required this.month,
    required this.day,
  });

  Map<String, dynamic> toJson() => {
    'created': created,
    'year': year,
    'month': month,
    'day': day,

    'key_value': key_value,
    'Type': Type,
    'name': name,
    'amoute': amoute,
    'special': special,
  };

  static DrugData fromJson(Map<String, dynamic> json) => DrugData(
    created: json['created'],
    year: json['year'],
    month: json['month'],
    day: json['day'],

    name: json['name'],
    amoute: json['amoute'],
    special: json['special'],
    Type: json['Type'],
    key_value: json['key_value'],
  );
}

