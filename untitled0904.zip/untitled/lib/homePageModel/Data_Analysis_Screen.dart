import 'package:flutter_animated_icons/flutter_animated_icons.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_animated_icons/icons8.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../chartModels/line_chart.dart';
import '../chartModels/bar_chart.dart';
import '../chartModels/pie_chart.dart';
import 'package:charts_flutter/flutter.dart' as charts;

import 'package:untitled/Pages/splash.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({Key? key}) : super(key: key);

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> with TickerProviderStateMixin {

  bool haveAnalysis = false;
  // true;

  final pressed = SnackBar(content: const Text('you Pressed that button'));
  final hold = SnackBar(content: const Text('you hold the button'));

  final _DefaultScreen = Container(height: 300,width: double.infinity,color:Colors.grey.shade100,
    child: Align(alignment: Alignment.center,
      child: Text('沒有任何生活紀錄',style: TextStyle(fontSize: 30),),
    ),
  );

  CalendarFormat format = CalendarFormat.month;
  DateTime selectedDay = DateTime.now();
  DateTime focusedDay = DateTime.now();

  // final List<BarDataset> data1 = [
  //   BarDataset(
  //     domain: 'march',
  //     value: 10,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   BarDataset(
  //     domain: 'april',
  //     value: 30,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   BarDataset(
  //     domain: 'may',
  //     value: 60,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];
  // final List<PieDataset> data2 = [
  //   PieDataset(
  //     domain: 'march',
  //     value: 10,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   PieDataset(
  //     domain: 'april',
  //     value: 30,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   PieDataset(
  //     domain: 'may',
  //     value: 60,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];
  // final List<LineDataset> data3 = [
  //   LineDataset(
  //     domain: 100,
  //     value: 10,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 300,
  //     value: 30,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 500,
  //     value: 40,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];

  final user = FirebaseAuth.instance.currentUser!.email.toString();
  final dataB = FirebaseFirestore.instance.collection('Health');

  Stream<List<Record>> showRecords() => FirebaseFirestore.instance
      .collection('Health').doc(FirebaseAuth.instance.currentUser!.email.toString())
      .collection('Records')
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) => Record
      .fromJson(doc.data())).toList(),
  );
  Future<Record?> showRecord() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Health')
        .doc(FirebaseAuth.instance.currentUser!.email.toString())
        .collection('testRecord').doc('2022').collection('8').doc('30').get();

    if (snapshot.exists) {
      return Record.fromJson(snapshot.data()!);
    }
  }

  bool _Extended = false;
  double _SizeValue = 100.0;
  double _SizeDetail = 0.0;
  late AnimationController _animationController;
  late AnimationController _animationIcons;
  Future OpenDetail() async {
    _SizeValue = 230.0;
    _SizeDetail = 130.0;
    _animationController.forward();
    this._Extended = true;
  }
  Future CloseDetail() async { // WHENEVER
    _SizeValue = 100.0;
    _SizeDetail = 0.0;
    _animationController.reverse();
    this._Extended = false;
  }

  String _changeToMandarin (String EngType) {
    late String out = '';
    switch (EngType) {
      case 'FoodRecord':
        out = '飲食紀錄';
        break;
      case 'DrugRecord':
        out = '用藥紀錄';
        break;
      case 'SugarRecord':
        out = '血糖紀錄';
        break;
      case 'ExerciseRecord':
        out = '運動紀錄';
        break;
      case 'TemperatureRecord':
        out = '體溫紀錄';
        break;
      case 'WaterRecord':
        out = '飲水紀錄';
        break;
      case 'PulseRecord':
        out = '血壓紀錄';
        break;
      case 'SleepRecord':
        out = '睡眠紀錄';
        break;
      // case 'InsulinTypes':
      //   out = '飲食紀錄';
      //   break;
      default:
        break;
    };
    return out;
  }
  Widget _enlist(Record data, DateTime sD, E,) {
    // print(sD);
    // print(sD.year);
    // print(sD.month);
    // print(sD.day);
    String Y = sD.year.toString();
    String M = sD.month.toString();
    String D = sD.day.toString();

    String value = '';
    (data.amoute==null||data.amoute=='') ? value = '紀錄份量：${data.name}' : value = '紀錄份量：${data.name} - ${data.amoute}';

    if (data.year==Y&&data.month==M&&data.day==D) {
      return Column(
        children: [
          AnimatedContainer(
            padding: EdgeInsets.symmetric(vertical: 5,),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [BoxShadow(
                color: Colors.black38,
                offset: Offset(3.0, 3.0),
                blurRadius: 0,
                spreadRadius: 0,
              )
              ],
            ),
            width: double.infinity,
            height: _SizeValue,
            // 100 or 250
            duration: Duration(milliseconds: 450),
            // _animateDuration,
            child: Column(
              children: [
                Container( // duration: Duration(milliseconds: 450,),
                  child: Row(
                    children: [
                      SizedBox(width: 20,),
                      Padding(padding: EdgeInsets.only(top: 10),
                        child: CircleAvatar(),
                      ), // Circle
                      Padding(
                        padding: EdgeInsets.only(top: 20, left: 20),
                        child: Column(
                          children: [
                            Text(_changeToMandarin(data.Type), style: TextStyle(fontSize: 30),),
                            Text('${data.created}', style: TextStyle(fontSize: 16),),
                          ],
                        ),
                      ), // Texts
                      SizedBox(width: 50,),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            if (_Extended == false) {
                              OpenDetail();
                            } else {
                              CloseDetail();
                            }
                            if (_animationIcons.status==AnimationStatus.dismissed) {
                              this._animationIcons.reset();
                              this._animationIcons.animateTo(0.6);
                            } else {
                              this._animationIcons.reverse();
                            }
                          });
                        },
                        icon: Padding(
                          padding: const EdgeInsets.all(1.0),
                          child: Lottie.asset(
                            Icons8.expand,
                            controller: this._animationIcons,
                          ),
                        ),
                        // AnimatedIcon(
                        //   icon:
                        //   progress: _animationController,
                        // ),
                      ), // Extend Button
                    ],
                  ),
                ),
                // (!_Extended) ? Container() : SizedBox(height: 1, child: Container(color: Colors.grey,),) ,
                AnimatedContainer(
                  padding: EdgeInsets.all(10),
                  width: double.infinity,
                  height: _SizeDetail,
                  duration: Duration(milliseconds: 450),
                  child: Container( //color: Colors.amber,
                    padding: EdgeInsets.all(5),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(flex: 30,
                          child: Text(
                            '分類詳情：${data.special}', style: TextStyle(fontSize: 16),),
                        ),
                        Expanded(flex: 30,
                          child: Text(
                            value, style: TextStyle(fontSize: 16),),
                        ),
                        Expanded(flex: 30,
                          child: Text(
                            '其他詳情：${data.key_value}', style: TextStyle(fontSize: 16),),
                        ),
                      ],
                    ),
                  ),
                ),
                // Detail
              ],
            ),
          ),
          SizedBox(height: 3,),
        ],
      );
    }
    return Container();
  }

  @override
  void initState() {
    super.initState();

    _animationController = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    _animationIcons = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
  }

  // double _CurrentRecordsSize = 282.0; Expanded

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(padding: EdgeInsets.only(top: 60,right: 20,left: 20,bottom: 10,),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // Expanded(flex: 20,
            //   child: Container(
            //     decoration: BoxDecoration(
            //       borderRadius: BorderRadius.all(Radius.circular(10)),
            //       border: Border.all(color: HexColor('#305C54')),
            //     ),
            //     child: TableCalendar(
            //       firstDay: DateTime(1950),
            //       lastDay: DateTime(2050),
            //       focusedDay: DateTime.now(),
            //
            //       //Calendar Sizes' [2weeks, a week,mouth(4weeks)]
            //       calendarFormat: format,
            //       onFormatChanged: (CalendarFormat _format) {
            //         setState(() {//set Calendar to next size(show on button)
            //           format = _format;
            //         });
            //       },
            //       //onPress
            //       selectedDayPredicate: (DateTime date){ //Date Select action
            //         return isSameDay(selectedDay, date);
            //       },
            //       onDaySelected: (DateTime selectDay,DateTime focusDay) {
            //         setState(() {//Date select States
            //           selectedDay = selectDay;
            //           focusedDay = focusDay;
            //         });
            //         Navigator.of(context).push(
            //           MaterialPageRoute(
            //             builder: (context) => Splash(),
            //           ),
            //         );
            //         print(focusedDay);//print on console
            //       },
            //
            //       startingDayOfWeek: StartingDayOfWeek.sunday,
            //       daysOfWeekVisible: true,
            //       //Style
            //       calendarStyle: CalendarStyle(isTodayHighlighted: true,
            //         selectedDecoration: BoxDecoration(
            //           color: Color.fromRGBO(48, 92, 84, 100),
            //           shape: BoxShape.circle,
            //         ),
            //         selectedTextStyle: TextStyle(color: Colors.white),
            //         todayDecoration: BoxDecoration(
            //             color: Colors.grey,
            //             shape: BoxShape.circle
            //         ),
            //       ),
            //       headerStyle: HeaderStyle(
            //         // formatButtonVisible: false,// default is true
            //         formatButtonShowsNext: false,// false = current Size
            //         formatButtonDecoration: BoxDecoration(
            //           color: Color.fromRGBO(48, 92, 84, 100),
            //           borderRadius: BorderRadius.circular(5),
            //         ),
            //         formatButtonTextStyle: TextStyle(
            //           color: Colors.black,
            //         ),
            //         // leftChevronVisible: false,//cancel <--
            //         // rightChevronVisible: false,//cancel -->
            //       ),
            //     ),
            //   ),
            // ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: HexColor('#305C54')),
              ),
              child: TableCalendar(
                // locale: 'zh_CN',
                firstDay: DateTime(1950),
                lastDay: DateTime(2050),
                focusedDay: selectedDay,
                currentDay: DateTime.now(), // today Always

                //Calendar Sizes' [2weeks, a week,mouth(4weeks)]
                calendarFormat: format,
                onFormatChanged: (CalendarFormat _format) {
                  setState(() { // set Calendar to next size(show on button)
                    format = _format;
                    // print(_format);
                    // switch(format) {
                    //   case CalendarFormat.month:
                    //     _CurrentRecordsSize = 282.0;
                    //     break;
                    //   case CalendarFormat.twoWeeks:                        _CurrentRecordsSize = 250.0;
                    //     _CurrentRecordsSize = 438.0;
                    //     break;
                    //   case CalendarFormat.week:                        _CurrentRecordsSize = 400.0;
                    //     _CurrentRecordsSize = 490.0;
                    //     break;
                    // }
                  });
                },

                //onPress
                onDaySelected: (DateTime selectDay,DateTime focusDay) {
                  setState(() { // Date select States
                    selectedDay = selectDay; // AnyDate on tap
                    focusedDay = focusDay; // 只限當月，跨月會到當月上/下限
                  });
                  print(selectedDay); // print on console
                  print(focusedDay); // print on console
                },
                // onDisabledDayTapped: ,
                selectedDayPredicate: (DateTime date){ // Date Select action
                  return isSameDay(selectedDay, date);
                },
                startingDayOfWeek: StartingDayOfWeek.sunday,
                daysOfWeekVisible: true,

                //Style
                calendarStyle: CalendarStyle(isTodayHighlighted: true,
                  selectedDecoration: BoxDecoration(
                    color: Colors.greenAccent,
                    shape: BoxShape.circle,
                  ),
                  selectedTextStyle: TextStyle(color: Colors.white),
                  todayDecoration: BoxDecoration(
                    color: Colors.grey,
                    shape: BoxShape.circle,
                  ),
                  weekendTextStyle: TextStyle(color: Colors.red),
                ),
                headerStyle: HeaderStyle(
                  // formatButtonVisible: false,// default is true
                  formatButtonShowsNext: false,// false = current Size
                  formatButtonDecoration: BoxDecoration(
                    color: Colors.greenAccent,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  formatButtonTextStyle: TextStyle(
                    color: Colors.black,
                  ),
                  // leftChevronVisible: false,//cancel <--
                  // rightChevronVisible: false,//cancel -->
                ),
              ),
            ),
            Expanded(flex: 12,child: SizedBox(height: 10,),),
            // current
            // haveAnalysis ?
            // Container(height: 250, width: double.infinity,
            //   // color:Colors.grey.shade100,
            //   decoration: BoxDecoration(
            //     borderRadius: BorderRadius.all(Radius.circular(10)),
            //     border: Border.all(color: HexColor('#305C54')),
            //   ),
            //   child: Padding(padding: EdgeInsets.symmetric(horizontal: 20,vertical: 5),
            //     child: StreamBuilder(
            //       stream: dataB.snapshots(),
            //       builder: (context, snapshot) {
            //         if (snapshot.hasError) {
            //           return Center(child: Text('${snapshot.error} happen'),);
            //         } else if (snapshot.hasData) {
            //           if (snapshot.data==null) {
            //             return _DefaultScreen;
            //           }
            //           // return PageView.builder(
            //           //   itemBuilder: itemBuilder,
            //           //   itemCount: dataB.doc(user).snapshots().length,
            //           // );
            //           return PageView(
            //             scrollDirection: Axis.horizontal,
            //             children: [
            //               Container( // color: Colors.grey,
            //                 child: BarChart(data: data1),
            //               ),
            //               Container( // color: Colors.grey,
            //                 child: PieChart(data: data2),
            //               ),
            //               Container( // color: Colors.grey,
            //                 child: LineChart(data: data3),
            //               ),
            //             ],
            //           );
            //         } else {
            //           return Center(child: CircularProgressIndicator(),);
            //         }
            //       },
            //     ),
            //   ),
            // ) :
            Expanded(flex: 88,child: AnimatedContainer(
              duration: Duration(milliseconds: 200), // to make sure not overflow
              // height: _CurrentRecordsSize, Expanded
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: HexColor('#305C54')),),
              child: StreamBuilder<List<Record>>(
                stream: showRecords(),
                builder: (context, snapshotT) {
                  // print(focusedDay.year);
                  if(snapshotT.hasError){
                    // print(snapshotT.data);
                    // print(snapshotT);
                    // print(FirebaseAuth.instance.currentUser!.email.toString());
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black38,
                            offset: Offset(3.0, 3.0),
                            blurRadius: 0,
                            spreadRadius: 0,
                          ),
                        ],
                      ),
                      width: double.infinity,height: 100,
                      child: Center(child: Text('無法載入正確資料\n${snapshotT.error}'),),
                    );
                  } else if (snapshotT.hasData) {
                    final dataL = snapshotT.data!;
                    return ListView(
                      children: [
                        for(Record t in dataL) _enlist(t, selectedDay,_Extended),
                        ElevatedButton(
                          child: Text('Basics'),
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Splash()),
                          ),
                        ),
                        ElevatedButton(
                          child: Text('Basics'),
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Splash()),
                          ),
                        ),
                        ElevatedButton(
                          child: Text('Basics'),
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Splash()),
                          ),
                        ),
                        ElevatedButton(
                          child: Text('Basics'),
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Splash()),
                          ),
                        ),
                        ElevatedButton(
                          child: Text('Basics'),
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Splash()),
                          ),
                        ),
                      ],
                    );
                  } else {
                    return Center(child: CircularProgressIndicator(),);
                  }
                },
              ),
            ),),
          ],
        ),
      ),
    );
  }
}

class Record {
  String key_value;
  String Type;
  String? name;
  String? amoute;
  String? special;
  String year;
  String month;
  String day;
  String created; // DateTime

  Record({
    this.name,
    this.amoute,
    this.special,
    required this.created,
    required this.Type,
    required this.key_value,
    required this.year,
    required this.month,
    required this.day,
  });

  Map<String, dynamic> toJson() => {
    'created': created,
    'year': year,
    'month': month,
    'day': day,

    'key_value': key_value,
    'Type': Type,
    'name': name,
    'amoute': amoute,
    'special': special,
  };

  static Record fromJson(Map<String, dynamic> json) => Record(
    created: json['created'],
    year: json['year'],
    month: json['month'],
    day: json['day'],

    name: json['name'],
    amoute: json['amoute'],
    special: json['special'],
    Type: json['Type'],
    key_value: json['key_value'],
  );
}

