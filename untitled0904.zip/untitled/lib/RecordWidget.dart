import 'package:flutter/material.dart';

class RecordWidget extends State<StatefulWidget> with TickerProviderStateMixin {
  int id;
  AnimationController SizeController;
  AnimationController IconController;
  RecordWidget(this.id,this.SizeController,this.IconController);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    SizeController =
    new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    IconController =
    new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }

}