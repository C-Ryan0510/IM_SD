import 'dart:io'; // for File

import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart'; // for local search file

class AddPicture extends StatefulWidget {
  const AddPicture({Key? key}) : super(key: key);

  @override
  State<AddPicture> createState() => _AddPictureState();
}

class _AddPictureState extends State<AddPicture> {
  final CurUser = FirebaseAuth.instance.currentUser?.email.toString();
  PlatformFile? pickedFile;
  UploadTask? uploadTask;

  Future uploadFile() async {
    // final path = 'Users_Profiles_AvatarPic/Ryan&Migo.jpg';
    final path = 'ProfilesPictures/${CurUser}/${pickedFile!.name}'; // name change by user
    final file = File(pickedFile!.path!);

    final ref = FirebaseStorage.instance.ref().child(path); // set sending Path
    setState(() {
      uploadTask = ref.putFile(file); // sending
    });

    final snapshot = await uploadTask!.whenComplete(() => {}); // finished

    final urlDownload = await snapshot.ref.getDownloadURL();
    print('Download Link: $urlDownload'); // get better view of pic on browser
    FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .collection('Image_Gallery').add({
      'image_path': urlDownload.toString(),
    });

    setState(() {
      uploadTask = null; // sent
    });
    Navigator.of(context).pop();
  }

  Future selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;

    setState(() {
      pickedFile = result.files.first;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (pickedFile != null)
              Expanded( // Image preView
                child: Container(
                  color: Colors.blue[100],
                  child: Center(
                    child: Image.file(
                      File(pickedFile!.path!),
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                    // Text(pickedFile!.name), picture name
                  ),
                ),
              ),
            ElevatedButton(
              onPressed: selectFile,
              child: Text('從裝置選擇'),
            ),
            SizedBox(height: 30,),
            ElevatedButton(
              onPressed: () {
                uploadFile();
              },
              child: Text('新增該照片'),
            ),
            SizedBox(height: 30,),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('取消該上傳'),
            ),
            SizedBox(height: 32,),
            buildProgress(),
          ],
        ),
      ),
    );
  }

  Widget buildProgress() => StreamBuilder<TaskSnapshot>(
    stream: uploadTask?.snapshotEvents,
    builder: (context, snapshot) {
      if (snapshot.hasData) {
        final data = snapshot.data!;
        double progress = data.bytesTransferred / data.totalBytes;

        return SizedBox(
          height: 50,
          child: Stack(
            fit: StackFit.expand,
            children: [
              LinearProgressIndicator(
                value: progress,
                backgroundColor: Colors.grey,
                color: Colors.green,
              ),
              Center(
                child: Text(
                  '${(100 * progress).roundToDouble()}%',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        );
      } else {
        return SizedBox(height: 50,);
      }
    },);
}


