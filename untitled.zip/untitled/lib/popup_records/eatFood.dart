import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
// import 'package:health/health.dart';


class Food extends StatefulWidget {
  const Food ({Key? key}) : super(key: key);

  @override
  State<Food> createState() => _FoodState();
}

// DocumentSnapshot snapshot; //Define snapshot

class _FoodState extends State<Food> {

  final ThisTypeCollection = FirebaseFirestore.instance
      .collection('Health').doc('Record_types')
      .collection('FoodTypes');

  // DropBox Default set text
  TextEditingController Peroid = TextEditingController();
  TextEditingController FoodCatergory = TextEditingController();
  TextEditingController FoodAte = TextEditingController();
  TextEditingController Calories = TextEditingController();

  // DocumentSnapshot snapshot; //Define snapshot
  final decro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.circular(50),);
  final UPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final DWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);

  String DateNow = DateFormat('yyyy-MM-dd – kk:mm').format(DateTime.now());

  String YEAR = DateTime.now().year.toString();
  String MONTH = DateTime.now().month.toString();
  String DAY = DateTime.now().day.toString();


  final Period = ['Morning', 'Noon', 'Evening',];
  final FoodTypes = ["Grains","ProteinsAndMeat","Vegetables","Fruits","Dairy","OliAndNuts"];
  var empty = [''];

  // default test
  final GrainsT = ['A_bowl_of_Rice','A_bowl_of_Noodle','A_bowl_of_Ramen','Steamed_bun',
                   'Toast','Cereal','Porridge','Tapioca'];
  final VarietyT = ['Spiced_Corned_Egg','Boiled_Egg','Scrambled_Egg','Poached_Egg'
                    'Beef','Pork','Ham','Fish',];
  final VegetableT = ['Cabbage','brocoli','lettuce','White_Fungus','Black_Fungus'];
  final FruitT = ['Orange','Tangerine','Banana','Strawberry','Blueberry',
                  'Mulberry'];
  final DairyT = ['Cream','Cheese','Yogurt',];
  final OilNutsT = ['Sesame','Almond','Salad_Oil'];

  var FDSelect = ['請先選擇食物類型'];

  var _curFType;
  var _curPeriod;
  var _curFSelect;
  // var _curCalories;

  bool _AbnormalCodition(String? kcal,String? amoute) { /*Any condition?*/
    bool outcome = false;
    // double wValue = double.parse(Water);
    // if (wValue > 2000) {
    //   outcome = true;
    // }
    return outcome;
  }
  // Firestore Database
  Future createRecord({String? Name,String? Special,String? Amoute, required String Time,/*required String? Type,*/required String Key,required String Year,required String Month,required String Day,}) async {
    final doc = FirebaseFirestore.instance.collection('Health').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .collection('Records');

    final data = FoodData(
      created: Time,
      year: Year,
      month: Month,
      day: Day,

      name: Name,
      amoute: Amoute,
      key_value: Key,
      special: Special,
      Type: 'FoodRecord',
      condition: false,
    );

    final json = data.toJson();
    await doc.add(json);
  }

  // stream<list<class>> function[stream]
  // read DOCs and make it to List
  Stream<List<FoodType>> readFoodCategory() => ThisTypeCollection
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) =>
      FoodType.fromJson(doc.data())).toList(),
  );
  // // read DOC w specify ID
  Stream<List<FoodData>> readFoodKcal(String cate) => ThisTypeCollection
      .doc(cate).collection('path').snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) =>
      FoodData.fromJson(doc.data())).toList(),
  );


  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.transparent,
      body: StreamBuilder (
        stream: ThisTypeCollection.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong! ${snapshot}');
          } else if (snapshot.hasData) {
            final detail = snapshot.data;

            return detail == null ?
            Center(child: Text('NoData'),) :
            Container(//border
              height: 500,
              decoration: BoxDecoration(
                border: Border.all(width:2.5,color: Color.fromRGBO(48, 92, 84, 100),),
                borderRadius: BorderRadius.only(topRight: Radius.circular(40),topLeft: Radius.circular(40),),
              ),
              child: Stack(
                children: [
                  //title for this record widget
                  Positioned(child: Text('飲食紀錄',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),top: 10,left: 18,),
                  Positioned(child: Text('紀錄時間',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 40,left: 24,),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                    child: ListView(
                      // mainAxisAlignment: MainAxisAlignment.end,
                      padding: EdgeInsets.only(top: 63),
                      children: [
                        TextFormField(enabled: false,
                          initialValue: DateNow,
                          decoration: InputDecoration(
                            enabledBorder: UPdecro,
                            disabledBorder: UPdecro,
                            prefixIcon  : Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: IconButton(
                                icon: Icon(Icons.date_range_rounded,color: Colors.black,),
                                color: Colors.black,
                                onPressed: null,
                              ),
                            ),
                          ),
                        ),
                        FormField<String>(
                          builder: (FormFieldState<String> Tstate) {
                            return InputDecorator(
                              decoration: InputDecoration(
                                enabledBorder: DWdecro,
                                disabledBorder: DWdecro,
                                prefixIcon  : Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  child: IconButton(
                                    icon: Icon(Icons.timer_outlined,color: Colors.black,),
                                    color: Colors.black,
                                    onPressed: null,
                                  ),
                                ),
                              ),
                              // isEmpty: _curPeriod == '早餐',
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: _curPeriod,
                                  isDense: true,
                                  onChanged: (newValue) {
                                    setState(() {
                                      _curPeriod = newValue;
                                      Tstate.didChange(newValue);
                                    });
                                  },
                                  items: Period.map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                ),
                              ),
                            );
                          },
                        ),
                        SizedBox(height: 10,),
                        Positioned(child: Text('食物類型',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                        FutureBuilder<List<FoodType>>(
                          future: readFoodCategory().first,
                          builder: (context, snapshot2){
                            List<String> buffer = [];

                            if (snapshot2.hasError) {
                              return Text('something went wrong ${snapshot}');
                            } else if (snapshot2.hasData) {
                              List<FoodType> data = snapshot2.data!;
                              // print(data);
                              for(FoodType target in data) {
                                // print(target.Types);
                                buffer.add(target.Types);
                              }
                            }
                            return FormField<String>(
                              builder: (FormFieldState<String> Fstate) {
                                return InputDecorator(
                                  decoration: InputDecoration(
                                    enabledBorder: UPdecro,
                                    disabledBorder: UPdecro,
                                    prefixIcon  : Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: IconButton(
                                        icon: Icon(Icons.food_bank_outlined,color: Colors.black,),
                                        color: Colors.black,
                                        onPressed: null,
                                      ),
                                    ),
                                  ),
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton<String>(
                                      value: _curFType,
                                      isDense: true,
                                      onChanged: (newValue) {
                                        setState(() {
                                          if (newValue != _curFType) {
                                            if (_curFType != null){
                                              setState((){
                                                _curFType = null;
                                              });
                                            };
                                            if (newValue != null) {
                                              setState(() {
                                                _curFSelect = null;// change key = null
                                                _curFType = newValue;
                                              });
                                            }
                                          }
                                          _curFType = newValue;
                                          print(_curFType.toString());
                                          Fstate.didChange(newValue);
                                        });
                                      },
                                      items: buffer.map((String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                        StreamBuilder<List<FoodData>>(
                          stream: readFoodKcal(_curFType.toString()),
                          builder: (context, snapshot3) {
                            List<String> buffer = [];

                            if (snapshot3.hasError) {
                              return Text('something went wrong ${snapshot}');
                            } else if (snapshot3.hasData) {
                              List<FoodData>? data2 = snapshot3.data;
                              // print(data2);
                              for (FoodData target in data2!) {
                                // print(target.Type);
                                buffer.add(target.Type);
                              }
                            }
                            return FormField<String>(
                              builder: (FormFieldState<String> FSstate) {
                                return InputDecorator(
                                  decoration: InputDecoration(
                                    enabledBorder: DWdecro,
                                    disabledBorder: DWdecro,
                                    prefixIcon: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: IconButton(
                                        icon: Icon(Icons.rice_bowl_outlined,
                                          color: Colors.black,),
                                        color: Colors.black,
                                        onPressed: null,
                                      ),
                                    ),
                                  ),
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton<String>(
                                      value: _curFSelect,
                                      isDense: true,
                                      onChanged: (newValue) {
                                        setState(() {
                                          _curFSelect = newValue;
                                          FSstate.didChange(newValue);
                                        });
                                      },
                                      items: GrainsT.map((String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                );
                              },
                            );
                          }
                        ),
                        Positioned(child: Text('熱量',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                        FutureBuilder(
                          future: FirebaseFirestore.instance.collection('Health').doc(_curFType).get(),
                          builder: (context, snapshotf){
                            final data = snapshotf.data;
                            return TextFormField(
                              enabled: false,
                              textAlign: TextAlign.start,
                              decoration: InputDecoration(
                                prefixIcon: Padding(padding: EdgeInsets.all(15),
                                  child: Text('大卡(Kcal)'),
                                ),
                                enabledBorder: UnderlineInputBorder(),
                                disabledBorder: UnderlineInputBorder(),
                              ),
                              // controller: Calories..text = data,
                            );
                          },
                        ),
                        SizedBox(height: 5,),
                        ElevatedButton(
                            child: const Text('儲存紀錄'),
                            onPressed: () => {// null
                              createRecord(
                                Time: DateNow,
                                Year: YEAR,
                                Month: MONTH,
                                Day: DAY,

                                Name: _curFSelect.toString(),
                                // Amoute: _curFType.toString(), 200g from DB
                                Special: '[${_curPeriod.toString()}] - ${_curFType.toString()}',
                                Key: Calories.text.trim(),
                              ),
                              Navigator.pop(context),
                            }
                          // addRecord(),
                          // addRecordwTime(),
                          // Navigator.pop(context),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
                // : buildF(detail);
          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }
}
class FoodType {
  String Types;
  FoodType({
    required this.Types,
  });
  Map<String, dynamic> toJson() =>{
    'Types': Types,
  };
  static FoodType fromJson(Map<String, dynamic> json) => FoodType(
    Types: json['Types'],
  );
}

class FoodData {
  String key_value;
  String Type;
  String? name;
  String? amoute;
  String? special;
  bool condition;
  String year;
  String month;
  String day;
  String created; // DateTime

  FoodData({
    this.name,
    this.amoute,
    this.special,
    required this.condition,
    required this.created,
    required this.Type,
    required this.key_value,
    required this.year,
    required this.month,
    required this.day,
  });

  Map<String, dynamic> toJson() => {
    'created': created,
    'year': year,
    'month': month,
    'day': day,

    'key_value': key_value,
    'Type': Type,
    'name': name,
    'amoute': amoute,
    'special': special,
    'isAbnormal': condition,
  };

  static FoodData fromJson(Map<String, dynamic> json) => FoodData(
    created: json['created'],
    year: json['year'],
    month: json['month'],
    day: json['day'],

    name: json['name'],
    amoute: json['amoute'],
    special: json['special'],
    Type: json['Type'],
    key_value: json['key_value'],
    condition: json['isAbnormal'],
  );
}