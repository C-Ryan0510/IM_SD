import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
// import 'package:scroll_date_picker/scroll_date_picker.dart';
// import 'package:health/health.dart';


class Food extends StatefulWidget {
  const Food ({Key? key}) : super(key: key);

  @override
  State<Food> createState() => _FoodState();
}

// DocumentSnapshot snapshot; //Define snapshot

class _FoodState extends State<Food> {
  TextEditingController Timestamp = TextEditingController();
  // DropBox Default set text
  // TextEditingController Peroid = TextEditingController();
  // TextEditingController FoodCatergory = TextEditingController();
  // TextEditingController FoodAte = TextEditingController();
  TextEditingController Calories = TextEditingController();

  // DocumentSnapshot snapshot; //Define snapshot
  final decro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.circular(50),);
  final UPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final DWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);

  String DateNow = DateFormat('yyyy-MM-dd – kk:mm').format(DateTime.now());

  final Period = ['早餐', '午餐', '晚餐',];
  final FoodTypes = ["全榖根莖類","蛋豆魚肉類","蔬菜類","水果類","低脂乳品類","油脂與堅果種子類"];

  // default test
  final GrainsT = ['一碗白飯','麵'];
  final VarietyT = ['蛋','肉'];
  final VegetableT = ['綠','黃'];
  final FruitT = ['飯','麵'];
  final DairyT = ['奶','nope'];
  final OilNutsT = ['???','??','?'];

  var FDSelect = ['請先選擇食物類型'];
  var _curPeriod;
  var _curFType;
  var _curFSelect;
  // read Firestore Database


  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 500,
      child: Container(//border
        decoration: BoxDecoration(
          border: Border.all(width:2.5,color: Color.fromRGBO(45, 224, 213, 86),),
          borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20),),
        ),
        child: Stack(
          children: [
            //title for this record widget
            Positioned(child: Text('飲食紀錄',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),top: 10,left: 18,),
            Positioned(child: Text('紀錄時間',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
            Padding(padding: EdgeInsets.symmetric(horizontal: 20),
              child: ListView(
                // mainAxisAlignment: MainAxisAlignment.end,
                padding: EdgeInsets.only(top: 63),
                children: [
                  TextFormField(enabled: false,
                    controller: Timestamp,
                    initialValue: DateNow,
                    decoration: InputDecoration(
                      enabledBorder: UPdecro,
                      disabledBorder: UPdecro,
                      prefixIcon  : Padding(
                        padding: EdgeInsets.all(10),
                        child: IconButton(
                          icon: Icon(Icons.date_range_rounded),
                          color: Colors.black,
                          onPressed: () {  },
                        ),
                      ),
                    ),
                  ),
                  FormField<String>(
                    builder: (FormFieldState<String> Tstate) {
                      return InputDecorator(
                        decoration: InputDecoration(
                          enabledBorder: DWdecro,
                          disabledBorder: DWdecro,
                          prefixIcon: Padding(
                            padding: EdgeInsets.all(10),
                            child: Icon(Icons.timer_outlined,color: Colors.black,),
                          ),
                        ),
                        // isEmpty: _curPeriod == '早餐',
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _curPeriod,
                            isDense: true,
                            onChanged: (newValue) {
                              setState(() {
                                _curPeriod = newValue;
                                Tstate.didChange(newValue);
                              });
                            },
                            items: Period.map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 10,),
                  Positioned(child: Text('食物類型',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                  FormField<String>(
                    builder: (FormFieldState<String> Fstate) {
                      return InputDecorator(
                        decoration: InputDecoration(
                          enabledBorder: UPdecro,
                          disabledBorder: UPdecro,
                          prefixIcon: Padding(
                            padding: EdgeInsets.all(10),
                            child: Icon(Icons.food_bank_outlined,color: Colors.black,),
                          ),
                        ),
                        isEmpty: _curFType == '全榖根莖類',
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _curFType,
                            isDense: true,
                            onChanged: (newValue) {
                              setState(() {
                                if (newValue != _curFType) {
                                  if (_curFType != null){
                                    setState((){
                                      _curFType = null;
                                    });
                                  };
                                  if (newValue != null) {
                                    setState(() {
                                      _curFSelect = null;// change key = null
                                      _curFType = newValue;
                                    });
                                  }
                                }
                                _curFType = newValue;
                                Fstate.didChange(newValue);
                                switch(_curFType){
                                  case'全榖根莖類':
                                    FDSelect = GrainsT;
                                    break;
                                  case'蛋豆魚肉類':
                                    FDSelect = VarietyT;
                                    break;
                                  case'蔬菜類':
                                    FDSelect = VegetableT;
                                    break;
                                  case'水果類':
                                    FDSelect = FruitT;
                                    break;
                                  case'低脂乳品類':
                                    FDSelect = DairyT;
                                    break;
                                  case'油脂與堅果種子類':
                                    FDSelect = OilNutsT;
                                    break;
                                  default:
                                    FDSelect = [''];
                                    break;
                                }
                              });
                            },
                            items: FoodTypes.map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      );
                    },
                  ),
                  FormField<String>(
                    builder: (FormFieldState<String> FSstate) {
                      return InputDecorator(
                        decoration: InputDecoration(
                          enabledBorder: DWdecro,
                          disabledBorder: DWdecro,
                          prefixIcon: Padding(
                            padding: EdgeInsets.all(10),
                            child:
                            Icon(Icons.rice_bowl_outlined,color: Colors.black,),
                          ),
                        ),
                        isEmpty: _curFSelect == '',
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _curFSelect,
                            isDense: true,
                            onChanged: (newValue) {
                              setState(() {
                                _curFSelect = newValue;
                                FSstate.didChange(newValue);
                                // calories.text = caloriesBaseValue;
                              });
                            },
                            items: FDSelect.map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      );
                    },
                  ),

                  Positioned(child: Text('熱量',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                  TextFormField(
                    enabled: false,
                    textAlign: TextAlign.start,
                    decoration: InputDecoration(
                      prefixIcon: Padding(padding: EdgeInsets.all(15),
                          child: Text('大卡(Kcal)')),
                      enabledBorder: UnderlineInputBorder(),
                      disabledBorder: UnderlineInputBorder(),
                    ),
                    // controller: calories,
                    onChanged: (Value){
                      setState(() {
                        // calories = readBaseValue.toString();
                      });
                    },
                  ),
                  SizedBox(height: 5,),
                  ElevatedButton(
                    child: const Text('儲存紀錄'),
                    onPressed: () => doAll(),
                    // Navigator.pop(context),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future doAll() async{
    record();
    Navigator.pop(context);
  }
  Future record() async{
    return null;
  }
}

class FoodData {
  String? Kcal;
  String? amoute;
  DateTime? created;

  FoodData();

  Map<String, dynamic> toJson() =>
      {'Kcal': Kcal, 'amoute': amoute,
        // 'created': created};
      };

  FoodData.fromSnapshot(snapShot)
    : Kcal = snapShot.data()['Kcal'],
      amoute = snapShot.data()['amoute'];
}
