import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Pulse extends StatefulWidget {
  const Pulse ({Key? key}) : super(key: key);

  @override
  State<Pulse> createState() => _PulseState();
}

// DocumentSnapshot snapshot; //Define snapshot

class _PulseState extends State<Pulse> {

  final ThisTypeCollection = FirebaseFirestore.instance
      .collection('Health').doc('Record_types')
      .collection('PulseTypes');

  // DropBox Default set text
  TextEditingController systolic_blood_pressure = TextEditingController();
  TextEditingController diastolic_blood_pressure = TextEditingController();

  // DocumentSnapshot snapshot; //Define snapshot
  final decro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.circular(50),);
  final Errordecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.circular(50),);
  final UPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final ErrorUPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final DWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);
  final ErrorDWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);

  String DateNow = DateFormat('yyyy-MM-dd – kk:mm').format(DateTime.now());

  String YEAR = DateTime.now().year.toString();
  String MONTH = DateTime.now().month.toString();
  String DAY = DateTime.now().day.toString();

  var _curFType;

  bool _AbnormalCodition(String sys, String dia,) {
    bool outcome = false;
    double SYS = double.parse(sys); // Systolic 收縮壓
    double DIA = double.parse(dia); // diastolic 舒張壓
    if(SYS < 140||SYS > 160||DIA < 90||DIA > 95) {
      outcome = true;
    }
    return outcome;
  }

  // Firestore Database
  Future createRecord({required String Time,required String systolic,required String diastolic,required String Year,required String Month,required String Day,}) async {
    final doc = FirebaseFirestore.instance.collection('Health')
        .doc(FirebaseAuth.instance.currentUser!.email.toString())
        .collection('Records');

    final data = PulseData(
      created: Time,
      year: Year,
      month: Month,
      day: Day,

      key_value: '$systolic mmHg / $diastolic mmHg',
      Type: 'PulseRecord',
      condition: _AbnormalCodition(systolic, diastolic),
    );

    final json = data.toJson();
    await doc.add(json);
  }

  // read DOCs and make it to List
  Stream<List<PulseData>> readPulse() =>
      ThisTypeCollection
          .snapshots()
          .map((snapshot) => snapshot
          .docs.map((doc) =>
          PulseData.fromJson(doc.data())).toList()
      );

  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.transparent,
      body: StreamBuilder<List> (
        stream: readPulse(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong! ${snapshot}');
          } else if (snapshot.hasData) {
            final detail = snapshot.data;

            return detail == null ?
            Center(child: Text('NoData'),) :
            SizedBox(
              height: 500, // ????
              child: Container(//border
                decoration: BoxDecoration(
                  border: Border.all(width:2.5,color: Color.fromRGBO(48, 92, 84, 100),),
                  borderRadius: BorderRadius.only(topRight: Radius.circular(40),topLeft: Radius.circular(40),),
                ),
                child: Stack(
                  children: [
                    //title for this record widget
                    Positioned(child: Text('血壓紀錄',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),top: 10,left: 18,),
                    Positioned(child: Text('紀錄時間',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 35,left: 24,),
                    Positioned(child: Text('收縮壓',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 122,left: 24,),
                    Positioned(child: Text('舒張壓',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 208,left: 24,),
                    Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        // mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Expanded(flex: 9,child: SizedBox(),),
                          Expanded(
                            flex: 10,
                            child: TextFormField(enabled: false,
                              initialValue: DateNow,
                              decoration: InputDecoration(
                                // enabledBorder: decro,
                                // focusedBorder: decro,
                                disabledBorder: decro, // enabled FALSE
                                prefixIcon  : Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  child: IconButton(
                                    icon: Icon(Icons.date_range_rounded,color: Colors.black,),
                                    color: Colors.black,
                                    onPressed: null,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(flex: 3, child: SizedBox(),),
                          TextFormField(
                            controller: systolic_blood_pressure,
                            decoration: InputDecoration(
                              enabledBorder: decro, //UPdecro,
                              focusedBorder: decro, //UPdecro,
                              disabledBorder: ErrorUPdecro,
                              hintText: '輸入收縮壓(mmHg)',
                              prefixIcon  : Padding(
                                padding: EdgeInsets.symmetric(horizontal: 10),
                                child: IconButton(
                                  icon: Icon(Icons.bloodtype_outlined,color: Colors.black,),
                                  color: Colors.black,
                                  onPressed: null,
                                ),
                              ),
                            ),
                            textInputAction: TextInputAction.next,
                          ),
                          Expanded(flex: 0,child: SizedBox(height: 24,),),
                          TextFormField(
                            controller: diastolic_blood_pressure,
                            decoration: InputDecoration(
                              enabledBorder: decro, // DWdecro,
                              focusedBorder: decro, // DWdecro,
                              disabledBorder: ErrorDWdecro,
                              hintText: '輸入舒張壓(mmHg)',
                              prefixIcon  : Padding(
                                padding: EdgeInsets.symmetric(horizontal: 10),
                                child: IconButton(
                                  icon: Icon(Icons.bloodtype,color: Colors.black,),
                                  color: Colors.black,
                                  onPressed: null,
                                ),
                              ),
                            ),
                            textInputAction: TextInputAction.done,
                          ),
                          Expanded(flex: 20,child: SizedBox(),),
                          Expanded(
                            flex: 6,
                            child: Container(width: double.infinity,
                              child: ElevatedButton(
                                child: const Text('儲存紀錄'),
                                onPressed: () => { // null
                                  createRecord(
                                    Time: DateNow,
                                    Year: YEAR,
                                    Month: MONTH,
                                    Day: DAY,
                                    systolic: systolic_blood_pressure.text.trim(),
                                    diastolic: diastolic_blood_pressure.text.trim(),
                                  ),
                                  Navigator.pop(context),
                                },
                              ),
                            ),
                          ),
                          SizedBox(height: 10,),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
            // : buildF(detail);
          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }
}

class PulseData {
  String key_value;
  String Type;
  String? name;
  String? amoute;
  String? special;
  String year;
  String month;
  String day;
  String created;
  bool condition; // DateTime

  PulseData({
    this.name,
    this.amoute,
    this.special,
    required this.condition,
    required this.created,
    required this.Type,
    required this.key_value,
    required this.year,
    required this.month,
    required this.day,
  });

  Map<String, dynamic> toJson() => {
    'created': created,
    'year': year,
    'month': month,
    'day': day,

    'key_value': key_value,
    'Type': Type,
    'name': name,
    'amoute': amoute,
    'special': special,
    'isAbnormal': condition,
  };

  static PulseData fromJson(Map<String, dynamic> json) => PulseData(
    created: json['created'],
    year: json['year'],
    month: json['month'],
    day: json['day'],

    name: json['name'],
    amoute: json['amoute'],
    special: json['special'],
    Type: json['Type'],
    key_value: json['key_value'],
    condition: json['isAbnormal'],
  );
}
