import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
// import 'package:health/health.dart';


class Sugar extends StatefulWidget {
  const Sugar ({Key? key}) : super(key: key);

  @override
  State<Sugar> createState() => _SugarState();
}

// DocumentSnapshot snapshot; //Define snapshot

class _SugarState extends State<Sugar> {

  final ThisTypeCollection = FirebaseFirestore.instance
      .collection('Health').doc('Recrod_types')
      .collection('InsulinTypes');

  // DocumentSnapshot snapshot; //Define snapshot
  final decro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.circular(50),);
  final Errordecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.circular(50),);
  final UPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final ErrorUPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final DWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);
  final ErrorDWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);

  String DateNow = DateFormat('yyyy-MM-dd – kk:mm').format(DateTime.now());

  String YEAR = DateTime.now().year.toString();
  String MONTH = DateTime.now().month.toString();
  String DAY = DateTime.now().day.toString();

  final Period = ['Morning', 'Noon', 'Evening',];

  // default test
  final SugarTypes = ['BeforeMeal', 'AfterMeal'];
  final InsulinTypes = ['Apidra', 'Humalog', 'NovoRapid',/*...*/];

  TextEditingController Sugar = TextEditingController();
  TextEditingController Insulin = TextEditingController();

  var _curS;
  var _curI;
  late var outS;
  late var outI;
  // read Firestore Database
  Future createRecord({required String Time,required String Insulin,required String InsuType,required String Sugar,required String SugarType,required String Year,required String Month,required String Day,}) async {
    final doc = FirebaseFirestore.instance.collection('Health').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .collection('SugarRecord').doc(Year).collection(Month).doc(Day);

    final data = SugarData(
      created: Time,
      Sugar: Sugar,
      Insulin: Insulin,
      year: Year,
      month: Month,
      day: Day,
      SugarType: SugarType,
      InsulinType: InsuType,
    );

    final json = data.toJson();
    await doc.set(json);
  }

  // stream<list<class>> function[stream]
  // read DOCs and make it to List
  Stream<List<InsulinData>> readSugar(String category, String clas) =>
      ThisTypeCollection
      .snapshots()
      .map((snapshot) =>
      snapshot.docs.map((doc) =>
      InsulinData.fromJson(doc.data())).toList()
  );
  // // read DOC w specify ID
  Future<SugarData?> SugarandInsulinDetail() async {
    final Detail = ThisTypeCollection.doc('test');
    final snapshot = await Detail.get();

    if (snapshot.exists) {
      return SugarData.fromJson(snapshot.data()!);
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.transparent,
      body: StreamBuilder (
        stream: ThisTypeCollection.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong! ${snapshot}');
          } else if (snapshot.hasData) {
            final detail = snapshot.data;
            final data = [];

            return detail == null ?
            Center(child: Text('NoData'),) :
            Container(//border
              height: 500,
              decoration: BoxDecoration(
                border: Border.all(width:2.5,color: Color.fromRGBO(45, 224, 213, 86),),
                borderRadius: BorderRadius.only(topRight: Radius.circular(40),topLeft: Radius.circular(40),),
              ),
              child: Stack(
                children: [
                  //title for this record widget
                  Positioned(child: Text('血糖和胰島素',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),top: 10,left: 18,),
                  Positioned(child: Text('紀錄時間',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 40,left: 20,),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                    child: ListView(
                      physics: NeverScrollableScrollPhysics(),
                      // mainAxisAlignment: MainAxisAlignment.end,
                      padding: EdgeInsets.only(top: 63),
                      children: [
                        TextFormField(enabled: false,
                          initialValue: DateNow,
                          decoration: InputDecoration(
                            enabledBorder: decro,
                            disabledBorder: decro,
                            prefixIcon  : Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: IconButton(
                                icon: Icon(Icons.date_range_rounded,color: Colors.black,),
                                color: Colors.black,
                                onPressed: null,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 3,),
                        Positioned(child: Text('血糖紀錄類型',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                        FormField<String>(
                          builder: (FormFieldState<String> Fstate) {
                            return InputDecorator(
                              decoration: InputDecoration(
                                enabledBorder: UPdecro,
                                disabledBorder: UPdecro,
                                prefixIcon: Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  child: IconButton(
                                    icon: Icon(Icons.account_circle,color: Colors.black,),
                                    color: Colors.black,
                                    onPressed: null,
                                  ),
                                ),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: _curS,
                                  isDense: true,
                                  onChanged: (newValue) {
                                    setState(() {
                                      if (newValue != _curS) {
                                        if (_curS != null){
                                          setState((){
                                            _curS = null;
                                          });
                                        };
                                        if (newValue != null) {
                                          setState(() {
                                            _curS = newValue;
                                          });
                                        }
                                      }
                                      _curS = newValue;
                                      Fstate.didChange(newValue);
                                    });
                                  },
                                  items: SugarTypes.map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                ),
                              ),
                            );
                          },
                        ),
                        TextFormField(
                          controller: Sugar,
                          decoration: InputDecoration(
                            enabledBorder: DWdecro, //UPdecro,
                            focusedBorder: DWdecro, //UPdecro,
                            disabledBorder: ErrorDWdecro,
                            // labelText: '請輸入毫升ml',
                            hintText: '請輸入血糖(mg/dl)',
                            prefixIcon: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: IconButton(
                                icon: Icon(Icons.water_drop_outlined,color: Colors.black,),
                                color: Colors.black,
                                onPressed: null,
                              ),
                            ),
                          ),
                          textInputAction: TextInputAction.next,
                        ),
                        Positioned(child: Text('胰島素',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                        FormField<String>(
                          builder: (FormFieldState<String> Fstate) {
                            return InputDecorator(
                              decoration: InputDecoration(
                                enabledBorder: UPdecro,
                                disabledBorder: UPdecro,
                                prefixIcon: Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  child: IconButton(
                                    icon: Icon(Icons.account_circle_outlined,color: Colors.black,),
                                    color: Colors.black,
                                    onPressed: null,
                                  ),
                                ),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: _curI,
                                  isDense: true,
                                  onChanged: (newValue) {
                                    setState(() {
                                      if (newValue != _curI) {
                                        if (_curI != null){
                                          setState((){
                                            _curI = null;
                                          });
                                        };
                                        if (newValue != null) {
                                          setState(() {
                                            _curI = newValue;
                                          });
                                        }
                                      }
                                      _curI = newValue;
                                      Fstate.didChange(newValue);
                                      }
                                    );
                                  },
                                  items: InsulinTypes.map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                ),
                              ),
                            );
                          },
                        ),
                        TextFormField(
                          controller: Insulin,
                          decoration: InputDecoration(
                            enabledBorder: DWdecro, //UPdecro,
                            focusedBorder: DWdecro, //UPdecro,
                            disabledBorder: ErrorDWdecro,
                            // labelText: '請輸入毫升ml',
                            hintText: '請輸入胰島素劑量',
                            prefixIcon: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: IconButton(
                                icon: Icon(Icons.water_drop_outlined,color: Colors.black,),
                                color: Colors.black,
                                onPressed: null,
                              ),
                            ),
                          ),
                          textInputAction: TextInputAction.next,
                        ),
                        SizedBox(height: 5,),
                        ElevatedButton(
                            child: const Text('儲存紀錄'),
                            onPressed: () => { // null
                              createRecord(
                                Time: DateNow,
                                Year: YEAR,
                                Month: MONTH,
                                Day: DAY,
                                SugarType: _curS.toString(),
                                Sugar: Sugar.text.trim(),
                                InsuType: _curI.toString(),
                                Insulin: Insulin.text.trim(),
                              ),
                              Navigator.pop(context),
                            }
                          // addRecord(),
                          // addRecordwTime(),
                          // Navigator.pop(context),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
            // : buildF(detail);
          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }
}

class SugarData {
  String Sugar;
  String SugarType;
  String Insulin;
  String InsulinType;
  String year;
  String month;
  String day;
  String created; // DateTime

  SugarData({
    required this.created,
    required this.Sugar,
    required this.SugarType,
    required this.Insulin,
    required this.InsulinType,
    required this.year,
    required this.month,
    required this.day,
  });

  Map<String, dynamic> toJson() => {
    'year': year,
    'month': month,
    'day': day,
    'Sugar': Sugar,
    'SugarType': SugarType,
    'Insulin': Insulin,
    'InsulinType': InsulinType,
    'created': created,
  };


  static SugarData fromJson(Map<String, dynamic> json) => SugarData(
    // (json['date'] as Timestamp, String),
    created: json['created'],
    Insulin: json['Insulin'],
    InsulinType: json['InsulinType'],
    Sugar: json['Sugar'],
    SugarType: json['SugarType'],
    year: json['year'],
    month: json['month'],
    day: json['day'],
  );
}

class InsulinData {
  String Insulin;
  String InsulinType;

  InsulinData({
    required this.Insulin,
    required this.InsulinType
  });

  Map<String, dynamic> toJson() => {
    'Insulin': Insulin,
    'InsulinType': InsulinType,
  };

  static InsulinData fromJson(Map<String, dynamic> json) => InsulinData(
    Insulin: json['Insulin'],
    InsulinType: json['InsulinType'],
  );
}
