import 'package:flutter/material.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:untitled/utils.dart';

import 'Pages/HomeScreen.dart';
import 'Pages/login_page.dart';
import 'Pages/newComer.dart';
import 'Pages/splash.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(const MyApp());
}
final navigatorKey = GlobalKey<NavigatorState>();

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    scaffoldMessengerKey: Utils.messengerKey,
    navigatorKey: navigatorKey,//GlobalKey
    title: '健康照護',
     theme: ThemeData(
      primarySwatch: Colors.blue,
    ),
    home: Splash(),//顯現主頁
    // initialRoute: '/',
    // routes: { //導覽頁面路徑}
  );
}

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

//主要導覽頁
class _MainScreenState extends State<MainScreen> {
  final authPath = FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser?.email.toString());

  Future<UserData?> readUserData() async {
    final snapshot = await authPath.get();

    if (snapshot.exists) {
      return UserData.fromJson(snapshot.data()!);
    }
  }

  @override
  Widget build(BuildContext context)
  => Scaffold(/*此代替導覽路徑*/
    body: StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),//Stream check STATE
      builder: (context, snapshot) {
        if(snapshot.connectionState==ConnectionState.waiting){
          return Center(child: CircularProgressIndicator(),);/*Loading*/
        } else if(snapshot.hasError){
          return Center(child: Text('Something went wrong!'),);
        } else if(snapshot.hasData){
          return FutureBuilder<UserData?>(
            future: readUserData(),
            builder: (context, snapshot2) {
              if (snapshot2.hasData) {
                final UData = snapshot2.data;
                if (UData==null||UData?.isFirst==true) {
                  return Intro();
                    // Guideline(index: 1);
                } else {
                  return HomeScreen();
                }
              } else {
                return Center(child: CircularProgressIndicator(),);
              }
            },
          );
          return HomeScreen();
        } else { //if press sign out or hasn't sign in
          return loginPage();
        }
      },
    ),
  );
}

class UserData {
  bool? isFirst;

  UserData({
    required this.isFirst,
  });

  // Map<String, dynamic> toJson() => {
  //   'Kcal': Kcal,
  //   'Type': Type,
  //   'Food': Food,
  //   'created': created,
  // };

  static UserData fromJson(Map<String, dynamic> json) => UserData(
    isFirst: (json['isFirst'] as bool),
    // (json['date'] as Timestamp).toDate(),
  );
}