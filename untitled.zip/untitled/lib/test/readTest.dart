import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:untitled/popup_records/eatFood.dart';
import 'package:untitled/test/test.dart';

class read extends StatefulWidget {
  const read({Key? key}) : super(key: key);

  @override
  State<read> createState() => _readState();
}

class _readState extends State<read> {

  final CollectionReference _products = FirebaseFirestore.instance.collection('test');

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    getList();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("return"),
      ),
      // body: StreamBuilder(
      //     stream: _products.snapshots(),
      //     builder: (context, AsyncSnapshot<QuerySnapshot> streamSnapshot) {
      //       if(streamSnapshot.hasData) {
      //         return ListView.builder(
      //           itemCount: streamSnapshot.data!.docs.length,
      //           itemBuilder: (context, index) {
      //             final DocumentSnapshot documentSnapshot = streamSnapshot.data!.docs[index];
      //             return Card(
      //               margin: const EdgeInsets.all(10),
      //               child: ListTile(
      //                 title: Text(documentSnapshot['name']),
      //                 subtitle: Text(documentSnapshot['price'].toString()),
      //               ),
      //             );
      //           },
      //         );
      //       }
      //     },
      // ),
    );
  }
  
  Future getList() async{
    var data = await FirebaseFirestore.instance
        .collection('Health')
        .doc('Record_types')
        .collection('FoodTypes')
        .doc('Grains')
        .collection('飯類')
        .get();
        // .orderBy('熱量', descending: true)
        // .doc('一碗白飯')
    // setState(() {
    //   _list = List.from(data.docs.map((doc) => FoodData.fromSnapshot(doc)));
    // });
  }
}
