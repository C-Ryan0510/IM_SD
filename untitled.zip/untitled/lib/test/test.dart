import 'package:flutter/material.dart';
import 'package:untitled/popup_records/eatFood.dart';

class ttttt extends StatelessWidget {
  final FoodData _a;

  ttttt(this._a);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              Row(
                children: [
                  Padding(padding: const EdgeInsets.only(bottom: 10.0),
                    child: Text("shoud ${_a.Kcal}"),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(padding: const EdgeInsets.only(bottom: 10.0),
                    child: Text("${_a.amoute}"),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
