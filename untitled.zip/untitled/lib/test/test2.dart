import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class webt extends StatefulWidget {
  const webt({Key? key}) : super(key: key);

  @override
  State<webt> createState() => _webtState();
}

class _webtState extends State<webt> {
  @override
  Widget build(BuildContext context) {
    return WebView(
      initialUrl: 'https://www.tku.edu.tw',
    );
  }
}
