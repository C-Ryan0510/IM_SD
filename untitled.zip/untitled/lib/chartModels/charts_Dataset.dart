import 'package:charts_flutter/flutter.dart' as charts;

class ChartsDataset {
  final double value;
  final num domain;
  final charts.Color? color;
  ChartsDataset({
    required this.value,
    required this.domain,
    this.color,
  });

  static ChartsDataset fromJson(Map<String, dynamic> json) => ChartsDataset(
    value: json['value'],
    domain: json['domain'],
    color: json['color'],
  );

  ChartsDataset.fromMap(Map<String, dynamic> map)
      : assert(map['value']!=null),
        assert(map['domain']!=null),
        assert(map['color']!=null),
        value = map['value'],
        domain = map['domain'],
        color = map['color'];

  @override // for debug Print
  String toString() => 'Record<$value:$domain:$color>';

}