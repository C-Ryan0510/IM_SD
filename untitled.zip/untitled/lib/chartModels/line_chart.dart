import 'package:flutter/material.dart';

import 'package:charts_flutter/flutter.dart' as charts;
import 'charts_Dataset.dart';

class LineChart extends StatelessWidget {
  final List<LineDataset> data;
  LineChart({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<charts.Series<LineDataset,int>> series = [
      charts.Series(
        id: 'Line',
        data: data,
        domainFn: (LineDataset data, _) => data.domain,
        measureFn: (LineDataset data, _) => data.value,
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
      ),
    ];
    return charts.LineChart(series, animate: true,);
  }
}

class LineDataset {
  final String? id;
  final double value;
  final int domain;
  final charts.Color? color;
  LineDataset({
    required this.value,
    required this.domain,
    this.color,
    this.id,
  });

  static LineDataset fromJson(Map<String, dynamic> json) => LineDataset(
    value: json['value'],
    domain: json['domain'],
    color: json['color'],
  ); // firestore

  LineDataset.fromMap(Map<String, dynamic> map)
      : assert(map['value']!=null),
        assert(map['domain']!=null),
        assert(map['color']!=null),
        assert(map['id']!=null),
        value = map['value'],
        domain = map['domain'],
        color = map['color'],
        id = map['id'];

  @override // for debug Print
  String toString() => 'Record<$value:$domain:$color>';

}