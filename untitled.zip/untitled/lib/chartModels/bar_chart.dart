import 'package:flutter/material.dart';

import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'charts_Dataset.dart';


class BarChart extends StatelessWidget {
  final List<BarDataset> data;

  BarChart({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<charts.Series<BarDataset,String>> series = [
      charts.Series(
        id: 'Pie',
        data: data,
        domainFn: (BarDataset data1, _) => data1.domain,
        measureFn: (BarDataset data1, _) => data1.value,
        colorFn: (BarDataset data1, _) => data1.color,
      ),
    ];
    return charts.BarChart(series, animate: true,);
  }
}

class BarDataset {
  final String? id;
  final String domain;
  final double value; // or int
  final charts.Color color;

  BarDataset({
    required this.domain,
    required this.value,
    required this.color,
    this.id,
  });
}

