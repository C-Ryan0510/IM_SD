import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'charts_Dataset.dart';


class PieChart extends StatelessWidget {
  final List<PieDataset> data;

  PieChart({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<charts.Series<PieDataset,String>> series = [
      charts.Series(
        id: 'Pie',
        data: data,
        domainFn: (PieDataset data1, _) => data1.domain,
        measureFn: (PieDataset data1, _) => data1.value,
        colorFn: (PieDataset data1, _) => data1.color,
      ),
    ];
    return charts.PieChart(series, animate: true,);
  }
}

class PieDataset {
  final String domain;
  final double value; // or int
  final charts.Color color;

  PieDataset({
    required this.domain,
    required this.value,
    required this.color,
  });
}

