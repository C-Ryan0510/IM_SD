import 'package:cloud_firestore/cloud_firestore.dart';

class Family {
  String? name;    // title
  String? mail;    // subtitle ??? or check if is CurrentUser
  String? gender;
  String? picpath; // Pic
  String? GIDcheck;// check group_id is same

  Family({
    this.picpath,
    this.gender,
    required this.name,
    required this.mail,
    required this.GIDcheck,
  });

  Map<String, dynamic> toJson() => {
    'user_name': name,
    'user_ID/account': mail,
    'user_gender': gender,
    'user_avatar': picpath,
    'group_id': GIDcheck,
  };

  static Family fromJson(Map<String, dynamic> json) => Family(
    mail: json['user_ID/account'],
    picpath: json['user_avatar'],
    name: json['user_name'],
    GIDcheck: json['group_id'],
    gender: json['user_gender'],
  );
}