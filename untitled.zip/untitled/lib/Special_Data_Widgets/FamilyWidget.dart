import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:untitled/Special_Data_Widgets/RecordWidget.dart';

import './/Special_Data_Widgets/Record.dart';
import './/Special_Data_Widgets/Family.dart';

import 'package:lottie/lottie.dart';
import 'package:flutter_animated_icons/icons8.dart';

class FamilyWidget extends StatefulWidget {
  Family FAMILY;
  FamilyWidget({Key? key,required this.FAMILY}) : super(key: key);

  @override
  State<FamilyWidget> createState() => _FamilyWidgetState();
}

class _FamilyWidgetState extends State<FamilyWidget> with TickerProviderStateMixin {
  late AnimationController animationController;
  late AnimationController animationIcons;

  bool Extended = false;
  double SizeValue = 100.0;
  double SizeDetail = 0.0;

  Future OpenDetail() async {
    SizeValue = 400.0;
    SizeDetail = 300.0;
    animationController.forward();
    this.Extended = true;
  }
  Future CloseDetail() async { // WHENEVER
    SizeValue = 100.0;
    SizeDetail = 0.0;
    animationController.reverse();
    this.Extended = false;
  }

  @override
  void initState() {
    super.initState();
    animationController = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    animationIcons = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
  }
  @override
  Widget build(BuildContext context) {
    return _enlist(widget.FAMILY);
  }

  Widget _DefaultIcon(String gender) {
    switch(gender.toLowerCase()){
      case'male':
        return Icon(Icons.man,size: 30,);
      case'female':
        return Icon(Icons.woman,size: 30,);
      default:
        return Icon(Icons.reddit_outlined ,size: 30,);
    }
  }
  Stream<List<Record>> _showRecords(/*Family data*/) => FirebaseFirestore.instance
      .collection('Health').doc(widget.FAMILY.mail/*data.mail*/)
      .collection('Records').orderBy('created',descending: true)
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) => Record
      .fromJson(doc.data())).toList(),
  );
  Widget _enlist(Family data) {
    // String value = '';
    // (data.amoute==null||data.amoute=='') ? value = '紀錄份量：${data.name}' : value = '紀錄份量：${data.name} - ${data.amoute}';
    return Column(
      children: [
        AnimatedContainer(
          padding: EdgeInsets.symmetric(vertical: 5,),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(
              color: Colors.black38,
              offset: Offset(3.0, 3.0),
              blurRadius: 0,
              spreadRadius: 0,
            )
            ],
          ),
          width: double.infinity,
          height: SizeValue,
          // 100 or 250
          duration: Duration(milliseconds: 450),
          // _animateDuration,
          child: Column(
            children: [
              Container( // duration: Duration(milliseconds: 450,),
                child: Row(
                  children: [
                    // SizedBox(width: 20,),
                    Expanded(flex:5,child: Container(),),
                    Expanded(flex: 10,
                      child: Padding(padding: EdgeInsets.only(top: 10),
                      child: CircleAvatar(
                        child: (data.picpath==''||data.picpath==null) ?
                        _DefaultIcon(data.gender.toString()) :
                        ClipRRect(
                          child: Image.network(data.picpath.toString()),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        backgroundColor: Colors.white,
                      ),
                    ),
                    ), // Circle
                    Expanded(flex: 50,
                      child: Padding(
                      padding: EdgeInsets.only(top: 20, left: 20),
                      child: Column(
                        children: [
                          Text('${data.name}', style: TextStyle(fontSize: 30),),
                          Text('${data.mail}', style: TextStyle(fontSize: 16),),
                        ],
                      ),
                    ),
                    ), // Texts
                    // SizedBox(width: 50,),
                    Expanded(flex: 10,
                      child: IconButton(
                        onPressed: () {
                          setState(() {
                            if (Extended == false) {
                              OpenDetail();
                            } else {
                              CloseDetail();
                            }
                            if (animationIcons.status==AnimationStatus.dismissed) {
                              this.animationIcons.reset();
                              this.animationIcons.animateTo(0.6);
                            } else {
                              this.animationIcons.reverse();
                            }
                          });
                        },
                        icon: Padding(
                          padding: const EdgeInsets.all(1.0),
                          child: Lottie.asset(
                            Icons8.expand,
                            controller: this.animationIcons,
                          ),
                        ),
                        // AnimatedIcon(
                        //   icon:
                        //   progress: _animationController,
                        // ),
                      ),
                    ),
                    Expanded(flex:5,child: Container(),),
                  ],
                ),
              ),
              // (!_Extended) ? Container() : SizedBox(height: 1, child: Container(color: Colors.grey,),) ,
              StreamBuilder<List<Record>>(
                stream: _showRecords(),
                builder: (context, snapshot) {
                  Future.delayed(Duration(milliseconds: 500),);
                  if (snapshot.hasError) {
                    return Center(child: Text('${snapshot.error}'),);
                  } else if (snapshot.hasData) {
                    // final data2 = snapshot.data!;
                    final dataList = snapshot.data!;
                    // print(dataL);
                    List<Record>TodayList = [];
                    for(Record check in dataList){
                      String CurY = DateTime.now().year.toString();
                      String CurM = DateTime.now().month.toString();
                      String CurD = DateTime.now().day.toString();
                      if (CurY==check.year&&CurM==check.month&&CurD==check.day) {
                        TodayList.add(check);
                      }
                    }
                    if (TodayList.isEmpty) {
                      return AnimatedContainer(
                        padding: EdgeInsets.all(5),
                        width: double.infinity,
                        height: SizeDetail,
                        duration: Duration(milliseconds: 450),
                        child: Card(
                          elevation: 12,
                          child: Center(
                            child: Text('今天尚未做任何紀錄', style: TextStyle(fontSize: 30,),),
                          ),
                        ),
                      );
                    } else {
                      return AnimatedContainer(
                        padding: EdgeInsets.all(10),
                        width: double.infinity,
                        height: SizeDetail,
                        duration: Duration(milliseconds: 450),
                        child: Container( //color: Colors.amber,
                          padding: EdgeInsets.all(5),
                          child: ListView(
                            children: [
                              for(Record Thier in TodayList) RecordWidget(RECORD: Thier),
                            ],
                          ),
                        ),
                      );
                    }
                  } else {
                    return Center(child: Container(),); // this will overflow for a second
                  }
                },
              ), // Detail
            ],
          ),
        ),
        SizedBox(height: 3,),
      ],
    );

  }
}
