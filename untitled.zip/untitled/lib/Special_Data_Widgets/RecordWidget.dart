import 'package:flutter/material.dart';
import './Record.dart';

import 'package:lottie/lottie.dart';
import 'package:flutter_animated_icons/icons8.dart';

class RecordWidget extends StatefulWidget {
  Record RECORD;
  RecordWidget({Key? key,required this.RECORD}) : super(key: key);

  @override
  State<RecordWidget> createState() => _RecordWidgetState();
}

class _RecordWidgetState extends State<RecordWidget> with TickerProviderStateMixin {
  // int id; // ??
  late AnimationController animationController;
  late AnimationController animationIcons;

  bool Extended = false;
  double SizeValue = 100.0;
  double SizeDetail = 0.0;

  Future OpenDetail() async {
    SizeValue = 230.0;
    SizeDetail = 130.0;
    animationController.forward();
    this.Extended = true;
  }
  Future CloseDetail() async { // WHENEVER
    SizeValue = 100.0;
    SizeDetail = 0.0;
    animationController.reverse();
    this.Extended = false;
  }
  bool NotifyB = false;

  @override
  void initState() {
    super.initState();
    animationController = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    animationIcons = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
  }

  String _cipherToMandarin (String? English) {
    if (English == null) { return ''; }
    String exLower = English.trim().toLowerCase();
    Map _exchange = {
      'foodrecord' : '飲食紀錄',
      'drugrecord' : '用藥紀錄',
      'sugarrecord' : '血糖紀錄',
      'exerciserecord' : '運動紀錄',
      'temperaturerecord' : '體溫紀錄',
      'waterrecord' : '飲水紀錄',
      'pulserecord' : '血壓紀錄',
      'sleeprecord' : '睡眠紀錄',
      'insulinrecord' : '胰島素使用紀錄',
      'morning' : '早餐',
      'noon' : '午餐',
      'evening' : '晚餐',
      'dairy' : '乳製品',
      'fruits' : '水果',
      'grains' : '五穀根莖類',
      'oilandnuts' : '堅果油類',
      'proteinsandmeat' : '蛋豆魚肉類',
      'vegetables' : '蔬菜',
      'a_bowl_of_rice' : '一碗白飯',
      'a_bowl_of_noodle' : '一碗麵',
      'a_bowl_of_ramen' : '一碗拉麵',
      'steamed_bun' : '蒸饅頭',
      'toast' : '吐司',
      'cereal' : '穀物',
      'porridge' : '粥/稀飯',
      'tapioca' : '粉圓',
      'beforemeal' : '餐前',
      'aftermeal' : '餐後',
      'anytime' : '隨時',
      'chinese' : '中藥',
      'prescription' : '處方藥品',
      'as_prescription' : '處方籤',
      'painkiller' : '止痛藥',
      'walking' : '步行',
      'jogging' : '慢跑',
      'biking' : '自行車',
      'dancing' : '跳舞',
      'hiking' : '登山',
      'swimming' : '游泳',
      'yoga' : '瑜珈',
      'rope-jumping' : '跳繩',
      'push-up' : '俯臥撑',
      'sit-up' : '仰臥起坐',
    };
    if (_exchange[exLower]!=null) {
      return _exchange[exLower];
    } else {
      return English;
    }
  }
  String _getClassify (String? special, String? type) {
    if (special == null ) { return ''; }
    late String outcome;
    List<String> buffer = special.split(RegExp(r'\-'));
    String one = _cipherToMandarin(buffer.first);
    String two = _cipherToMandarin(buffer.last);
    outcome = '[ $one ] - $two ';
    return '分類詳情：' + outcome;
  }
  String _getCorrectUnit (String unit){
    // if (unit == null) { return ''; } // no Need cause no trim()
    Map _exchange = {
      null: '',
      'pill(s)': '藥物(粒)',
      'oC': '攝氏',
      'oF': '華氏',
      'l': '公升',
      'ml': '毫升',
      'mg': '豪克',
      'g': '公克',
      'gram': '公克',
      'kg': '公斤',
      // 'mmHg': 'mmHg(毫米汞柱)',
      'mmHg': 'mmHg',
      'min': '分鐘',
      'min(s)': '分鐘',
      'minute': '分鐘',
      'minute(s)': '分鐘',
      'hour': '小時',
      'Hour': '小時',
      'hour(s)': '小時',
      'Hour(s)': '小時',
    };
    if (_exchange[unit]!=null) {
      return _exchange[unit];
    } else {
      return unit;
    }
  }
  String _getAmoute (String? amoute, String? Type) {
    if (amoute == null) { return ''; }
    late String outcome;
    List<String> buffer = (amoute as String).split(RegExp(r'/'));
    String AMOUTE = buffer.first;
    String UNIT = _getCorrectUnit(buffer.last);
    // if ()
    outcome = '$AMOUTE /$UNIT';
    return '紀錄詳情：' + outcome;
  }
  String _ABdetail (String? key,String? Type) {
    late String ABoutcome;
    late List<String> ABbuffer;
    switch (Type) {
      case 'TemperatureRecord':
        double TemperC = double.parse(key!);
        if(TemperC < 35) {
          ABoutcome = '體溫過低';
        } else if (TemperC > 37.5 && TemperC < 38.3) {
          ABoutcome = '體溫偏高';
        } else if (TemperC > 38.3 && TemperC < 39.5) {
          ABoutcome = '體溫過高';
        } else if (TemperC > 39.5) {
          ABoutcome = '體溫超高，建議尋求醫療協助。';
        }
        break;
      case 'PulseRecord':
        ABbuffer = key!.split(RegExp(r';'));
        double systolic = double.parse(ABbuffer.first);
        double diastolic = double.parse(ABbuffer.last);
        if(diastolic < 90) {
          ABoutcome = '低血壓';
        } else if (systolic >= 90 && systolic < 105) {
          ABoutcome = '輕度高血壓';
        } else if (systolic >= 105 && systolic < 115) {
          ABoutcome = '中度高血壓';
        } else if (systolic >= 115) {
          ABoutcome = '重度高血壓';
        }
        break;
    }
    return ABoutcome;
  }
  String _OtherNote(Record data) {
    late String outcome;
    String? key = data.key_value, Keyname = data.name;
    bool AB = data.condition;
    int? times = data.Times, goal = data.Goal;
    switch(data.Type) {
      case 'FoodRecord':
        (times==null||goal==null) ?
        outcome = '$key[${_cipherToMandarin(Keyname)}](未設定目標)' :
        outcome = '$key[${_cipherToMandarin(Keyname)}](目標：$goal大卡)';
        break;
      case 'DrugRecord':
        (AB) ?
        outcome = '此次紀錄檢測到異常' :
        (times==null||goal==null) ?
        outcome = '$key[${_cipherToMandarin(Keyname)}] (尚未設定提醒)' :
        outcome = '$key[${_cipherToMandarin(Keyname)}] (今天已紀錄$times/$goal)';
        break;
      case 'SugarRecord':
        (AB) ?
        outcome = '此次紀錄檢測到異常' :
        (times==null||goal==null) ?
        outcome = '$key[${_cipherToMandarin(Keyname)}] (尚未設定提醒)' :
        outcome = '$key[${_cipherToMandarin(Keyname)}] (今天已紀錄$times/$goal)';
        break;
      case 'ExerciseRecord':
        (AB) ?
        outcome = '此次紀錄檢測到異常' :
        (times==null||goal==null) ?
        outcome = '$key[${_cipherToMandarin(Keyname)}](未設定目標)' :
        outcome = '$key[${_cipherToMandarin(Keyname)}](已達成$times/$goal)';
        break;
      case 'TemperatureRecord':
        (!AB) ?
        outcome = '體溫正常' :
        // (IsoF) ?
        // outcome = '${_ABdetail(key,data.Type)}': // in case oF
        outcome = '${_ABdetail(key,data.Type)}';
        break;
      case 'PulseRecord':
        (!AB) ?
        outcome = '正常血壓' :
        outcome = '${_ABdetail(key,data.Type)}';
        break;
      case 'WaterRecord':
        if (double.parse(key!) > (goal as int)) {
          outcome = '飲水過量有害身體健康請注意。';
        } else {
          outcome = '已飲用${data.amoute}(目標：$goal/ml)';
        }
        break;
      case 'SleepRecord':
        if (double.parse(key!) < 7) {
          outcome = '休息是為了走更長遠的路';
        } else {
          outcome = '今天睡眠充足';
        }
        break;
      default:
        outcome = 'error';
        break;
    }
    return '其他詳情：' + outcome;
  }
  Widget _AppendIcon (String TYPE,bool ABNORMAL) {
    late Widget Appearance;
    late Color condition;
    (ABNORMAL) ? condition = Colors.deepOrange : condition = Colors.green;
    switch (TYPE) {
      case 'FoodRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/eat_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'DrugRecord':
        Appearance = GestureDetector(
          onTap: () {
            if (NotifyB) {
              showDialog(
                context: context,
                builder: (BuildContext context) => AlertDialog(
                  title: Text('已向對方提醒用藥',),
                  actions: [
                    FlatButton(child: Text('確定'),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                  elevation: 24,
                ),
                barrierDismissible: false, // tap outside of it to dismiss
              );
            }
            setState(() {
              NotifyB = !NotifyB;
            });
          },
          child: (NotifyB) ?
          CircleAvatar(
            backgroundColor: Colors.amberAccent,
            child: ClipRRect(
              child: Image.asset('lib/asset/notification.png'),
              borderRadius: BorderRadius.circular(50.0),
            ),
          ):
          CircleAvatar(
            backgroundColor: condition,
            child: ClipRRect(
              child: Image.asset('lib/asset/drug_record.png'),
              borderRadius: BorderRadius.circular(50.0),
            ),
          ),
        );
        break;
      case 'SugarRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/bloodsugar_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'ExerciseRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/exercise_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'TemperatureRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/temperature_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'WaterRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/water_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'PulseRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/pulse_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'SleepRecord':
        Appearance = CircleAvatar(
          // radius: 16.0,
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/sleep_clock.png',),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
    // case 'InsulinTypes':
    //   Appearance = '飲食紀錄';
    //   break;
      default:
        break;
    };
    return Appearance;
  }
  Widget _enlist(Record data,/*DateTime selected*/) {
    String Note1 = _getClassify(data.special, data.Type);
    String Note2 = _getAmoute(data.amoute,data.Type);
    String Note3 = _OtherNote(data);

    print(Note1);
    print(Note2);
    print(Note3);

    // if (data.year==Y&&data.month==M&&data.day==D) {
    //   return Column(
    //     children: [
    //       AnimatedContainer(
    //         padding: EdgeInsets.symmetric(vertical: 5,),
    //         decoration: BoxDecoration(
    //           color: Colors.white,
    //           borderRadius: BorderRadius.circular(10),
    //           boxShadow: [BoxShadow(
    //             color: Colors.black38,
    //             offset: Offset(3.0, 3.0),
    //             blurRadius: 0,
    //             spreadRadius: 0,
    //           )
    //           ],
    //         ),
    //         width: double.infinity,
    //         height: SizeValue,
    //         // 100 or 250
    //         duration: Duration(milliseconds: 450),
    //         // _animateDuration,
    //         child: Column(
    //           children: [
    //             Container( // duration: Duration(milliseconds: 450,),
    //               child: Row(
    //                 children: [
    //                   // SizedBox(width: 20,),
    //                   Expanded(flex: 5,child: SizedBox(),),
    //                   Expanded(flex: 10,
    //                     child: Padding(padding: EdgeInsets.only(top: 10),
    //                       child: _AppendIcon(data.Type, data.condition),
    //                     ), // Circle
    //                   ),
    //                   Expanded(flex: 50,
    //                     child: Padding(
    //                       padding: EdgeInsets.only(top: 20, left: 20),
    //                       child: Column(
    //                         children: [
    //                           Text(_cipherToMandarin(data.Type), style: TextStyle(fontSize: 30),),
    //                           Text('${data.created}', style: TextStyle(fontSize: 16),),
    //                         ],
    //                       ),
    //                     ), // Texts
    //                   ),
    //                   // SizedBox(width: 60,),
    //                   Expanded(flex: 10,
    //                     child: IconButton(
    //                     onPressed: () {
    //                       setState(() {
    //                         if (Extended == false) {
    //                           OpenDetail();
    //                         } else {
    //                           CloseDetail();
    //                         }
    //                         if (animationIcons.status==AnimationStatus.dismissed) {
    //                           this.animationIcons.reset();
    //                           this.animationIcons.animateTo(0.6);
    //                         } else {
    //                           this.animationIcons.reverse();
    //                         }
    //                       });
    //                     },
    //                     icon: Padding(
    //                       padding: const EdgeInsets.all(1.0),
    //                       child: Lottie.asset(
    //                         Icons8.expand,
    //                         controller: this.animationIcons,
    //                       ),
    //                     ),
    //                     // AnimatedIcon(
    //                     //   icon:
    //                     //   progress: _animationController,
    //                     // ),
    //                   ),
    //                   ), // Extend Button
    //                   Expanded(flex: 5,child: SizedBox(),),
    //                 ],
    //               ),
    //             ),
    //             // (!_Extended) ? Container() : SizedBox(height: 1, child: Container(color: Colors.grey,),) ,
    //             AnimatedContainer(
    //               padding: EdgeInsets.all(10),
    //               width: double.infinity,
    //               height: SizeDetail,
    //               duration: Duration(milliseconds: 450),
    //               child: Container( //color: Colors.amber,
    //                 padding: EdgeInsets.all(5),
    //                 child: Column(
    //                   crossAxisAlignment: CrossAxisAlignment.start,
    //                   children: [
    //                     Expanded(flex: 30,
    //                       child: Text(
    //                         '分類詳情：${data.special}', style: TextStyle(fontSize: 16),),
    //                     ),
    //                     Expanded(flex: 30,
    //                       child: Text(
    //                         value, style: TextStyle(fontSize: 16),),
    //                     ),
    //                     Expanded(flex: 30,
    //                       child: Text(
    //                         '其他詳情：${data.key_value}', style: TextStyle(fontSize: 16),),
    //                     ),
    //                   ],
    //                 ),
    //               ),
    //             ),
    //             // Detail
    //           ],
    //         ),
    //       ),
    //       SizedBox(height: 3,),
    //     ],
    //   );
    // }
    return Column(
      children: [
        AnimatedContainer(
          padding: EdgeInsets.symmetric(vertical: 5,),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(
              color: Colors.black38,
              offset: Offset(3.0, 3.0),
              blurRadius: 0,
              spreadRadius: 0,
            )
            ],
          ),
          width: double.infinity,
          height: SizeValue,
          // 100 or 250
          duration: Duration(milliseconds: 450),
          child: Column(
            children: [
              Container( // duration: Duration(milliseconds: 450,),
                child: Row(
                  children: [
                    // SizedBox(width: 20,),
                    Expanded(flex: 5,child: SizedBox(),),
                    Expanded(flex: 10,
                      child: Padding(padding: EdgeInsets.only(top: 10),
                        child: _AppendIcon(data.Type, data.condition),
                      ), // Circle
                    ),
                    Expanded(flex: 50,
                      child: Padding(
                        padding: EdgeInsets.only(top: 20, left: 20),
                        child: Column(
                          children: [
                            Text(_cipherToMandarin(data.Type), style: TextStyle(fontSize: 30),),
                            Text('${data.created}', style: TextStyle(fontSize: 16),),
                          ],
                        ),
                      ), // Texts
                    ),
                    // SizedBox(width: 60,),
                    Expanded(flex: 10,
                      child: IconButton(
                        onPressed: () {
                          setState(() {
                            if (Extended == false) {
                              OpenDetail();
                            } else {
                              CloseDetail();
                            }
                            if (animationIcons.status==AnimationStatus.dismissed) {
                              this.animationIcons.reset();
                              this.animationIcons.animateTo(0.6);
                            } else {
                              this.animationIcons.reverse();
                            }
                          });
                        },
                        icon: Padding(
                          padding: const EdgeInsets.all(1.0),
                          child: Lottie.asset(
                            Icons8.expand,
                            controller: this.animationIcons,
                          ),
                        ),
                        // AnimatedIcon(
                        //   icon:
                        //   progress: _animationController,
                        // ),
                      ),
                    ), // Extend Button
                    Expanded(flex: 5,child: SizedBox(),),
                  ],
                ),
              ),
              AnimatedContainer(
                padding: EdgeInsets.all(10),
                width: double.infinity,
                height: SizeDetail,
                duration: Duration(milliseconds: 450),
                child: Container( //color: Colors.amber,
                  padding: EdgeInsets.all(5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(flex: 30,
                        child: Text(
                          // '分類詳情：${data.special}'
                          Note1
                          , style: TextStyle(fontSize: 16),),
                      ),
                      Expanded(flex: 30,
                        child: Text(
                          Note2, style: TextStyle(fontSize: 16),),
                      ),
                      Expanded(flex: 30,
                        child: Text(
                          Note3, style: TextStyle(fontSize: 16),),
                      ),
                    ],
                  ),
                ),
              ),
              // Detail
            ],
          ),
        ),
        SizedBox(height: 3,),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return _enlist(widget.RECORD,/*widget.DATE*/);
  }

}

