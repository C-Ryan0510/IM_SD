import 'package:flutter/material.dart';
import './Record.dart';

import 'package:lottie/lottie.dart';
import 'package:flutter_animated_icons/icons8.dart';

class RecordWidget extends StatefulWidget {
  Record RECORD;
  DateTime DATE;
  RecordWidget({Key? key,required this.RECORD,required this.DATE}) : super(key: key);

  @override
  State<RecordWidget> createState() => _RecordWidgetState();
}

class _RecordWidgetState extends State<RecordWidget> with TickerProviderStateMixin {
  // int id; // ??
  late AnimationController animationController;
  late AnimationController animationIcons;

  bool Extended = false;
  double SizeValue = 100.0;
  double SizeDetail = 0.0;

  Future OpenDetail() async {
    SizeValue = 230.0;
    SizeDetail = 130.0;
    animationController.forward();
    this.Extended = true;
  }
  Future CloseDetail() async { // WHENEVER
    SizeValue = 100.0;
    SizeDetail = 0.0;
    animationController.reverse();
    this.Extended = false;
  }
  bool NotifyB = false;

  @override
  void initState() {
    super.initState();
    animationController = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    animationIcons = new AnimationController(vsync: this, duration: Duration(milliseconds: 450));
  }

  String _cipherToMandarin (String English) {
    late String out = '';
    switch (English) {
      case 'FoodRecord':
        out = '飲食紀錄';
        break;
      case 'DrugRecord':
        out = '用藥紀錄';
        break;
      case 'SugarRecord':
        out = '血糖紀錄';
        break;
      case 'ExerciseRecord':
        out = '運動紀錄';
        break;
      case 'TemperatureRecord':
        out = '體溫紀錄';
        break;
      case 'WaterRecord':
        out = '飲水紀錄';
        break;
      case 'PulseRecord':
        out = '血壓紀錄';
        break;
      case 'SleepRecord':
        out = '睡眠紀錄';
        break;
      case 'initial':
        out = '';
        break;
    // case 'InsulinTypes':
    //   out = '飲食紀錄';
    //   break;
      default:
        break;
    };
    return out;
  }
  Widget _AppendIcon (String TYPE,bool ABNORMAL) {
    late Widget Appearance;
    late Widget outPort;
    late Color condition;
    (ABNORMAL) ? condition = Colors.deepOrange : condition = Colors.green;
    switch (TYPE) {
      case 'FoodRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/eat_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'DrugRecord':
        Appearance = GestureDetector(
          onTap: () {
            if (NotifyB) {
              showDialog(
                context: context,
                builder: (BuildContext context) => AlertDialog(
                  title: Text('已向對方提醒用藥',),
                  actions: [
                    FlatButton(child: Text('確定'),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                  elevation: 24,
                ),
                barrierDismissible: false, // tap outside of it to dismiss
              );
            }
            setState(() {
              NotifyB = !NotifyB;
            });
          },
          child: (NotifyB) ?
          CircleAvatar(
            backgroundColor: Colors.amberAccent,
            child: ClipRRect(
              child: Image.asset('lib/asset/notification.png'),
              borderRadius: BorderRadius.circular(50.0),
            ),
          ):
          CircleAvatar(
            backgroundColor: condition,
            child: ClipRRect(
              child: Image.asset('lib/asset/drug_record.png'),
              borderRadius: BorderRadius.circular(50.0),
            ),
          ),
        );
        break;
      case 'SugarRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/bloodsugar_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'ExerciseRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/exercise_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'TemperatureRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/temperature_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'WaterRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/water_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'PulseRecord':
        Appearance = CircleAvatar(
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/pulse_record.png'),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
      case 'SleepRecord':
        Appearance = CircleAvatar(
          // radius: 16.0,
          backgroundColor: condition,
          child: ClipRRect(
            child: Image.asset('lib/asset/sleep_clock.png',),
            borderRadius: BorderRadius.circular(50.0),
          ),
        );
        break;
    // case 'InsulinTypes':
    //   Appearance = '飲食紀錄';
    //   break;
      default:
        break;
    };
    // (ABNORMAL) ?
    // outPort = GestureDetector(
    //   child: Appearance,
    // ) :
    // outPort = Appearance;

    return GestureDetector(
      child: Appearance,
    );
    // outPort
  }

  @override
  Widget build(BuildContext context) {
    return _enlist(widget.RECORD,widget.DATE);
  }

  Widget _enlist(Record data, DateTime sD) {
    // print(sD);
    // print(sD.year);
    // print(sD.month);
    // print(sD.day);
    String Y = sD.year.toString();
    String M = sD.month.toString();
    String D = sD.day.toString();

    String value = '';
    (data.amoute==null||data.amoute=='') ? value = '紀錄份量：${data.name}' : value = '紀錄份量：${data.name} - ${data.amoute}';

    if (data.year==Y&&data.month==M&&data.day==D) {
      return Column(
        children: [
          AnimatedContainer(
            padding: EdgeInsets.symmetric(vertical: 5,),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [BoxShadow(
                color: Colors.black38,
                offset: Offset(3.0, 3.0),
                blurRadius: 0,
                spreadRadius: 0,
              )
              ],
            ),
            width: double.infinity,
            height: SizeValue,
            // 100 or 250
            duration: Duration(milliseconds: 450),
            // _animateDuration,
            child: Column(
              children: [
                Container( // duration: Duration(milliseconds: 450,),
                  child: Row(
                    children: [
                      // SizedBox(width: 20,),
                      Expanded(flex: 5,child: SizedBox(),),
                      Expanded(flex: 10,
                        child: Padding(padding: EdgeInsets.only(top: 10),
                          child: _AppendIcon(data.Type, data.condition),
                        ), // Circle
                      ),
                      Expanded(flex: 50,
                        child: Padding(
                          padding: EdgeInsets.only(top: 20, left: 20),
                          child: Column(
                            children: [
                              Text(_cipherToMandarin(data.Type), style: TextStyle(fontSize: 30),),
                              Text('${data.created}', style: TextStyle(fontSize: 16),),
                            ],
                          ),
                        ), // Texts
                      ),
                      // SizedBox(width: 60,),
                      Expanded(flex: 10,
                        child: IconButton(
                        onPressed: () {
                          setState(() {
                            if (Extended == false) {
                              OpenDetail();
                            } else {
                              CloseDetail();
                            }
                            if (animationIcons.status==AnimationStatus.dismissed) {
                              this.animationIcons.reset();
                              this.animationIcons.animateTo(0.6);
                            } else {
                              this.animationIcons.reverse();
                            }
                          });
                        },
                        icon: Padding(
                          padding: const EdgeInsets.all(1.0),
                          child: Lottie.asset(
                            Icons8.expand,
                            controller: this.animationIcons,
                          ),
                        ),
                        // AnimatedIcon(
                        //   icon:
                        //   progress: _animationController,
                        // ),
                      ),
                      ), // Extend Button
                      Expanded(flex: 5,child: SizedBox(),),
                    ],
                  ),
                ),
                // (!_Extended) ? Container() : SizedBox(height: 1, child: Container(color: Colors.grey,),) ,
                AnimatedContainer(
                  padding: EdgeInsets.all(10),
                  width: double.infinity,
                  height: SizeDetail,
                  duration: Duration(milliseconds: 450),
                  child: Container( //color: Colors.amber,
                    padding: EdgeInsets.all(5),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(flex: 30,
                          child: Text(
                            '分類詳情：${data.special}', style: TextStyle(fontSize: 16),),
                        ),
                        Expanded(flex: 30,
                          child: Text(
                            value, style: TextStyle(fontSize: 16),),
                        ),
                        Expanded(flex: 30,
                          child: Text(
                            '其他詳情：${data.key_value}', style: TextStyle(fontSize: 16),),
                        ),
                      ],
                    ),
                  ),
                ),
                // Detail
              ],
            ),
          ),
          SizedBox(height: 3,),
        ],
      );
    }
    return Container();
  }

}

