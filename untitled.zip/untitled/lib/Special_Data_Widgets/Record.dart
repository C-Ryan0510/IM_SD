import 'package:cloud_firestore/cloud_firestore.dart';

class Record {
  String key_value;
  String Type;
  String? name;
  String? amoute;
  String? special;
  int? Goal;
  int? Times;
  bool condition;
  String year;
  String month;
  String day;
  String created; // DateTime

  Record({
    this.name,
    this.amoute,
    this.special,
    this.Goal,
    this.Times,
    required this.condition,
    required this.created,
    required this.Type,
    required this.key_value,
    required this.year,
    required this.month,
    required this.day,
  });

  Map<String, dynamic> toJson() => {
    'created': created,
    'year': year,
    'month': month,
    'day': day,

    'key_value': key_value,
    'Type': Type,
    'name': name,
    'amoute': amoute,
    'special': special,
    'isAbnormal': condition,
    'TodayGoal': Goal,
    'used_times': Times,
  };

  static Record fromJson(Map<String, dynamic> json) => Record(
    created: json['created'],
    year: json['year'],
    month: json['month'],
    day: json['day'],

    name: json['name'],
    amoute: json['amoute'],
    special: json['special'],
    Type: json['Type'],
    key_value: json['key_value'],
    condition: json['isAbnormal'],
    Goal: json['TodayGoal'],
    Times: json['used_times'],
  );
}
