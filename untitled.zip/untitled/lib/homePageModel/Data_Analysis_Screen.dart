import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:untitled/chartModels/charts_Dataset.dart';

import '../chartModels/line_chart.dart';
import '../chartModels/bar_chart.dart';
import '../chartModels/pie_chart.dart';

import 'package:charts_flutter/flutter.dart' as charts;

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({Key? key}) : super(key: key);

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {

  bool haveAnalysis = // false;
  true;

  final pressed = SnackBar(content: const Text('you Pressed that button'));
  final hold = SnackBar(content: const Text('you hold the button'));

  final _DefaultScreen = Container(height: 300,width: double.infinity,color:Colors.grey.shade100,
    child: Align(alignment: Alignment.center,
      child: Text('你還沒有做任何生活紀錄',style: TextStyle(fontSize: 30),),
    ),
  );

  CalendarFormat format = CalendarFormat.month;
  DateTime selectedDay = DateTime.now();
  DateTime focusedDay = DateTime.now();

  final List<BarDataset> data1 = [
    BarDataset(
      domain: 'march',
      value: 10,
      color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
    BarDataset(
      domain: 'april',
      value: 30,
      color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
    BarDataset(
      domain: 'may',
      value: 60,
      color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
  ];
  final List<PieDataset> data2 = [
    PieDataset(
      domain: 'march',
      value: 10,
      color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
    PieDataset(
      domain: 'april',
      value: 30,
      color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
    PieDataset(
      domain: 'may',
      value: 60,
      color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
  ];
  final List<LineDataset> data3 = [
    LineDataset(
      domain: 100,
      value: 10,
      // color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
    LineDataset(
      domain: 300,
      value: 30,
      // color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
    LineDataset(
      domain: 500,
      value: 40,
      // color: charts.ColorUtil.fromDartColor(Colors.blue),
    ),
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(padding: EdgeInsets.only(top: 60,right: 10,left: 10,),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: HexColor('#305C54')),
              ),
              child: TableCalendar(
                firstDay: DateTime(1950),
                lastDay: DateTime(2050),
                focusedDay: DateTime.now(),

                //Calendar Sizes' [2weeks, a week,mouth(4weeks)]
                calendarFormat: format,
                onFormatChanged: (CalendarFormat _format) {
                  setState(() {//set Calendar to next size(show on button)
                    format = _format;
                  });
                },
                //onPress
                selectedDayPredicate: (DateTime date){//Date Select action
                  return isSameDay(selectedDay, date);
                },
                onDaySelected: (DateTime selectDay,DateTime focusDay) {
                  setState(() {//Date select States
                    selectedDay = selectDay;
                    focusedDay = focusDay;
                  });
                  print(focusedDay);//print on console
                },

                startingDayOfWeek: StartingDayOfWeek.sunday,
                daysOfWeekVisible: true,
                //Style
                calendarStyle: CalendarStyle(isTodayHighlighted: true,
                  selectedDecoration: BoxDecoration(
                    color: Color.fromRGBO(45, 224, 213, 100),
                    shape: BoxShape.circle,
                  ),
                  selectedTextStyle: TextStyle(color: Colors.white),
                  todayDecoration: BoxDecoration(
                      color: Colors.grey,
                      shape: BoxShape.circle
                  ),
                ),
                headerStyle: HeaderStyle(
                  // formatButtonVisible: false,// default is true
                  formatButtonShowsNext: false,// false = current Size
                  formatButtonDecoration: BoxDecoration(
                    color: Color.fromRGBO(45, 224, 213, 100),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  formatButtonTextStyle: TextStyle(
                    color: Colors.black,
                  ),
                  // leftChevronVisible: false,//cancel <--
                  // rightChevronVisible: false,//cancel -->
                ),
              ),
            ),
            SizedBox(height: 5,), // current
            SizedBox(height: 40,), // current
            SizedBox(height: 5,), // current
            haveAnalysis ?
            Container(height: 250, width: double.infinity,
              // color:Colors.grey.shade100,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: HexColor('#305C54')),
              ),
              child: Padding(padding: EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                child: PageView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Container( // color: Colors.grey,
                      child: BarChart(data: data1),
                    ),
                    Container( // color: Colors.grey,
                      child: PieChart(data: data2),
                    ),
                    Container( // color: Colors.grey,
                      child: LineChart(data: data3),
                    ),
                  ],
                ),
              ),
            ) :
            _DefaultScreen,
          ],
        ),
      ),
    );
  }
}


class _AnalysisOutcome extends StatelessWidget {
  // final String imagePath;
  // final String ItemData;

  // _AnalysisOutcome({required this.imagePath, required this.ItemData});
  _AnalysisOutcome({Key? key});

  @override
  Widget build(BuildContext context) {
    return Container(height: double.infinity,width:150,color: Colors.grey,);
    // Center(
    //   child: Container(
    //     // color: Colors.transparent,
    //     color: Colors.white,
    //     child: OutlinedButton(
    //       style: OutlinedButton.styleFrom(
    //         shape: RoundedRectangleBorder(
    //           borderRadius: BorderRadius.circular(15),
    //         ),
    //         // side: BorderSide(width: 5,color: Colors.grey),
    //       ),
    //       onPressed: () {},//navigator-->otherPage
    //       child: Column(
    //         mainAxisAlignment: MainAxisAlignment.center,
    //         children: [
    //           Image.asset('$imagePath',),
    //           Text(
    //             '$ItemData',
    //             style: TextStyle(
    //                 backgroundColor: Colors.transparent,
    //                 color: Colors.black,
    //                 fontSize: 16,
    //                 fontWeight: FontWeight.bold
    //             ),
    //           )
    //         ],
    //       ),
    //     ),
    //   ),
    // );
  }
}
