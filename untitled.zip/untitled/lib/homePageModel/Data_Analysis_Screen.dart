import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:flutter/material.dart';

// import '../chartModels/line_chart.dart';
// import '../chartModels/bar_chart.dart';
// import '../chartModels/pie_chart.dart';
// import 'package:charts_flutter/flutter.dart' as charts;

import 'package:untitled/Pages/splash.dart';

import '../Special_Data_Widgets/Record.dart';
import '../Special_Data_Widgets/RecordWidget.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({Key? key}) : super(key: key);

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {

  bool haveAnalysis = false;
  // true;

  final pressed = SnackBar(content: const Text('you Pressed that button'));
  final hold = SnackBar(content: const Text('you hold the button'));

  final _DefaultScreen = Container(height: 300,width: double.infinity,color:Colors.grey.shade100,
    child: Align(alignment: Alignment.center,
      child: Text('沒有任何生活紀錄',style: TextStyle(fontSize: 30),),
    ),
  );

  CalendarFormat format = CalendarFormat.month;
  DateTime selectedDay = DateTime.now();
  DateTime focusedDay = DateTime.now();

  // final List<BarDataset> data1 = [
  //   BarDataset(
  //     domain: 'march',
  //     value: 10,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   BarDataset(
  //     domain: 'april',
  //     value: 30,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   BarDataset(
  //     domain: 'may',
  //     value: 60,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];
  // final List<PieDataset> data2 = [
  //   PieDataset(
  //     domain: 'march',
  //     value: 10,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   PieDataset(
  //     domain: 'april',
  //     value: 30,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   PieDataset(
  //     domain: 'may',
  //     value: 60,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];
  // final List<LineDataset> data3 = [
  //   LineDataset(
  //     domain: 100,
  //     value: 10,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 300,
  //     value: 30,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 500,
  //     value: 40,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];

  final user = FirebaseAuth.instance.currentUser!.email.toString();
  final dataB = FirebaseFirestore.instance.collection('Health');

  Stream<List<Record>> showRecords() => FirebaseFirestore.instance
      .collection('Health').doc(FirebaseAuth.instance.currentUser!.email.toString())
      .collection('Records').orderBy('created',descending: false)
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) => Record
      .fromJson(doc.data())).toList(),
  );

  // double _CurrentRecordsSize = 282.0; Expanded

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(padding: EdgeInsets.only(top: 60,right: 20,left: 20,bottom: 10,),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: HexColor('#305C54')),
              ),
              child: TableCalendar(
                // locale: 'zh_CN',
                firstDay: DateTime(1950),
                lastDay: DateTime(2050),
                focusedDay: selectedDay,
                currentDay: DateTime.now(), // today Always

                //Calendar Sizes' [2weeks, a week,mouth(4weeks)]
                calendarFormat: format,
                onFormatChanged: (CalendarFormat _format) {
                  setState(() { // set Calendar to next size(show on button)
                    format = _format;
                    // print(_format);
                    // switch(format) {
                    //   case CalendarFormat.month:
                    //     _CurrentRecordsSize = 282.0;
                    //     break;
                    //   case CalendarFormat.twoWeeks:                        _CurrentRecordsSize = 250.0;
                    //     _CurrentRecordsSize = 438.0;
                    //     break;
                    //   case CalendarFormat.week:                        _CurrentRecordsSize = 400.0;
                    //     _CurrentRecordsSize = 490.0;
                    //     break;
                    // }
                  });
                },

                //onPress
                onDaySelected: (DateTime selectDay,DateTime focusDay) {
                  setState(() { // Date select States
                    selectedDay = selectDay; // AnyDate on tap
                    focusedDay = focusDay; // 只限當月，跨月會到當月上/下限
                  });
                  print(selectedDay); // print on console
                  print(focusedDay); // print on console
                },
                // onDisabledDayTapped: ,
                selectedDayPredicate: (DateTime date){ // Date Select action
                  return isSameDay(selectedDay, date);
                },
                startingDayOfWeek: StartingDayOfWeek.sunday,
                daysOfWeekVisible: true,

                //Style
                calendarStyle: CalendarStyle(isTodayHighlighted: true,
                  selectedDecoration: BoxDecoration(
                    color: Colors.greenAccent,
                    shape: BoxShape.circle,
                  ),
                  selectedTextStyle: TextStyle(color: Colors.white),
                  todayDecoration: BoxDecoration(
                    color: Colors.grey,
                    shape: BoxShape.circle,
                  ),
                  weekendTextStyle: TextStyle(color: Colors.red),
                ),
                headerStyle: HeaderStyle(
                  // formatButtonVisible: false,// default is true
                  formatButtonShowsNext: false,// false = current Size
                  formatButtonDecoration: BoxDecoration(
                    color: Colors.greenAccent,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  formatButtonTextStyle: TextStyle(
                    color: Colors.black,
                  ),
                  // leftChevronVisible: false,//cancel <--
                  // rightChevronVisible: false,//cancel -->
                ),
              ),
            ),
            Expanded(flex: 12,child: SizedBox(height: 10,),),
            Expanded(flex: 85,child: AnimatedContainer(
              duration: Duration(milliseconds: 200), // to make sure not overflow
              // height: _CurrentRecordsSize, Expanded
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: HexColor('#305C54')),),
              child: StreamBuilder<List<Record>>(
                stream: showRecords(),
                builder: (context, snapshotT) {
                  if(snapshotT.hasError){
                    // print(snapshotT.data);
                    // print(snapshotT);
                    // print(FirebaseAuth.instance.currentUser!.email.toString());
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black38,
                            offset: Offset(3.0, 3.0),
                            blurRadius: 0,
                            spreadRadius: 0,
                          ),
                        ],
                      ),
                      width: double.infinity,height: 100,
                      child: Center(child: Text('無法載入正確資料\n${snapshotT.data.toString()}\n${snapshotT.error}'),),
                    );
                  } else if (snapshotT.hasData) {
                    final dataList = snapshotT.data!;
                    // print(dataList);
                    List<Record>TodayList = [];
                    for(Record check in dataList){
                      String CurY = selectedDay.year.toString();
                      String CurM = selectedDay.month.toString();
                      String CurD = selectedDay.day.toString();
                      if (CurY==check.year&&CurM==check.month&&CurD==check.day) {
                        TodayList.add(check);
                      }
                    }
                    // print(TodayList);
                    if (TodayList.isEmpty) {
                      return Padding(padding: EdgeInsets.all(5),
                        child: Card(
                          elevation: 12,
                          child: Center(
                            child: Text('今天尚未做任何紀錄', style: TextStyle(fontSize: 30,),),
                          ),
                        ),
                      );
                    } else {
                      return ListView(
                        children: [
                          // for(Record t in dataL) _enlist(t, selectedDay), //
                          for(Record t in TodayList) RecordWidget(RECORD: t,),
                          // ElevatedButton(
                          //   child: Text('Test'),
                          //   onPressed: () => Navigator.push(
                          //     context,
                          //     MaterialPageRoute(builder: (_) => Splash()),
                          //   ),
                          // ),
                        ],
                      );
                    }
                  } else {
                    return Center(child: CircularProgressIndicator(),);
                  }
                },
              ),
            ),),
          ],
        ),
      ),
    );
  }
}

