import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:untitled/Pages/splash.dart';

// import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class SSScreen extends StatefulWidget {
  const SSScreen({Key? key}) : super(key: key);

  @override
  State<SSScreen> createState() => _SSScreenState();
}

class _SSScreenState extends State<SSScreen> {

  final test = Container(
    height: 200,
    width: double.infinity,
    color: Colors.grey.shade100,
    child: Icon(Icons.add),
  );

  @override
  void initState() {
    super.initState();
    // Enable virtual display.
    // if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 70, right: 45,left: 45,bottom: 10),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              flex: 1,
              child: Container( height: 200, width: 280,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  border: Border.all(color: HexColor('#305C54')),
                ),
                child: OutlinedButton(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('門口偵測',
                        style: TextStyle(
                          backgroundColor: Colors.transparent,
                          color: Colors.black,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10,),
                      Icon(Icons.camera_alt,size: 60,color: HexColor('#305C54'),),
                    ],
                  ),
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    // side: BorderSide(width: 5,color: Colors.grey),
                  ),
                  onPressed: () => {

                  },
                ),
              ),
            ),
            SizedBox(height: 10,),
            Expanded(
              flex: 1,
              child: Container( height: 200, width: 280,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  border: Border.all(color: HexColor('#305C54')),
                ),
                child: OutlinedButton(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('聲音監控',
                        style: TextStyle(
                          backgroundColor: Colors.transparent,
                          color: Colors.black,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10,),
                      Icon(Icons.camera_alt,size: 60,color: HexColor('#305C54'),),
                    ],
                  ),
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    // side: BorderSide(width: 5,color: Colors.grey),
                  ),
                  onPressed: () => {

                  },
                ),
              ),
            ),
            SizedBox(height: 10,),
            Expanded(
              flex: 1,
              child: Container( height: 200, width: 280,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  border: Border.all(color: HexColor('#305C54')),
                ),
                child: OutlinedButton(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('跌倒偵測',
                        style: TextStyle(
                          backgroundColor: Colors.transparent,
                          color: Colors.black,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10,),
                      Icon(Icons.camera_alt,size: 60,color: HexColor('#305C54'),),
                    ],
                  ),
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    // side: BorderSide(width: 5,color: Colors.grey),
                  ),
                  onPressed: () => {

                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

