import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:charts_flutter/flutter.dart' as charts;
import 'package:untitled/chartModels/bar_chart.dart';
import 'package:untitled/chartModels/line_chart.dart';

import '../Pages/Web.dart';
import '../Special_Data_Widgets/Family.dart';
import 'FamilyScreen.dart';

class mainHome extends StatefulWidget {
  const mainHome({Key? key}) : super(key: key);

  @override
  State<mainHome> createState() => _mainHomeState();
}

class _mainHomeState extends State<mainHome> {

  final UserID = FirebaseAuth.instance.currentUser!.email.toString();

  final MonitorsC = PageController(initialPage: 0,);
  final NEWSC = PageController(initialPage: 0,);

  final SignalOut = Center(child: Text('No Signal',style: TextStyle(fontSize: 24),),);
  final LoadFail = Center(child: Text('無法載入',style: TextStyle(fontSize: 24),),);
  final AddDevice = Column(//==>add Device Page
    children: [
      SizedBox(height: 50,),
      Center(child: IconButton(icon: Icon(Icons.add_circle_outlined,size: 24,color: Colors.blueGrey,), onPressed: () => null,),),
      Center(child: Text('新增裝置'),),
    ],
  );

  final homeDecoration = BoxDecoration(border: Border.all(color: Color.fromRGBO(48, 92, 84, 100),),borderRadius: BorderRadius.circular(24),);
  final _JustcardDesign = Card(child: SizedBox(
    width: 135,height: 100,
    child: Stack(
      children: [
        Align(alignment: Alignment.topCenter,child: CircleAvatar(child: Icon(Icons.self_improvement),),),
        Align(alignment: Alignment.center,child: Center(child: Text('state\nonline'),),),
      ],
    ),
  ),);
  final _Default = Padding(padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
    child: InkWell(
      onTap: () { },
      child: Center(
        child: Text(''),
      ),
    ),
  );

  Widget AvatarIcon(String gender) {
    switch(gender.toLowerCase()){
      case'male':
        return Icon(Icons.man,size: 30,);
      case'female':
        return Icon(Icons.woman,size: 30,);
      default:
        return Icon(Icons.reddit_outlined ,size: 30,);
    }
  }
  Widget buildList(Family data) {
    return Card(
      child: SizedBox(
        width: 135,height: 100,
        child: Stack(
          children: [
            Align(alignment: Alignment.topCenter,
              child: CircleAvatar(
                child: (data.picpath==''||data.picpath==null) ?
                AvatarIcon(data.gender.toString()) :
                ClipRRect(
                  child: Image.network(data.picpath.toString()),
                  borderRadius: BorderRadius.circular(50),
                ),
                backgroundColor: Colors.white70,
              ),
            ),
            Align(alignment: Alignment.center,
              child: Center(child: (data.name != null) ?
                Text('${data.name}',style: TextStyle(fontSize: 30),):
                Text('${data.mail}',style: TextStyle(fontSize: 10),),
              ),
            ),
          ],
        ),
      ),
    );
  }
  // Family
  // get group_id User have
  Future<UserData?> checkSelfHaveGroup() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Users_Profile').doc(UserID).get();
    if (snapshot.exists) {
      return UserData.fromJson(snapshot.data()!);
    }
  }
  // get member by Same group_id maybe members
  Stream<List<Family>> getMember() => FirebaseFirestore.instance
      .collection('Users_Profile')
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) =>
      Family.fromJson(doc.data())).toList()
  );

  @override
  void initState() {
    super.initState();
  }

  // final List<BarDataset> data1 = [
  //   BarDataset(
  //     domain: '早餐',
  //     value: 5,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   BarDataset(
  //     domain: '午餐',
  //     value: 30,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   BarDataset(
  //     domain: '晚餐',
  //     value: 100,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   BarDataset(
  //     domain: '消夜',
  //     value: 75,
  //     color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];
  // final List<LineDataset> data2 = [
  //   LineDataset(
  //     domain: 100,
  //     value: 10,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 300,
  //     value: 30,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 500,
  //     value: 40,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];
  // final List<LineDataset> data3 = [
  //   LineDataset(
  //     domain: 100,
  //     value: 10,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 300,
  //     value: 30,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  //   LineDataset(
  //     domain: 500,
  //     value: 40,
  //     // color: charts.ColorUtil.fromDartColor(Colors.blue),
  //   ),
  // ];
  final testCondition = true;

  @override
  Widget build(BuildContext context) {
    return Padding(padding: EdgeInsets.only(top: 70,right: 50,left: 50,bottom: 10),
      child: Column(
        children: [
          Align(alignment:Alignment.centerLeft,child: Text('最新消息',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100)),),),
          Expanded(
            flex: 3,
            child: Container(height: 200,width:double.infinity,
              // color: Colors.grey,
              decoration: homeDecoration,
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Stack(
                  children: [
                    PageView(
                      controller: NEWSC,
                      scrollDirection: Axis.horizontal,
                      children: [
                        InkWell(
                          onTap: () { Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) =>WebViewExample(url: 'https://health.ltn.com.tw/article/breakingnews/4041000'),
                            ),
                          );},
                          child: Ink(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(20.0),
                              child: Image.network('https://img.ltn.com.tw/Upload/health/page/800/2022/08/29/phpsGWwbg.jpg',),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () { Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) =>WebViewExample(url: 'https://tw.news.yahoo.com/10年追蹤50萬人-茶飲這樣喝-死亡率降13-103847398.html'),
                            ),
                          );},
                          child: Ink(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(20.0),
                              child: Image.network('https://s.yimg.com/ny/api/res/1.2/Zz1cLpQPV3KpsiBvJuAhjA--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTcyMDtjZj13ZWJw/https://s.yimg.com/uu/api/res/1.2/CEO1bbTB9TLyQ8dlUv.QYw--~B/aD05MDA7dz0xMjAwO2FwcGlkPXl0YWNoeW9u/https://media.zenfs.com/zh-tw/bcc.com.tw/01951124dc9b17764c2d815972047c88',),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () { Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) =>WebViewExample(url: ''),
                            ),
                          );},
                          child: Ink(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(20.0),
                              child: Image.network('https://www.mohw.gov.tw/xslGip/Unit001/images/logo.png',),
                            ),
                          ),
                        ),
                        // Container(color: Colors.grey.withOpacity(0.2),child: (testCondition)? (testCondition)? SignalOut:LoadFail:AddDevice,),
                        // Container(color: Colors.grey.withOpacity(0.2),child: (testCondition)? (false)? SignalOut:LoadFail:AddDevice,),
                        // Container(color: Colors.grey.withOpacity(0.2),child: (false)? (testCondition)? SignalOut:LoadFail:AddDevice,),
                      ],
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: SmoothPageIndicator(
                        controller: NEWSC,
                        count: 3,// NEWS count (should be add into firebase)
                        effect: ExpandingDotsEffect(),
                        // WormEffect(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Align(alignment:Alignment.centerLeft,child: Text('家人快訊',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100)),),),
          Expanded(
            flex: 7,
            child: Container(height: 400,width:double.infinity,
              // color: Colors.grey.withOpacity(0.3),
              decoration: homeDecoration,
              padding: EdgeInsets.all(10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 4,
                    child: Container(width: double.infinity,
                    // color: Colors.amber.withOpacity(0.2),
                    child: StreamBuilder<List<Family>>(
                      stream: getMember(),
                      builder: (context, snapshot2) {
                        if (snapshot2.hasError) {
                          return Center(child: Text(snapshot2.error.toString(),),);
                        } else if (snapshot2.hasData) {
                          return FutureBuilder<UserData?> (
                            future: checkSelfHaveGroup(),
                            builder: (context, snapshot) {
                              if(snapshot.hasError) {
                                return Center(child: Text(snapshot.error.toString(),),);
                              } else if(snapshot.hasData) {
                                final data = snapshot.data!;
                                final users = snapshot2.data!;
                                List<Family> checkEmpty = [];
                                for(Family target in users) {
                                  if (target.GIDcheck==data.groupID&&target.mail!=data.ID){
                                    if (target.GIDcheck!=''&&target.GIDcheck!=null) {
                                      checkEmpty.add(target);
                                    }
                                  };
                                }
                                if (data==null||data.groupID==''){
                                  return Container(
                                    // padding: EdgeInsets.all(10),
                                    child: _Default, //_JustcardDesign,
                                  );
                                } else if (users.isEmpty||checkEmpty.isEmpty) {
                                  return Container(
                                    // padding: EdgeInsets.all(10),
                                    child: _Default, //_JustcardDesign,
                                  );
                                } else {
                                  return GridView( // scrollDirection: Axis.horizontal,
                                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,),
                                    children: [for(Family f in checkEmpty) buildList(f)],
                                  );
                                }
                              } else {
                                return Center(child: CircularProgressIndicator(),); // loading
                              }
                            },
                          );
                        } else {
                          return Center(child: CircularProgressIndicator(),);
                        }
                      },
                    ),
                  ),
                  ),
                  // SizedBox(height: 20,),
                  // Expanded(
                  //   flex: 6,
                  //   child: Container(width:double.infinity,
                  //   // color: Colors.amber,
                  //   child:
                  //   Stack(
                  //     children: [
                  //       PageView(
                  //         controller: MonitorsC,
                  //         scrollDirection: Axis.horizontal,
                  //         children: [
                  //           Container( // color: Colors.grey,
                  //             child: BarChart(data: data1),
                  //           ),
                  //           // Container(color: Colors.grey.withOpacity(0.2),child: SignalOut,),
                  //           Container(color: Colors.grey.withOpacity(0.2),child: LoadFail,),
                  //           // Container(color: Colors.grey.withOpacity(0.2),child: AddDevice,),
                  //           Container( // color: Colors.grey,
                  //             child: LineChart(data: data3),
                  //           ),
                  //         ],
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  // ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _newsItems extends StatelessWidget{
  final String text;
  final String imagePath;
  // final String url;
  _newsItems({required this.text, required this.imagePath, /*required this.url*/});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.3),
      ),
      padding: EdgeInsets.all(15),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Center(child: Image.asset('$imagePath',fit: BoxFit.contain,),),
          Positioned(child: Text('$text',style: TextStyle(fontSize: 24),),bottom: 5,left: 10,),
        ],
      ),
    );
  }
}

class UserData {
  String? name;    // check with other name and hide self detail
  String? ID;      // check if is creator???
  String? groupID; // check which group

  UserData({
    this.name,
    this.ID,
    this.groupID,
  });

  Map<String, dynamic> toJson() => {
    'user_name': name,
    'user_ID/account': ID,
    'group_id': groupID,
  };

  static UserData fromJson(Map<String, dynamic> json) => UserData(
    ID: json['user_ID/account'],
    name: json['user_name'],
    groupID: json['group_id'],
  );
}