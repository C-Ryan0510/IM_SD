import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class mainHome extends StatefulWidget {
  const mainHome({Key? key}) : super(key: key);

  @override
  State<mainHome> createState() => _mainHomeState();
}

class _mainHomeState extends State<mainHome> {

  final UserID = FirebaseAuth.instance.currentUser!.email.toString();

  final MonitorsC = PageController(initialPage: 0,);
  final NEWSC = PageController(initialPage: 0,);

  final SignalOut = Center(child: Text('No Signal',style: TextStyle(fontSize: 24),),);
  final LoadFail = Center(child: Text('無法載入',style: TextStyle(fontSize: 24),),);
  final AddDevice = Column(//==>add Device Page
    children: [
      SizedBox(height: 50,),
      Center(child: IconButton(icon: Icon(Icons.add_circle_outlined,size: 24,color: Colors.blueGrey,), onPressed: () => null,),),
      Center(child: Text('新增裝置'),),
    ],
  );

  final homeDecoration = BoxDecoration(border: Border.all(color: Color.fromRGBO(48, 92, 84, 100),),borderRadius: BorderRadius.circular(24),);
  Widget AvatarIcon(String gender) {
    switch(gender.toLowerCase()){
      case'male':
        return Icon(Icons.man,size: 30,);
      case'female':
        return Icon(Icons.woman,size: 30,);
      default:
        return Icon(Icons.reddit_outlined ,size: 30,);
    }
  }
  final familyCard = Card(child: SizedBox(
    width: 135,
    height: 100,
    child: Center(child: Text('Family Member')),
  ),);
  final JustcardDesign = Card(child: SizedBox(
    width: 135,height: 100,
    child: Stack(
      children: [
        Align(alignment: Alignment.topCenter,child: CircleAvatar(child: Icon(Icons.self_improvement),),),
        Align(alignment: Alignment.center,child: Center(child: Text('state\nonline'),),),
      ],
    ),
  ),
  );
  Widget buildList(Family data) {
    return Card(
      child: SizedBox(
        width: 135,height: 100,
        child: Stack(
          children: [
            Align(alignment: Alignment.topCenter,
              child: CircleAvatar(
                child: (data.picpath==''||data.picpath==null) ?
                AvatarIcon(data.gender.toString()) :
                ClipRRect(
                  child: Image.network(data.picpath.toString()),
                  borderRadius: BorderRadius.circular(50),
                ),
              ),
            ),
            Align(alignment: Alignment.center,
              child: Center(child: Text('${data.name}',style: TextStyle(fontSize: 30),),
              ),
            ),
          ],
        ),
      ),
    );
    //   ListTile(
    //   leading: CircleAvatar(
    //     child: (data.picpath==''||data.picpath==null) ?
    //     AvatarIcon(data.gender.toString()) :
    //     ClipRRect(
    //       child: Image.network(data.picpath.toString()),
    //       borderRadius: BorderRadius.circular(50),
    //     ),
    //     backgroundColor: Colors.white,
    //   ),
    //   title: Text(data.name.toString()),
    //   subtitle: Text(data.mail.toString()),
    //   onTap: null,
    // );
  }
  // Family
  // get group_id User have
  Future<UserData?> checkSelfHaveGroup() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Users_Profile').doc(UserID).get();
    if (snapshot.exists) {
      return UserData.fromJson(snapshot.data()!);
    }
  }
  // get member by Same group_id maybe members
  Stream<List<Family>> getMember() => FirebaseFirestore.instance
      .collection('Users_Profile')
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) =>
      Family.fromJson(doc.data())).toList()
  );

  @override
  void initState() {
    super.initState();
  }

  final testCondition = true;

  @override
  Widget build(BuildContext context) {
    return Padding(padding: EdgeInsets.only(top: 70,right: 50,left: 50,bottom: 10),
      child: Column(
        children: [
          Align(alignment:Alignment.centerLeft,child: Text('最新消息',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100)),),),
          Expanded(
            flex: 3,
            child: Container(height: 200,width:double.infinity,
              // color: Colors.grey,
              decoration: homeDecoration,
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Stack(
                  children: [
                    PageView(
                      controller: NEWSC,
                      scrollDirection: Axis.horizontal,
                      children: [
                        Container(color: Colors.grey.withOpacity(0.2),child: (testCondition)? (testCondition)? SignalOut:LoadFail:AddDevice,),
                        Container(color: Colors.grey.withOpacity(0.2),child: (testCondition)? (false)? SignalOut:LoadFail:AddDevice,),
                        Container(color: Colors.grey.withOpacity(0.2),child: (false)? (testCondition)? SignalOut:LoadFail:AddDevice,),
                      ],
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: SmoothPageIndicator(
                        controller: NEWSC,
                        count: 3,//Monitor count
                        effect: ExpandingDotsEffect(),
                        // WormEffect(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Align(alignment:Alignment.centerLeft,child: Text('快訊',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100)),),),
          Expanded(
            flex: 7,
            child: Container(height: 400,width:double.infinity,
              // color: Colors.grey.withOpacity(0.3),
              decoration: homeDecoration,
              padding: EdgeInsets.all(10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 4,
                    child: Container(width: double.infinity,
                    // color: Colors.amber.withOpacity(0.2),
                    child: StreamBuilder<List<Family>>(
                      stream: getMember(),
                      builder: (context, snapshot2) {
                        if (snapshot2.hasError) {
                          return Center(child: Text(snapshot2.error.toString(),),);
                        } else if (snapshot2.hasData) {
                          return FutureBuilder<UserData?> (
                            future: checkSelfHaveGroup(),
                            builder: (context, snapshot) {
                              if(snapshot.hasError) {
                                return Center(child: Text(snapshot.error.toString(),),);
                              } else if(snapshot.hasData) {
                                final data = snapshot.data!;
                                final users = snapshot2.data!;
                                List<Family> checkEmpty = [];
                                for(Family target in users) {
                                  // print(target.GIDcheck);
                                  // print(target.mail);
                                  // print(data.groupID);
                                  // print(checkEmpty.toString());
                                  if (target.GIDcheck==data.groupID&&target.mail!=data.ID){
                                    checkEmpty.add(target);
                                  };
                                }
                                if (data==null||data.groupID==''){
                                  return Padding(
                                    padding: EdgeInsets.only(top: 50),
                                    child: Container(
                                      padding: EdgeInsets.symmetric(vertical: 10),
                                      child: JustcardDesign,
                                    ),
                                  );
                                } else if (users.isEmpty||checkEmpty.isEmpty) {
                                  return Padding(
                                    padding: EdgeInsets.only(top: 50),
                                    child: Container(
                                      padding: EdgeInsets.symmetric(vertical: 10),
                                      child: JustcardDesign,
                                    ),
                                  );
                                } else {
                                  // print(checkEmpty);
                                  // return GridView( scrollDirection: Axis.horizontal,
                                  //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:1,mainAxisSpacing: 10,crossAxisSpacing: 10),
                                  //   children: [for(Family f in checkEmpty) buildList(f)],
                                  return ListView(scrollDirection: Axis.horizontal,
                                    children: [for(Family f in checkEmpty) buildList(f)],
                                      // ),
                                  );
                                }
                              } else {
                                return Center(child: CircularProgressIndicator(),); // loading
                              }
                            },
                          );
                        } else {
                          return Center(child: CircularProgressIndicator(),);
                        }
                      },
                    ),
                  ),
                  ),
                  SizedBox(height: 20,),
                  Expanded(
                    flex: 6,
                    child: Container(width:double.infinity,
                    // color: Colors.amber,
                    child:
                    Stack(
                      children: [
                        // TabPageSelector(),
                        PageView(
                          controller: MonitorsC,
                          scrollDirection: Axis.horizontal,
                          children: [
                            Container(color: Colors.grey.withOpacity(0.2),child: SignalOut,),
                            Container(color: Colors.grey.withOpacity(0.2),child: LoadFail,),
                            Container(color: Colors.grey.withOpacity(0.2),child: AddDevice,),
                          ],
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: SmoothPageIndicator(
                            controller: MonitorsC,
                            count: 3,//Monitor count
                            effect: ExpandingDotsEffect(),
                            // WormEffect(),
                          ),
                        ),
                      ],
                    ),
                  ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _newsItems extends StatelessWidget{
  final String text;
  final String imagePath;
  // final String url;
  _newsItems({required this.text, required this.imagePath, /*required this.url*/});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.3),
      ),
      padding: EdgeInsets.all(15),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Center(child: Image.asset('$imagePath',fit: BoxFit.contain,),),
          Positioned(child: Text('$text',style: TextStyle(fontSize: 24),),bottom: 5,left: 10,),
        ],
      ),
    );
  }
}


class Family {
  String? name;    // title
  String? mail;    // subtitle ??? or check if is CurrentUser
  String? gender;
  String? picpath; // Pic
  String? GIDcheck;// check group_id is same

  Family({
    this.picpath,
    this.gender,
    required this.name,
    required this.mail,
    required this.GIDcheck,
  });

  Map<String, dynamic> toJson() => {
    'user_name': name,
    'user_ID/account': mail,
    'user_gender': gender,
    'user_avatar': picpath,
    'group_id': GIDcheck,
  };

  static Family fromJson(Map<String, dynamic> json) => Family(
    mail: json['user_ID/account'],
    picpath: json['user_avatar'],
    name: json['user_name'],
    GIDcheck: json['group_id'],
    gender: json['user_gender'],
  );
}

class UserData {
  String? name;    // check with other name and hide self detail
  String? ID;      // check if is creator???
  String? groupID; // check which group

  UserData({
    this.name,
    this.ID,
    this.groupID,
  });

  Map<String, dynamic> toJson() => {
    'user_name': name,
    'user_ID/account': ID,
    'group_id': groupID,
  };

  static UserData fromJson(Map<String, dynamic> json) => UserData(
    ID: json['user_ID/account'],
    name: json['user_name'],
    groupID: json['group_id'],
  );
}