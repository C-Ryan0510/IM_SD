import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class FGroupScreen extends StatefulWidget {
  const FGroupScreen({Key? key}) : super(key: key);

  @override
  State<FGroupScreen> createState() => _FGroupScreenState();
}

class _FGroupScreenState extends State<FGroupScreen> {

  final test = Container(height: double.infinity,width: double.infinity,color: Colors.lightBlueAccent,child: Text('Family'),);

  final PersonDecro = BoxDecoration(color: Colors.blueGrey.shade200);

  final pressed = SnackBar(content: const Text('you Pressed that button'));
  final hold = SnackBar(content: const Text('you hold the button'));

  //??No family
  final _DefaultScreen = Container(height: 1000,width: double.infinity, // color:Colors.grey.shade100,
    child: Align(alignment: Alignment.center,
      child: Text('你還沒建立群組',style: TextStyle(fontSize: 30),),
    ),
  );

  final _errMsg = Container(
    height: 1000,width: double.infinity, // color:Colors.grey.shade100,
    child: Text('Something went wrong!'),
  );

  // Firebase
  final user = FirebaseAuth.instance.currentUser!;//當前登入帳戶for info

  Stream<List<Family>> readFamily() => FirebaseFirestore.instance
      .collection('Users_Profile').doc(user.email.toString())
      .collection('group')
      .snapshots()
      .map((snapshot) =>
      snapshot.docs.map((doc) =>
      Family.fromJson(doc.data())).toList(),
  );
  // read DOC w specify ID
  Future<Family?> readFamilyDetail() async {
    final Detail = FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser.toString())
        .collection('group').doc('test');
    final snapshot = await Detail.get();
    if (snapshot.exists) {
      return Family.fromJson(snapshot.data()!);
    }
  }
  // content change by different person
  Widget buildList(Family data) => ListTile(
    leading: CircleAvatar(child: Text('${data.picpath}'),),
    title: Text(data.t.toString()),
    subtitle: Text(data.st.toString()),
    onTap: () => {
      pressed, // (null)
    },
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body :
      StreamBuilder<List<Family>> (
        stream: readFamily(),
        builder: (context, snapshot) {
          if(snapshot.hasError) {
            return _errMsg;
          } else if(snapshot.hasData) {
            final data = snapshot.data!;

            return Padding(
              padding: EdgeInsets.only(top: 50),
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: (data==null||data.isEmpty)? _DefaultScreen :
                  ListView(
                    children: data.map(buildList).toList(),
                  ),
              ),
            );
          } else {
            return Center(child: CircularProgressIndicator(),); // loading
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(pressed),
        // _addMember,
        backgroundColor: Color.fromRGBO(45, 224, 213, 86),
        child: const Icon(Icons.add,),
      ),
    );
  }
}

class Family {
  String? t;    // title
  String? st;    // subtitle
  String? Food;    // ....
  String? picpath; // Pic

  Family({
    this.picpath,
    required this.t,
    required this.st,
    required this.Food,
  });

  Map<String, dynamic> toJson() => {
    't': t,
    'st': st,
    'Food': Food,
    'picpath': picpath,
  };

  static Family fromJson(Map<String, dynamic> json) => Family(
    picpath: json['picpath'],
    // (json['date'] as Timestamp).toDate(),
    st: json['st'],
    Food: json['Food'],
    t: json['t'],
  );
}

