import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:untitled/CustomPageRoute.dart';
// import 'package:untitled/Pages/HomeScreen.dart';

import '../Group/Actions.dart';
import '../Group/Group.dart';

class FGroupScreen extends StatefulWidget {
  const FGroupScreen({Key? key}) : super(key: key);

  @override
  State<FGroupScreen> createState() => _FGroupScreenState();
}

class _FGroupScreenState extends State<FGroupScreen> {
  // currentUser
  final UserID = FirebaseAuth.instance.currentUser!.email.toString();

  final PersonDecro = BoxDecoration(color: Colors.blueGrey.shade200);
  // button test
  // final pressed = SnackBar(content: const Text('you Pressed that button'));
  // final hold = SnackBar(content: const Text('you hold the button'));
  // show error in Center
  final _errMsg = Container(
      height: 1000,width: double.infinity, // color:Colors.grey.shade100,
      child: Center(
        child: Text('An Error occurred!',style: TextStyle(fontSize: 30),),
      )
  );
  // Haven't in a Group
  final _DefaultScreen = Container(height: 1000,width: double.infinity, // color:Colors.grey.shade100,
    child: Align(alignment: Alignment.center,
      child: Text('你還沒建立群組',style: TextStyle(fontSize: 30),),
    ),
  );
  // Don't Have Group_Member
  final _EmptyGroup = Container(height: 1000,width: double.infinity, // color:Colors.grey.shade100,
    child: Align(alignment: Alignment.center,
      child: Text('現在群組尚未有其他成員',style: TextStyle(fontSize: 30),),
    ),
  );

  Widget AvatarIcon(String gender) {
    switch(gender.toLowerCase()){
      case'male':
        return Icon(Icons.man,size: 30,);
      case'female':
        return Icon(Icons.woman,size: 30,);
      default:
        return Icon(Icons.reddit_outlined ,size: 30,);
    }
  }
  // GroupList as if Have Family
  Widget buildList(Family data) {
    return ListTile(
      leading: CircleAvatar(
        child: (data.picpath==''||data.picpath==null) ?
        AvatarIcon(data.gender.toString()) :
        ClipRRect(
          child: Image.network(data.picpath.toString()),
          borderRadius: BorderRadius.circular(50),
        ),
        backgroundColor: Colors.white,
      ),
      title: Text(data.name.toString()),
      subtitle: Text(data.mail.toString()),
      onTap: null,
    );
  }
  // Streaming on All Groups not used
  Stream<List<OurGroup>> readCurrentGroup() => FirebaseFirestore.instance
      .collection('Groups_List')
      .snapshots()
      .map((snapshot) =>
      snapshot.docs.map((doc) => OurGroup.fromJson(doc.data())).toList(),
  );
  // get group_id User have
  Future<UserData?> checkSelfHaveGroup() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Users_Profile').doc(UserID).get();
    if (snapshot.exists) {
      return UserData.fromJson(snapshot.data()!);
    }
  }
  // get member by Same group_id maybe members
  Stream<List<Family>> getMember() => FirebaseFirestore.instance
      .collection('Users_Profile')
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) =>
      Family.fromJson(doc.data())).toList()
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body : StreamBuilder<List<Family>>(
        stream: getMember(),
        builder: (context, snapshot2) {
          if (snapshot2.hasError) {
            return Center(child: Text(snapshot2.error.toString(),),);
          } else if (snapshot2.hasData) {
            return FutureBuilder<UserData?> (
              future: checkSelfHaveGroup(),
              builder: (context, snapshot) {
                if(snapshot.hasError) {
                  return Center(child: Text(snapshot.error.toString(),),);
                } else if(snapshot.hasData) {
                  final data = snapshot.data!;
                  final users = snapshot2.data!;
                  List<Family> checkEmpty = [];
                  for(Family target in users) {
                    // print(target.GIDcheck);
                    // print(target.mail);
                    // print(data.groupID);
                    // print(checkEmpty.toString());
                    if (target.GIDcheck==data.groupID&&target.mail!=data.ID){
                      checkEmpty.add(target);
                    };
                  }
                  if (data==null||data.groupID==''){
                    return Padding(
                      padding: EdgeInsets.only(top: 50),
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: _DefaultScreen,
                      ),
                    );
                  } else if (users.isEmpty||checkEmpty.isEmpty) {
                    return Padding(
                      padding: EdgeInsets.only(top: 50),
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: _EmptyGroup,
                      ),
                    );
                  } else {
                    // print(checkEmpty);
                    return Padding(
                      padding: EdgeInsets.only(top: 50),
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: ListView(
                          children: [for(Family f in checkEmpty) buildList(f)],
                        ),
                      ),
                    );
                  }
                } else {
                  return Center(child: CircularProgressIndicator(),); // loading
                }
              },
            );

          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => {
          Navigator.of(context).push(
            CustomPageRoute(
              child: GroupActions(),
              direction: AxisDirection.down,
            ),
          ),
        }, // ScaffoldMessenger.of(context).showSnackBar(pressed),
        backgroundColor: Color.fromRGBO(48, 92, 84, 100),
        child: const Icon(Icons.add,),
      ),
    );
  }
}

class Family {
  String? name;    // title
  String? mail;    // subtitle ??? or check if is CurrentUser
  String? gender;
  String? picpath; // Pic
  String? GIDcheck;// check group_id is same

  Family({
    this.picpath,
    this.gender,
    required this.name,
    required this.mail,
    required this.GIDcheck,
  });

  Map<String, dynamic> toJson() => {
    'user_name': name,
    'user_ID/account': mail,
    'user_gender': gender,
    'user_avatar': picpath,
    'group_id': GIDcheck,
  };

  static Family fromJson(Map<String, dynamic> json) => Family(
    mail: json['user_ID/account'],
    picpath: json['user_avatar'],
    name: json['user_name'],
    GIDcheck: json['group_id'],
    gender: json['user_gender'],
  );
}

class UserData {
  String? name;    // check with other name and hide self detail
  String? ID;      // check if is creator???
  String? groupID; // check which group

  UserData({
    this.name,
    this.ID,
    this.groupID,
  });

  Map<String, dynamic> toJson() => {
    'user_name': name,
    'user_ID/account': ID,
    'group_id': groupID,
  };

  static UserData fromJson(Map<String, dynamic> json) => UserData(
    ID: json['user_ID/account'],
    name: json['user_name'],
    groupID: json['group_id'],
  );
}
