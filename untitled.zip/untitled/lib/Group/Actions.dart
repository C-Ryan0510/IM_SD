import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:untitled/Group/Group.dart';

import 'package:untitled/Group/createGroup.dart';
import 'package:untitled/Group/joinGroup.dart';
import 'package:untitled/Group/sentGroupInviite.dart';

class GroupActions extends StatefulWidget {
  GroupActions({Key? key}) : super(key: key);
  @override
  State<GroupActions> createState() => _GroupActionsState();
}
class _GroupActionsState extends State<GroupActions> {
  final authPath = FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser?.email.toString());

  Future<UserGroupData?> checkGroup() async {
    final snapshot = await authPath.get();

    if (snapshot.exists) {
      return UserGroupData.fromJson(snapshot.data()!);
    }
  }
  Future<OurGroup?> getGroupName(String? groupid) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Groups_List').doc(groupid).get();

    if (snapshot.exists) {
      return OurGroup.fromJson(snapshot.data()!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        alignment: AlignmentDirectional.topCenter,
        children: [
          Container(
            height: 780,
            width: 500,
            decoration: BoxDecoration(
              color: Color.fromRGBO(45, 224, 213, 0.6),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(100),
                bottomRight: Radius.circular(100),
              ),
            ),
          ),
          FutureBuilder<UserGroupData?>(
            future: checkGroup(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(child: Text('Something went wrong!'),);
              } else if (snapshot.hasData) {
                final data = snapshot.data;
                if (data==null||data.groupID==''){
                  return Column(
                    children: [
                      Spacer(flex: 1,),
                      Padding(
                        padding: EdgeInsets.all(80),
                        child: Image.asset('lib/asset/homecare.png'),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 40),
                        child: Text(
                          '歡迎加入TakeCare大家庭',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 40,
                            color: Colors.grey[600],
                          ),
                        ),
                      ),
                      Spacer(flex: 1,),
                      Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            RaisedButton(
                              child: Text('Cancel'),
                              onPressed: () => {
                                Navigator.pop(context),
                              },
                              color: Theme.of(context).canvasColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                side: BorderSide(
                                  color: Color.fromRGBO(200, 5, 200, 0.4),
                                  width: 2,
                                ),
                              ),
                            ),
                            RaisedButton(
                              child: Text('Create'),
                              onPressed: () => {
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => createGroup(),),),
                              },
                              color: Theme.of(context).canvasColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                side: BorderSide(
                                  color: Colors.yellow.shade700,
                                  width: 2,
                                ),
                              ),
                            ),
                            RaisedButton(
                              child: Text('Join',
                                style: TextStyle(color: Colors.black,),
                              ),
                              onPressed: () => {
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => joinGroup(),),),
                              },
                              color: Theme.of(context).canvasColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                side: BorderSide(
                                  color: Colors.lightBlueAccent.shade700,
                                  width: 2,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                } else {
                  return FutureBuilder<OurGroup?>(
                    future: getGroupName(data.groupID),
                    builder: (context, snapshot2) {
                      if (snapshot2.hasError) {
                        return Center(child: Text('Something went wrong!${snapshot2.toString()}'),);
                      } else if (snapshot2.hasData) {
                        final data2 = snapshot2.data;
                        return Column(
                          children: [
                            Spacer(flex: 1,),
                            Padding(
                              padding: EdgeInsets.all(80),
                              child: Image.asset('lib/asset/homecare.png'),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 40),
                              child: Text(
                                '你的家庭\n'
                                '${data2?.name}',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 40,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ),
                            Spacer(flex: 1,),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  RaisedButton(
                                    child: Text('Cancel'),
                                    onPressed: () => {
                                      Navigator.pop(context),
                                    },
                                    color: Theme.of(context).canvasColor,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                      side: BorderSide(
                                        color: Color.fromRGBO(200, 5, 200, 0.4),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  RaisedButton(
                                    child: Text('Invite'),
                                    onPressed: () => {
                                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => GroupInvitation(),),),
                                    },
                                    color: Theme.of(context).canvasColor,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                      side: BorderSide(
                                        color: Colors.pink.shade200,
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        );
                      } else {
                        return Center(child: CircularProgressIndicator(),);
                      }
                    },
                  );
                }
              } else {
                return Center(child: CircularProgressIndicator(),);
              }
            },
          ),
        ],
      ),
    );
  }
}
class UserGroupData {
  String? groupID; // check

  UserGroupData({
    required this.groupID,
  });

  Map<String, dynamic> toJson() => {
    'group_id' : groupID,
  };

  static UserGroupData fromJson(Map<String, dynamic> json) => UserGroupData(
    groupID: json['group_id'],
  );
}
