import 'package:cloud_firestore/cloud_firestore.dart';

class OurGroup{
  String? id;
  String name;
  String creator;
  List<String> members;
  Timestamp groupCreated;

  OurGroup({
    this.id,
    required this.name,
    required this.creator,
    required this.members,
    required this.groupCreated,
  });

  Map<String, dynamic> toJson() => {
    'name' : name,
    'creator': creator,
    'groupCreated': groupCreated,
    'members': members,
  };

  static OurGroup fromJson(Map<String, dynamic> json) => OurGroup(
    name: json['name'],
    creator: json['creator'],
    members: List<String>.from(json['members']),
    groupCreated: (json['groupCreated'] as Timestamp),
  );
}