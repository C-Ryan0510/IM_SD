/*
*
* ALL section of the sources code
* were Only Created and Edited
* by the Author Ryan Chiang
*
* */