import 'package:flutter/material.dart';

class Ending extends StatefulWidget {
  const Ending({Key? key}) : super(key: key);

  @override
  State<Ending> createState() => _EndingState();
}

class _EndingState extends State<Ending> {

  void iniState(){
    _GuideEnd();
  }
  _GuideEnd() async{
    await Future.delayed(Duration(seconds: 2));
    // Navigator.pushReplacement(context, MaterialPageRoute(
    //     // builder: (context)=> Splash()),
    // );
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}


