import 'package:flutter/material.dart';

class Intro extends StatelessWidget {
  Intro({Key? key}) : super(key: key);

  final Controller = new TextEditingController();
  // final passcheckController = TextEditingController();

  final BoxOutline = OutlineInputBorder(borderSide: BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.circular(200),);
  final ErorrOutline = OutlineInputBorder(borderSide: BorderSide(color: Colors.red.withOpacity(0.86), width: 2.0), borderRadius: BorderRadius.circular(200),);


  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black54.withOpacity(0.5),
      child:Padding(
        padding: EdgeInsets.symmetric(horizontal: 20,vertical: 75),
        child: Stack(
          children: <Widget>[
            Positioned(left: 25,
              child: Text('註冊',style: TextStyle(fontSize: 40, color: Color.fromRGBO(45, 224, 213, 100)),),),
            ListView(
              // mainAxisAlignment: MainAxisAlignment.center,
              // reverse: true,
              padding: EdgeInsets.symmetric(horizontal: 40,),
              children: [
                SizedBox(height: 200,),
                TextFormField(
                    controller: Controller,
                    decoration: InputDecoration(
                      labelText: '請輸入信箱',
                      labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                      enabledBorder: BoxOutline,
                      focusedBorder: BoxOutline,
                      errorBorder: ErorrOutline,
                      focusedErrorBorder: ErorrOutline,
                      prefixIcon: Padding(
                        padding: EdgeInsets.all(10),
                        child: Icon(Icons.email_outlined,color: Colors.black,),
                      ),
                    ),
                    textInputAction: TextInputAction.next,
                ),
                SizedBox(height: 400,),//間隔
                ElevatedButton(
                  child: Text('註冊新帳號',style: TextStyle(fontSize:20 ,fontWeight: FontWeight.bold ,color: Color.fromRGBO(48, 92, 84, 100)),),
                  onPressed: null, // next page
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.white),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(200),
                        side: BorderSide(color: Color.fromRGBO(45, 224, 213, 86)),
                      ),
                    ),
                  ),
                ),
                // SizedBox(height: 30,),//間隔
              ],
            ),
            // IconButton(//To put it on top of ListView so it can be onPressed
            //   alignment: Alignment.bottomCenter,
            //   icon: Icon(Icons.arrow_back_ios_new,color: Colors.black,size: 40,),
            //   onPressed: () => Navigator.of(context).pop(),
            // ),
          ],
        ),
      ),
    );
  }
}
