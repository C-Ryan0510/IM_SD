// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// import 'package:flutter/material.dart';
//
// class ThemeColorPicker extends StatefulWidget {
//   const ThemeColorPicker({Key? key}) : super(key: key);
//
//   @override
//   State<ThemeColorPicker> createState() => _ThemeColorPickerState();
// }
//
// class _ThemeColorPickerState extends State<ThemeColorPicker> {
//   final CurUser = FirebaseAuth.instance.currentUser?.email.toString();
//   late String CurrentColor;
//   late Color CurrentTheme;
//   // CurrentTheme = new fromHex("#305C54");
//
//   Color fromHex(String hexString) {
//     final buffer = StringBuffer();
//     if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
//     buffer.write(hexString.replaceFirst('#', ''));
//     return Color(int.parse(buffer.toString(), radix: 16));
//   }
//
//   Future back() async { // use this Future function to onTop use
//     Navigator.of(context).pop();
//   }
//   Future setPic() async {
//     FirebaseFirestore.instance.collection('Users_Profile').doc(CurUser).update({
//       'favorite_theme': CurrentColor,
//     });
//   }
//   Stream<List<getGallery>> ColorSeleted() => FirebaseFirestore.instance.collection('Users_Profile').doc(CurUser)
//       .collection('favorite_theme_color')
//       .snapshots()
//       .map((snapshot) => snapshot
//       .docs.map((doc) =>
//       getGallery.fromJson(doc.data())).toList(),
//   );
//
//   Widget ImageTile(getGallery data) => GridTile(
//       child: InkWell(
//         splashColor: Colors.blue,
//         child: Ink(
//           color: Colors.blue.shade100,
//           child: Image.network('${data.url.toString()}'),
//         ),
//         onTap: () => setState(() {
//           // CurrentImage = data.url.toString();
//         }),
//       )
//   );
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: StreamBuilder<List<getGallery>>(
//         stream: ColorSeleted(),
//         builder: (context, snapshot) {
//           if (snapshot.hasData) {
//             final get = snapshot.data!;
//             return Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   SizedBox(height: 70,
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Text(''),
//                         GestureDetector(
//                           child: Text('取消',
//                             style: TextStyle(
//                               fontSize: 24,
//                               color: Colors.black26,
//                             ),
//                           ),
//                           onTap: back,
//                           // null,
//                         ),
//                         Text(''),
//                         Text('設定頭像',
//                           style: TextStyle(
//                             fontSize: 24,
//                             color: Colors.black,
//                           ),
//                         ),
//                         Text(''),
//                         GestureDetector(
//                             child: Text('完成',
//                               style: TextStyle(
//                                 fontSize: 24,
//                                 color: Colors.blueAccent,
//                               ),
//                             ),
//                             onTap: () {
//                               setColor();
//                               back();
//                             }
//                         ),
//                         Text(''),
//                       ],
//                     ),
//                   ),
//                   Divider(thickness: 2,color: Color.fromRGBO(48, 92, 84, 100),),
//                   Container(
//                     width: double.infinity, height: 400,
//                     color: Color.fromRGBO(48, 92, 84, 100),
//                     child: (CurrentTheme == '') ?
//                     ColoredBox(color: Colors.white,):
//                     ColoredBox(color: $theme,),
//                   ),
//                   Divider(thickness: 2,color: Color.fromRGBO(48, 92, 84, 100),),
//                   SizedBox(height: 40,
//                     child: Row(
//                       children: [
//                         Expanded(
//                           flex: 5,
//                           child: GestureDetector(child: Text('上傳新照片',style: TextStyle(fontSize: 20),),
//                             onTap: () {
//                               Navigator.of(context).push(MaterialPageRoute(
//                                 builder: (context) => ColorPicker(),
//                               ),);
//                             },
//                           ),
//                         ),
//                         Expanded(
//                           flex: 5,
//                           child: GestureDetector(child: Text('上傳新照片',style: TextStyle(fontSize: 20),),
//                             onTap: () {
//                               Navigator.of(context).push(MaterialPageRoute(
//                                 builder: (context) => DefaultThemeList(),
//                               ),);
//                             },
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Divider(thickness: 2,color: Color.fromRGBO(48, 92, 84, 100),),
//                   Container(
//                     width: double.infinity, height: 294,
//                     // color: Colors.grey,
//                     child: GridView(
//                       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3,mainAxisSpacing: 10,crossAxisSpacing: 10),
//                       children: get.map(ImageTile).toList(),
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           } else if(snapshot.hasError) {
//             return Center(child: Text('Error $snapshot'),);
//           } else {
//             return Center(child: CircularProgressIndicator(),);
//           }
//         },
//       ),
//     );
//   }
// }
//
// class getGallery {
//   String? url;
//
//   getGallery({
//     required this.url
//   });
//
//   Map<String, dynamic> toJson() => {
//     'selected_color': url,
//   };
//
//   static getGallery fromJson(Map<String, dynamic> json) => getGallery(
//     url: json['selected_color'],
//   );
// }