library flutter_collapse;
import 'package:flutter/material.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/rendering.dart';

// class AnimatedRotate extends ImplicitlyAnimatedWidget {
//   /// 自定义旋转动画
//   /// 参考：自带动画 AnimatedOpacity
//   /// 详细注解查看  AnimatedOpacity
//   /// ``` dart
//   /// @params rotate 计算方式：x * math.pi * 2
//   /// ```
//   const AnimatedRotate({
//     Key? key,
//     this.child,
//     @required this.rotate,
//     Curve curve = Curves.linear,
//     @required Duration duration,
//   })  : assert(rotate != null),
//         super(key: key, curve: curve, duration: duration);
//
//   final Widget child;
//
//   final double rotate;
//
//   @override
//   _AnimatedRotateState createState() => _AnimatedRotateState();
//
//   @override
//   void debugFillProperties(DiagnosticPropertiesBuilder properties) {
//     super.debugFillProperties(properties);
//     properties.add(DoubleProperty('rotate', rotate));
//   }
// }
//
// class _AnimatedRotateState
//     extends ImplicitlyAnimatedWidgetState<AnimatedRotate> {
//   Tween<double> _rotate;
//   Animation<double> _rotateAnimation;
//
//   @override
//   void forEachTween(TweenVisitor<dynamic> visitor) {
//     _rotate = visitor(
//         _rotate, widget.rotate, (dynamic value) => Tween<double>(begin: value));
//   }
//
//   @override
//   void didUpdateTweens() {
//     _rotateAnimation = animation.drive(_rotate);
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return RotationTransition(
//       turns: _rotateAnimation,
//       alignment: Alignment.center,
//       child: widget.child,
//     );
//   }
// }

class Collapse extends StatelessWidget {
  /// 折叠面板
  const Collapse({
    Key? key,
    this.title,
    this.icon = const Icon(
      Icons.expand_more,
      size: 24,
    ),
    this.value = true,
    this.body,
    this.onChange,
    this.showBorder = true,
    this.padding = const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
  }) : super(key: key);

  /// 标题
  final title;

  /// 是否展开 true:展开 false:收起 默认值:true
  final bool value;

  /// 内容
  final body;

  /// 回调 返回当前value
  final onChange;

  /// icon 默认值：Icon(Icons.expand_more, size: 24,),
  final Widget icon;

  /// padding 默认值：EdgeInsets.symmetric(vertical: 10, horizontal: 15)
  final EdgeInsets padding;

  /// 是否显示border
  final bool showBorder;

  static const Color borderColor = Color.fromRGBO(235, 237, 240, 1);
  static const Duration sleep = const Duration(milliseconds: 120);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      key: key,
      child: Column(
        children: <Widget>[
          /// title
          InkWell(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          color:
                          showBorder ? borderColor : Colors.transparent))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: title,
                  ),
                  // AnimatedRotate(
                  //   duration: sleep,
                  //   child: icon,
                  //   rotate: value ? 0.5 : 1,
                  // )
                ],
              ),
            ),
            onTap: () => onChange == null ? () {} : onChange(!value),
          ),

          _Body(
            child: Container(padding: padding, child: body),
            sleep: sleep,
            value: value,
          )
        ],
      ),
    );
  }
}

/// 内容区域
/// 为了获取当前内容的高度 实现展开收起动画，所以拆成状态组件
class _Body extends StatefulWidget {
  _Body({
    this.child,
    this.value,
    @required this.sleep,
    Key? key,
  }) : super(key: key);

  final child;
  final value;
  final sleep;

  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<_Body> with TickerProviderStateMixin {
  Widget build(BuildContext context) {
    return Container(
      child: AnimatedSize(
          vsync: this,
          duration: widget.sleep,
          child: Container(
            constraints: BoxConstraints(
              maxHeight: !widget.value ? 0 : double.infinity,
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: widget.child,
                )
              ],
            ),
          )),
    );
  }
}

class QandA extends StatefulWidget {
  QandA({Key? key}) : super(key: key);

  @override
  _QandAState createState() => _QandAState();
}

class _QandAState extends State<QandA> {
  bool status1 = false;
  bool status2 = false;
  bool status3 = false;
  bool status4 = false;
  bool status5 = false;
  bool status6 = false;
  bool status7 = false;
  bool status8 = false;
  bool status9 = false;
  bool status10 = false;
  bool status11 = false;
  bool status12 = false;
  bool status13 = false;
  bool status14 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Q&A'),
        backgroundColor: Colors.transparent,
      ),
      body: Stack(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 40,horizontal: 30),
            child: ListView(
              children: [
                ListTile(
                  title: Text('個人資料相關問題'),
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('忘記密碼')
                  ),
                  body: Text('於登入介面中按忘記密碼並輸入email即可於email中更新密碼。'),
                  value: status1,
                  onChange: (bool value) {
                    setState(() {
                      status1 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('要去哪裡更改email、密碼等個人資料?')
                  ),
                  body: Text('點選home screen旁的按鈕後點基本資料即可更新個人資料，但是由於email為帳號，因此目前無法更改。'),
                  value: status2,
                  onChange: (bool value) {
                    setState(() {
                      status2 = value;
                    });
                  },
                ),
                Divider(thickness: 4),
                ListTile(
                  title: Text('健康紀錄相關問題'),
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('我不小心輸入錯誤的數字，請問可以更改嗎?')
                  ),
                  body: Text('可以的，再重新輸入一次資料就會更新數據。'),
                  value: status3,
                  onChange: (bool value) {
                    setState(() {
                      status3 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('昨天測量的資料忘了輸入，請問可以補輸入嗎?')
                  ),
                  body: Text('可以至「記錄」中選取您想補填的資料，日期選取至您想補填的時間後輸入數值即可。'),
                  value: status4,
                  onChange: (bool value) {
                    setState(() {
                      status4 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('如果會常常忘記測量或吃藥怎麼辦?')
                  ),
                  body: Text('可以至「記錄」中的用藥時間輸入吃藥的時間或測量的時間，由app來提醒您。'),
                  value: status5,
                  onChange: (bool value) {
                    setState(() {
                      status5 = value;
                    });
                  },
                ),
                Divider(thickness: 4),
                ListTile(
                  title: Text('儀器相關問題'),
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('我沒買血壓計，請問app可以幫忙測量血壓嗎?')
                  ),
                  body: Text('此app只適用於追蹤或記錄自身的健康狀況，並不包含此功能喔！建議您還是購買相關器材來保護您的健康！'),
                  value: status6,
                  onChange: (bool value) {
                    setState(() {
                      status6 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('每天手動輸入資料有點麻煩，\n請問可以讓他自動輸入嗎?')
                  ),
                  body: Text('目前此app尚未有此功能，以手動輸入為主，還請見諒！'),
                  value: status7,
                  onChange: (bool value) {
                    setState(() {
                      status7 = value;
                    });
                  },
                ),
                Divider(thickness: 4),
                ListTile(
                  title: Text('健康狀況相關問題'),
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('請問要怎麼知道自己的健康狀況呢?')
                  ),
                  body: Text('請至「數據」頁面選擇您想查看的日期，app會整合歷史數據呈現在您面前。'),
                  value: status8,
                  onChange: (bool value) {
                    setState(() {
                      status8 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('請問要怎麼知道家人的健康狀況呢?')
                  ),
                  body: Text('請至「家庭」或「首頁」頁面查看，可以得知家人目前的狀況。'),
                  value: status9,
                  onChange: (bool value) {
                    setState(() {
                      status9 = value;
                    });
                  },
                ),
                Divider(thickness: 4),
                ListTile(
                  title: Text('家庭群組相關問題'),
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('請問要怎麼跟家人建立群組?')
                  ),
                  body: Text('請至「家庭」頁面點擊右下角的加號按鈕，輸入您想群組的人的email即可進行群組。 '),
                  value: status10,
                  onChange: (bool value) {
                    setState(() {
                      status10 = value;
                    });
                  },
                ),
                Divider(thickness: 4),
                ListTile(
                  title: Text('即時訊息相關問題'),
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('要怎麼知道自己有沒有潛在疾病?')
                  ),
                  body: Text('當您輸入的資料不在正常範圍時會於「首頁」頁面跳出即時訊息代表您的身體健康出現了異常，此時建議您瀏覽最新消息，可得知您附近的醫療資源。'),
                  value: status11,
                  onChange: (bool value) {
                    setState(() {
                      status11 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('收到即時通知怎麼辦?\n是不是代表我的身體很糟糕?')
                  ),
                  body: Text('收到即時通知代表您的健康指數超出或低於正常值，並不代表您的身體真的有問題，或許是睡眠時間不足、飲水量不足或卡路里攝取過多。但是若是血壓、心率或體溫異常的情況建議您瀏覽最新消息，可得知您附近的醫療資源進行醫療諮詢或診斷。'),
                  value: status12,
                  onChange: (bool value) {
                    setState(() {
                      status12 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('收到血壓偏高的即時通知，\n請問是否該直接就醫諮詢?')
                  ),
                  body: Text('收縮壓>140mmHg或舒張壓>90mmHg就是高血壓，必須用藥及調整生活型態。收縮壓在120-139mmHg或是舒張壓在80-89mmHg間，稱為高血壓前期，不需吃藥，僅調整生活型態即可。'),
                  value: status13,
                  onChange: (bool value) {
                    setState(() {
                      status13 = value;
                    });
                  },
                ),
                Divider(thickness: 2),
                Collapse(
                  title: Container(
                      child: Text('收到心率偏高或偏低的即時通知，\n請問是否該直接就醫諮詢?')
                  ),
                  body: Text('可能引發原因有以下七種：\n'
                      '1.壓力大會使心臟負荷較大，進而增加心臟病或中風風險\n'
                      '2.糖尿病風險高\n'
                      '3.心律不整，常合併頭暈、頭昏症狀\n'
                      '4.不運動導致心臟不夠力，靜止時心率就會加快\n'
                      '5.食用含咖啡因的藥物可能使心跳加速\n'
                      '6.喝太多水或水分不足時，就會引發心律失常\n'
                      '7.甲狀腺低下，心跳減慢；甲狀腺亢進，心跳加快\n'
                      '此時建議您瀏覽最新消息，可得知您附近的醫療資源進行醫療諮詢或診斷。'),
                  value: status14,
                  onChange: (bool value) {
                    setState(() {
                      status14 = value;
                    });
                  },
                ),
              ],
            ),
          ),
        ],
      ),

    );
  }
}