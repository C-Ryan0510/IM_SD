import 'package:flutter/material.dart';

class AccQ extends StatefulWidget {
  const AccQ({Key? key}) : super(key: key);

  @override
  State<AccQ> createState() => _AccQState();
}

class _AccQState extends State<AccQ> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
