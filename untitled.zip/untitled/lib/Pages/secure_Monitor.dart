import 'package:flutter/material.dart';

class sMonitor extends StatefulWidget {
  const sMonitor({Key? key}) : super(key: key);

  @override
  State<sMonitor> createState() => _sMonitorState();
}

class _sMonitorState extends State<sMonitor> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20,),
        child: Stack(
          children: [

          ],
        ),
      ),
    );
  }
}
