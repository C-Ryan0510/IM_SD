import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:untitled/AddPicture.dart';

import 'package:file_picker/file_picker.dart'; // for local search file


class Picture extends StatefulWidget {
  const Picture({Key? key}) : super(key: key);

  @override
  State<Picture> createState() => _PictureState();
}

class _PictureState extends State<Picture> {
  final CurUser = FirebaseAuth.instance.currentUser?.email.toString();
  late String CurrentImage = '';
  // final path = 'ProfilesPictures/${CurUser}'; // name change by user

  PlatformFile? pickedFile;

  Future back() async { // use this Future function to onTop use
    Navigator.of(context).pop();
  }
  Future setPic() async {
    FirebaseFirestore.instance.collection('Users_Profile').doc(CurUser).update({
      'user_avatar': CurrentImage,
    });
  }

  Stream<List<getGallery>> readGallery() => FirebaseFirestore.instance.collection('Users_Profile').doc(CurUser)
      .collection('Image_Gallery')
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) =>
      getGallery.fromJson(doc.data())).toList(),
  );

  Widget ImageTile(getGallery data) => GridTile(
    child: InkWell(
      splashColor: Colors.blue,
      child: Ink(
        color: Colors.blue.shade100,
        child: Image.network('${data.url.toString()}'),
      ),
      onTap: () => setState(() {
        CurrentImage = data.url.toString();
      }),
    )
  );

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<List<getGallery>>(
        stream: readGallery(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final get = snapshot.data!;
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(height: 70,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(''),
                        GestureDetector(
                          child: Text('取消',
                            style: TextStyle(
                              fontSize: 24,
                              color: Colors.black26,
                            ),
                          ),
                          onTap: back,
                          // null,
                        ),
                        Text(''),
                        Text('設定頭像',
                          style: TextStyle(
                            fontSize: 24,
                            color: Colors.black,
                          ),
                        ),
                        Text(''),
                        GestureDetector(
                            child: Text('完成',
                              style: TextStyle(
                                fontSize: 24,
                                color: Colors.blueAccent,
                              ),
                            ),
                            onTap: () {
                              setPic();
                              back();
                            }
                        ),
                        Text(''),
                      ],
                    ),
                  ),
                  Divider(thickness: 2,color: Color.fromRGBO(45, 224, 213, 86),),
                  Container(
                    width: double.infinity, height: 400,
                    color: Color.fromRGBO(45, 224, 213, 86),
                    child: (CurrentImage == '') ?
                    Image.asset('lib/asset/healthcare.png'):
                    Image.network(
                      CurrentImage,
                    ),
                  ),
                  Divider(thickness: 2,color: Color.fromRGBO(45, 224, 213, 86),),
                  SizedBox(height: 40,
                    child: GestureDetector(child: Text('上傳新照片',style: TextStyle(fontSize: 20),),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => AddPicture(),
                        ),);
                      },
                    ),
                  ),
                  Divider(thickness: 2,color: Color.fromRGBO(45, 224, 213, 86),),
                  Container(
                    width: double.infinity, height: 294,
                    // color: Colors.grey,
                    child: GridView(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3,mainAxisSpacing: 10,crossAxisSpacing: 10),
                      children: get.map(ImageTile).toList(),
                    ),
                  ),
                ],
              ),
            );
          } else if(snapshot.hasError) {
            return Center(child: Text('Error $snapshot'),);
          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }
}
class getGallery {
  String? url;

  getGallery({
    required this.url
  });

  Map<String, dynamic> toJson() => {
    'image_path': url,
  };

  static getGallery fromJson(Map<String, dynamic> json) => getGallery(
    url: json['image_path'],
  );
}
