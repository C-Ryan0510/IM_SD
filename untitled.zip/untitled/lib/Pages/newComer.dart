import 'package:flutter/material.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../GuidLines/Intro.dart';

class Guideline extends StatefulWidget {
  const Guideline({Key? key}) : super(key: key);

  @override
  State<Guideline> createState() => _GuidelineState();
}

class _GuidelineState extends State<Guideline> {

  final PageController controll = PageController();

  final authPath = FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser?.email.toString());

  Future userProfile() async {
    // authPath.set({
    //   'user_ID/account': FirebaseAuth.instance.currentUser!.email,
    //   'user_name': '',
    //   'user_age': '',
    //   'user_phoneNumber': '',
    //   // 'IsFirstTime': true,
    // });
    authPath.update({
      'user_name': 'Ryan',
    });
  }
  // Future<bool> dataDetect() async {
  //   var check = await authPath.get();
  //   return check.exists;
  // }

  @override
  Widget build(BuildContext context) {
    if (authPath.get()!=null) {
      return PageView(
        controller: controll,
        children: [
          Intro(),
          Container(), // gender name
          Container(), // height & weight
          Container(), // current BMI
          Container(), // Thank
        ],
      );
    } else {
      return Center(child: Container(color: Colors.red.shade400, child: Text('An Error Occurs.'),),);
    }
    // return Padding(
    //   padding: EdgeInsets.all(25),
    //   child: Container(
    //     child: ,
    //   ),
    // );
  }
}
