import 'dart:ffi';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:untitled/Pages/BMI.dart';
import 'package:untitled/Pages/splash.dart';

class Intro extends StatefulWidget {
  Intro({Key? key}) : super(key: key);

  @override
  State<Intro> createState() => _IntroState();
}
class _IntroState extends State<Intro> {

  final BoxOutline = OutlineInputBorder(borderSide: BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.circular(200),);
  final ErorrOutline = OutlineInputBorder(borderSide: BorderSide(color: Colors.red.withOpacity(0.86), width: 2.0), borderRadius: BorderRadius.circular(200),);

  final TextEditingController _name = new TextEditingController();
  // final TextEditingController _gender = new TextEditingController();
  final TextEditingController _age = new TextEditingController();
  final TextEditingController _Phone = new TextEditingController();

  final Gen = ['Male', 'Female'];

  var _curGendar;

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.grey.shade200,
      padding: EdgeInsets.only(
        top: 50,bottom: 20,
        left: 50,right: 50,
      ),
      child: Stack(
        children: [
          Column(
            children:[
              Center(
                // left: 30,
                // right: 30,
                child: Text('歡迎開始使用',
                  style: TextStyle(fontSize: 50, color: Color.fromRGBO(45, 224, 213, 100)),
                ),
              ),
              SizedBox(height: 5,),
              Center(
                child: Text(
                  '接下來要填幾個您的個人資料\n'
                  '以便接下來APP的使用。\n'
                  '若有不方便告知的可以之後再填。',
                  style: TextStyle(fontSize: 20,),
                ),
              ),
              SizedBox(height: 10,),
              TextFormField(
                controller: _name,
                decoration: InputDecoration(
                  labelText: '姓名/暱稱',
                  labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                  enabledBorder: BoxOutline,
                  focusedBorder: BoxOutline,
                  errorBorder: ErorrOutline,
                  focusedErrorBorder: ErorrOutline,
                ),
                textInputAction: TextInputAction.next,
                keyboardType: TextInputType.name,
              ),
              SizedBox(height: 15,),
              FormField<String>(
                builder: (FormFieldState<String> Tstate) {
                  return InputDecorator(
                    decoration: InputDecoration(
                      enabledBorder: BoxOutline,
                      disabledBorder: BoxOutline,
                    ),
                    // isEmpty: _curPeriod == '早餐',
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _curGendar,
                        hint: Text('性別'),
                        isDense: true,
                        onChanged: (newValue) {
                          setState(() {
                            _curGendar = newValue;
                            Tstate.didChange(newValue);
                          });
                        },
                        items: Gen.map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                      ),
                    ),
                  );
                },
              ),
              SizedBox(height: 15,),
              TextFormField(
                controller: _age,
                decoration: InputDecoration(
                  labelText: '年齡',
                  labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                  enabledBorder: BoxOutline,
                  focusedBorder: BoxOutline,
                  errorBorder: ErorrOutline,
                  focusedErrorBorder: ErorrOutline,
                ),
                textInputAction: TextInputAction.next,
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 15,),
              TextFormField(
                controller: _Phone,
                decoration: InputDecoration(
                  labelText: '電話號碼',
                  labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                  enabledBorder: BoxOutline,
                  focusedBorder: BoxOutline,
                  errorBorder: ErorrOutline,
                  focusedErrorBorder: ErorrOutline,
                ),
                textInputAction: TextInputAction.done,
                keyboardType: TextInputType.phone,
              ),
            ]
          ),
          Positioned(
              left: 50,
              right: 50,
              top: 700,
              child: ElevatedButton(
                child: Text('下一步',style: TextStyle(fontSize:20 ,fontWeight: FontWeight.bold ,color: Color.fromRGBO(48, 92, 84, 100)),),
                onPressed: () {
                  signInfo();
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context) => BMI(),
                          // Guideline(index: 2),
                    ),
                  );
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.white),
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(200),
                      side: BorderSide(color: Color.fromRGBO(45, 224, 213, 86)),
                    ),
                  ),
                ),
              )
          ),
        ],
      ),
    );
  }
  Future signInfo() async {
    FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .update({
      // 'user_ID/account': FirebaseAuth.instance.currentUser!.email,
      'user_phoneNumber': _Phone.text.trim(),
      'user_gender': _curGendar.toString(),
      'user_name': _name.text.trim(),
      'user_age': _age.text.trim(),
      // 'height': null,
      // 'weight': null,
      // 'BMI': null,
      // 'isFirst': false,
    });
  }
}
class Ending extends StatelessWidget {
  Ending({Key? key}) : super(key: key);

  final BoxOutline = OutlineInputBorder(borderSide: BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.circular(200),);
  final ErorrOutline = OutlineInputBorder(borderSide: BorderSide(color: Colors.red.withOpacity(0.86), width: 2.0), borderRadius: BorderRadius.circular(200),);

  @override
  Widget build(BuildContext context) => Scaffold(
    resizeToAvoidBottomInset: false,
    body: Stack(
      children: <Widget>[
        Container(
          height: double.infinity, width: double.infinity,
          child: Padding(
            padding: EdgeInsets.only(
              top: 50,bottom: 20,
              left: 50,right: 50,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Center(
                  child: Text('完成',
                    style: TextStyle(fontSize: 40, color: Color.fromRGBO(45, 224, 213, 100)),
                  ),
                ),
                SizedBox(height: 5,),
                Center(
                  child: Text(
                        '接下來要填幾個您的個人資料\n'
                        '以便接下來APP的使用。\n'
                        '若有不方便告知的可以之後再填。',
                    style: TextStyle(fontSize: 20,),
                  ),
                ),
                // SizedBox(height: 10,),
                // TextFormField(
                //   // controller: emailController,
                //   decoration: InputDecoration(
                //     labelText: '請輸入信箱',
                //     labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                //     enabledBorder: BoxOutline,
                //     focusedBorder: BoxOutline,
                //     errorBorder: ErorrOutline,
                //     focusedErrorBorder: ErorrOutline,
                //     prefixIcon: Padding(
                //       padding: EdgeInsets.symmetric(horizontal: 10),
                //       child: IconButton(
                //         icon: Icon(Icons.timer_outlined,color: Colors.black,),
                //         color: Colors.black,
                //         onPressed: null,
                //       ),
                //     ),
                //   ),
                //   textInputAction: TextInputAction.next,
                // ),
                // SizedBox(height: 15,),
                // TextFormField(
                //   // controller: emailController,
                //   decoration: InputDecoration(
                //     labelText: '請輸入信箱',
                //     labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                //     enabledBorder: BoxOutline,
                //     focusedBorder: BoxOutline,
                //     errorBorder: ErorrOutline,
                //     focusedErrorBorder: ErorrOutline,
                //     prefixIcon: Padding(
                //       padding: EdgeInsets.symmetric(horizontal: 10),
                //       child: IconButton(
                //         icon: Icon(Icons.timer_outlined,color: Colors.black,),
                //         color: Colors.black,
                //         onPressed: null,
                //       ),
                //     ),
                //   ),
                //   textInputAction: TextInputAction.next,
                // ),
                // SizedBox(height: 15,),
                // TextFormField(
                //   // controller: emailController,
                //   decoration: InputDecoration(
                //     labelText: '請輸入信箱',
                //     labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                //     enabledBorder: BoxOutline,
                //     focusedBorder: BoxOutline,
                //     errorBorder: ErorrOutline,
                //     focusedErrorBorder: ErorrOutline,
                //     prefixIcon: Padding(
                //       padding: EdgeInsets.symmetric(horizontal: 10),
                //       child: IconButton(
                //         icon: Icon(Icons.timer_outlined,color: Colors.black,),
                //         color: Colors.black,
                //         onPressed: null,
                //       ),
                //     ),
                //   ),
                //   textInputAction: TextInputAction.next,
                // ),
                // SizedBox(height: 15,),
                // TextFormField(
                //   // controller: emailController,
                //   decoration: InputDecoration(
                //     labelText: '請輸入信箱',
                //     labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                //     enabledBorder: BoxOutline,
                //     focusedBorder: BoxOutline,
                //     errorBorder: ErorrOutline,
                //     focusedErrorBorder: ErorrOutline,
                //     prefixIcon: Padding(
                //       padding: EdgeInsets.symmetric(horizontal: 10),
                //       child: IconButton(
                //         icon: Icon(Icons.timer_outlined,color: Colors.black,),
                //         color: Colors.black,
                //         onPressed: null,
                //       ),
                //     ),
                //   ),
                //   textInputAction: TextInputAction.done,
                // ),
              ],
            ),
          ),
        ),
        Positioned(
          left: 50,
          right: 50,
          top: 750,
          child: ElevatedButton(
            child: Text('結束',style: TextStyle(fontSize:20 ,fontWeight: FontWeight.bold ,color: Color.fromRGBO(48, 92, 84, 100)),),
            onPressed: () {
              complete();
              Navigator.popUntil(context, (route) => route.isFirst);
              Navigator.push(context,
                MaterialPageRoute(
                  builder: (context) => Splash(),
                  // Guideline(index: 2),
                ),
              );
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(Colors.white),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(200),
                  side: BorderSide(color: Color.fromRGBO(45, 224, 213, 86)),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 40),
          child: IconButton( //To put it on top of ListView so it can be onPressed
            alignment: Alignment.bottomCenter,
            icon: Icon(Icons.arrow_back_ios_new,color: Colors.black,size: 40,),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
      ],
    ),
  );
  Future complete() async {
    FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .update({
      // 'user_ID/account': FirebaseAuth.instance.currentUser!.email,
      // 'user_phoneNumber': null,
      // 'user_gender': null,
      // 'user_name': null,
      // 'user_age': null,
      // 'height': null,
      // 'weight': null,
      // 'BMI': null,
      'isFirst': false,
    });
  }
}

