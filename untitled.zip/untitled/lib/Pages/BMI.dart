import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../CustomPageRoute.dart';
import 'newComer.dart';

class BMI extends StatefulWidget {
  BMI({Key? key}) : super(key: key);

  @override
  State<BMI> createState() => _BMIState();
}
class _BMIState extends State<BMI> {

  late TextEditingController _HeightController = TextEditingController();
  late TextEditingController _WeightController = TextEditingController();
  late TextEditingController _BMIC = TextEditingController();

  final BoxOutline = OutlineInputBorder(borderSide: BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.circular(200),);
  final ErorrOutline = OutlineInputBorder(borderSide: BorderSide(color: Colors.red.withOpacity(0.86), width: 2.0), borderRadius: BorderRadius.circular(200),);

  double HFlow = 0.0, WFlow = 0.0;
  String _message = '';
  late String H, W;
  String Bmi = '';

  String Calculate(TextEditingController h, TextEditingController w, TextEditingController BmI) {
    H = h.text;
    W = w.text;
    double bmi = 0.0;

    if (H != '' && W != '') {
      bmi = (WFlow/ (HFlow/100*HFlow/100));
      Bmi = bmi.toStringAsFixed(2);
      BmI.value = BmI.value.copyWith(
        text: Bmi.toString(),
      );
    }

    if (bmi < 18.5 && bmi > 0.0) {
      _message ='          ' // 至中用
          '體重過輕\n'
          'You are underweight';
    } else if (bmi < 24) {
      _message ='       ' // 至中用
          '健康體位\n'
          'Your body is fine';
    } else if (bmi < 27) {
      _message ='                 ' // 至中用
          '稍微過重\n'
          'You\'re a slightly overweight';
    } else if (bmi < 30) {
      _message ='          ' // 至中用
          '輕度肥胖\n'
          'You are mild obesity';
    } else if (bmi < 35) {
      _message ='               ' // 至中用
          '中度肥胖\n'
          'You are moderate obesity';
    } else if (bmi > 35){
      _message ='            ' // 至中用
          '重度肥胖\n'
          'You are severe obesity';
    }
    // else if (bmi == 0 || bmi < 0) {
    //   _message = '';
    // }
    // else if (bmi! == true) {
    //   _message = '';
    // }
    return Bmi;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    resizeToAvoidBottomInset: false,
    body: FutureBuilder<User?>(
      future: readUserDetail(),
      // FirebaseFirestore.instance.collection('User_Profile').doc(FirebaseAuth.instance.currentUser?.email.toString()).snapshots(),
      builder: (context, snapshot) {
        final data = snapshot.data;
        if (snapshot.hasData) {
          if (SecondOrNot(data!) == true) { // First Time for NewComer()
            return Stack(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(
                    top: 50, bottom: 20,
                    left: 50, right: 50,
                  ),
                  child: Column(
                    children: [
                      Text('身體指數',
                        style: TextStyle(fontSize: 40,
                            color: Color.fromRGBO(48, 92, 84, 100),),
                      ),
                      SizedBox(height: 10,),
                      TextFormField(
                        controller: _HeightController,
                        decoration: InputDecoration(
                          hintText: '  請輸入身高',
                          labelStyle: TextStyle(color: Color.fromRGBO(
                              48, 92, 84, 100),),
                          enabledBorder: BoxOutline,
                          focusedBorder: BoxOutline,
                          errorBorder: ErorrOutline,
                          focusedErrorBorder: ErorrOutline,
                        ),
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.number,
                        onChanged: (height) {
                          setState(() {
                            HFlow = double.parse(height.toString());
                          });
                        },
                      ),
                      SizedBox(height: 10,),
                      TextFormField(
                        onChanged: (weight) {
                          setState(() {
                            WFlow = double.parse(weight.toString());
                          });
                        },
                        controller: _WeightController,
                        decoration: InputDecoration(
                          hintText: '  請輸入體重',
                          labelStyle: TextStyle(color: Color.fromRGBO(
                              48, 92, 84, 100),),
                          enabledBorder: BoxOutline,
                          focusedBorder: BoxOutline,
                          errorBorder: ErorrOutline,
                          focusedErrorBorder: ErorrOutline,
                        ),
                        textInputAction: TextInputAction.done,
                        keyboardType: TextInputType.number,
                      ),
                      SizedBox(height: 20,),
                      TextFormField(
                        key: Key(Calculate(_HeightController, _WeightController, _BMIC)),
                        controller: _BMIC,
                        onChanged: (value) {
                          setState(() {
                            _BMIC.value = _BMIC.value.copyWith(
                              text: value.toString(),
                            );
                          });
                        },
                        decoration: InputDecoration(
                          enabled: false,
                          hintText: '    BMI',
                          labelStyle: TextStyle(color: Color.fromRGBO(
                              48, 92, 84, 100),),
                          enabledBorder: BoxOutline,
                          disabledBorder: BoxOutline,
                          focusedBorder: BoxOutline,
                          errorBorder: ErorrOutline,
                          focusedErrorBorder: ErorrOutline,
                        ),
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.number,
                      ),
                      SizedBox(height: 20,),
                      Center(
                        child: Text(_message,
                          style: TextStyle(
                            fontSize: 20,
                          ),
                        ),
                      ),
                      SizedBox(height: 30,),
                    ],
                  ),
                ),
                Positioned(
                  left: 50,
                  right: 50,
                  top: 750,
                  child: ElevatedButton(
                    child: Text('下一步', style: TextStyle(fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromRGBO(48, 92, 84, 100)),),
                    onPressed: () {
                      SaveBMI();
                      Navigator.of(context).push(
                        CustomPageRoute(
                          child: Ending(),
                          direction: AxisDirection.left, // 向左
                        ),
                      );
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.white),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(200),
                          side: BorderSide(color: Color.fromRGBO(48, 92, 84, 100),),
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 40),
                  child: IconButton( //To put it on top of ListView so it can be onPressed
                    alignment: Alignment.bottomCenter,
                    icon: Icon(
                      Icons.arrow_back_ios_new, color: Colors.black, size: 40,),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            );
          } else /*if (SecondOrNot(data) == false)*/{ // else
            return Stack(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(
                    top: 50, bottom: 20,
                    left: 50, right: 50,
                  ),
                  child: Column(
                    children: [
                      Text('身體指數',
                        style: TextStyle(fontSize: 40,
                            color: Color.fromRGBO(48, 92, 84, 100),),
                      ),
                      SizedBox(height: 10,),
                      TextFormField(
                        controller: _HeightController,
                        decoration: InputDecoration(
                          hintText: data.height,
                          labelStyle: TextStyle(color: Color.fromRGBO(
                              48, 92, 84, 100),),
                          enabledBorder: BoxOutline,
                          focusedBorder: BoxOutline,
                          errorBorder: ErorrOutline,
                          focusedErrorBorder: ErorrOutline,
                        ),
                        textInputAction: TextInputAction.next,
                        // keyboardType: TextInputType.number,
                        onChanged: (height) {
                          setState(() {
                            HFlow = double.parse(height.toString());
                          });
                        },
                      ),
                      SizedBox(height: 10,),
                      TextFormField(
                        onChanged: (weight) {
                          setState(() {
                            WFlow = double.parse(weight.toString());
                          });
                        },
                        controller: _WeightController,
                        decoration: InputDecoration(
                          hintText: data.weight,
                          labelStyle: TextStyle(color: Color.fromRGBO(
                              48, 92, 84, 100),),
                          enabledBorder: BoxOutline,
                          focusedBorder: BoxOutline,
                          errorBorder: ErorrOutline,
                          focusedErrorBorder: ErorrOutline,
                        ),
                        // keyboardType: TextInputType.number,
                        textInputAction: TextInputAction.done,
                      ),
                      SizedBox(height: 20,),
                      TextFormField(
                        key: Key(Calculate(_HeightController, _WeightController, _BMIC)),
                        controller: _BMIC,
                        // initialValue: bMi,
                        onChanged: (value) {
                          setState(() {
                            _BMIC.value = _BMIC.value.copyWith(
                              text: value.toString(),
                            );
                          });
                        },
                        decoration: InputDecoration(
                          enabled: false,
                          hintText: data.BMI,
                          labelStyle: TextStyle(color: Color.fromRGBO(
                              48, 92, 84, 100),),
                          enabledBorder: BoxOutline,
                          disabledBorder: BoxOutline,
                          focusedBorder: BoxOutline,
                          errorBorder: ErorrOutline,
                          focusedErrorBorder: ErorrOutline,
                        ),
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.number,
                      ),
                      SizedBox(height: 20,),
                      Center(
                        child: Text(_message,
                          style: TextStyle(
                            fontSize: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  left: 50,
                  right: 50,
                  top: 750,
                  child: ElevatedButton(
                    child: Text('儲存變更', style: TextStyle(fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromRGBO(48, 92, 84, 100)),),
                    onPressed: () {
                      if (_HeightController.text.isNotEmpty&&_WeightController.text.isNotEmpty) {
                        SaveBMI();
                      }
                      Navigator.pop(context); // go back
                      // Navigator.pop(context); // pop drawer
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.white),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(200),
                          side: BorderSide(color: Color.fromRGBO(48, 92, 84, 100),),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          }
        } else {
          return Center(child: CircularProgressIndicator(),);
        }
      },
    ),
  );

  Future<User?> readUserDetail() async {
    final Detail = FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser?.email.toString());
    final snapshot = await Detail.get();

    if (snapshot.exists) {
      return User.fromJson(snapshot.data()!);
    }
  }
  bool SecondOrNot(User data) {
    bool check = (data.isFirst as bool);
    return check;
  }

  Future SaveBMI() async {
    FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .update({
      // 'user_ID/account': FirebaseAuth.instance.currentUser!.email,
      // 'user_phoneNumber': null,
      // 'user_gender': null,
      // 'user_name': null,
      // 'user_age': null,
      'height': _HeightController.text.trim(),
      'weight': _WeightController.text.trim(),
      'BMI': _BMIC.text.trim(),
      // 'isFirst': false,
    });
  }
}
class User{
  String? height;
  String? weight;
  String? BMI;
  bool? isFirst;

  User({
    required this.height,
    required this.weight,
    required this.BMI,
    this.isFirst,
  });

  Map<String, dynamic> toJson() => {
    'height': height,
    'weight': weight,
    'BMI': BMI,
    'isFirst': isFirst,
  };

  static User fromJson(Map<String, dynamic> json) => User(
    height: json['height'],
    weight: json['weight'],
    BMI: json['BMI'],
    isFirst: json['isFirst'],
  );
}