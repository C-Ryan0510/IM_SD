import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'newComer.dart';

class BMI extends StatefulWidget {
  BMI({Key? key}) : super(key: key);

  @override
  State<BMI> createState() => _BMIState();
}
class _BMIState extends State<BMI> {

  final TextEditingController _HeightController = TextEditingController();
  final TextEditingController _WeightController = TextEditingController();
  final TextEditingController _BMIC = TextEditingController();

  final BoxOutline = OutlineInputBorder(borderSide: BorderSide(color: Color.fromRGBO(45, 224, 213, 86), width: 2.0), borderRadius: BorderRadius.circular(200),);
  final ErorrOutline = OutlineInputBorder(borderSide: BorderSide(color: Colors.red.withOpacity(0.86), width: 2.0), borderRadius: BorderRadius.circular(200),);

  double HFlow = 0.0, WFlow = 0.0;
  late String _message;
  late String H, W;
  String Bmi = '';

  String Calculate() {
    H = _HeightController.text;
    W = _WeightController.text;
    var bmi = 20.0;

    if (H != '' && W != '') {
      bmi = (WFlow/ (HFlow/100*HFlow/100));
      Bmi = bmi.toStringAsFixed(2);
      _BMIC.value = _BMIC.value.copyWith(
        text: Bmi.toString(),
      );
    }

    if (bmi! < 18.5) {
      _message ='          ' // 至中用
          '體重過輕\n'
          'You are underweight';
    } else if (bmi! < 24) {
      _message ='       ' // 至中用
          '健康體位\n'
          'Your body is fine';
    } else if (bmi! < 27) {
      _message ='                 ' // 至中用
          '稍微過重\n'
          'You\'re a slightly overweight';
    } else if (bmi! < 30) {
      _message ='          ' // 至中用
          '輕度肥胖\n'
          'You are mild obesity';
    } else if (bmi! < 35) {
      _message ='               ' // 至中用
          '中度肥胖\n'
          'You are moderate obesity';
    } else {
      _message ='            ' // 至中用
          '重度肥胖\n'
          'You are severe obesity';
    }
    return Bmi;
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    resizeToAvoidBottomInset: false,
    body: Stack(
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(
            top: 50,bottom: 20,
            left: 50,right: 50,
          ),
          child: Column(
            children: [
              Text('身體指數',
                style: TextStyle(fontSize: 40, color: Color.fromRGBO(45, 224, 213, 100)),
              ),
              SizedBox(height: 10,),
              TextFormField(
                controller: _HeightController,
                decoration: InputDecoration(
                  hintText: '  請輸入身高',
                  labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                  enabledBorder: BoxOutline,
                  focusedBorder: BoxOutline,
                  errorBorder: ErorrOutline,
                  focusedErrorBorder: ErorrOutline,
                ),
                textInputAction: TextInputAction.next,
                keyboardType: TextInputType.number,
                onChanged: (height) {
                  setState(() {
                    HFlow = double.parse(height.toString());
                  });
                },
              ),
              SizedBox(height: 10,),
              TextFormField(
                onChanged: (weight) {
                  setState(() {
                    WFlow = double.parse(weight.toString());
                  });
                },
                controller: _WeightController,
                decoration: InputDecoration(
                  hintText: '  請輸入體重',
                  labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                  enabledBorder: BoxOutline,
                  focusedBorder: BoxOutline,
                  errorBorder: ErorrOutline,
                  focusedErrorBorder: ErorrOutline,
                ),
                textInputAction: TextInputAction.done,
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20,),
              TextFormField(
                key: Key(Calculate()),
                controller: _BMIC,
                onChanged: (value) {
                  setState(() {
                    _BMIC.value = _BMIC.value.copyWith(
                      text: value.toString(),
                    );
                  });
                },
                decoration: InputDecoration(
                  enabled: false,
                  hintText: '    BMI',
                  labelStyle: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),),
                  enabledBorder: BoxOutline,
                  disabledBorder: BoxOutline,
                  focusedBorder: BoxOutline,
                  errorBorder: ErorrOutline,
                  focusedErrorBorder: ErorrOutline,
                ),
                textInputAction: TextInputAction.next,
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20,),
              Center(
                child: Text(_message,
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
              ),
            ],
          ),
        ),
        Positioned(
          left: 50,
          right: 50,
          top: 750,
          child: ElevatedButton(
            child: Text('下一步',style: TextStyle(fontSize:20 ,fontWeight: FontWeight.bold ,color: Color.fromRGBO(48, 92, 84, 100)),),
            onPressed: () {
              SaveBMI();
              Navigator.push(context,
                MaterialPageRoute(
                  builder: (context) => Ending(),
                  // Guideline(index: 2),
                ),
              );
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(Colors.white),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(200),
                  side: BorderSide(color: Color.fromRGBO(45, 224, 213, 86)),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 40),
          child: IconButton( //To put it on top of ListView so it can be onPressed
            alignment: Alignment.bottomCenter,
            icon: Icon(Icons.arrow_back_ios_new,color: Colors.black,size: 40,),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
      ],
    ),
  );

  Future SaveBMI() async {
    FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser!.email.toString())
        .update({
      // 'user_ID/account': FirebaseAuth.instance.currentUser!.email,
      // 'user_phoneNumber': null,
      // 'user_gender': null,
      // 'user_name': null,
      // 'user_age': null,
      'height': _HeightController.text.trim(),
      'weight': _WeightController.text.trim(),
      'BMI': _BMIC.text.trim(),
      // 'isFirst': false,
    });
  }
}