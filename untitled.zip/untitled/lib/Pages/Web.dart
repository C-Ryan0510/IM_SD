import 'dart:io';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

// void main(){
//   runApp(MaterialApp(
//     home: WebViewExample(url: 'https://www.mohw.gov.tw/mp-1.html',),
//   ));
// }

class WebViewExample extends StatefulWidget {
  String url = 'https://www.mohw.gov.tw/mp-1.html';
  WebViewExample({required this.url});
  @override
  WebViewExampleState createState() => WebViewExampleState();
}

class WebViewExampleState extends State<WebViewExample> {
  @override
  void initState() {
    super.initState();
    // Enable virtual display.
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Color.fromRGBO(48, 92, 84, 100),),
      body:
      WebView(
        initialUrl: (this.widget.url == '')? 'https://www.mohw.gov.tw/mp-1.html' : this.widget.url,
        javascriptMode: JavascriptMode.unrestricted,
      ),
    );
  }
}