import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:untitled/Pages/Picture.dart';
import 'package:untitled/Pages/BMI.dart';
import 'package:untitled/Pages/QandA.dart';
import 'package:untitled/Pages/accountManagement.dart';

import 'package:untitled/homePageModel/Data_Analysis_Screen.dart';
import 'package:untitled/homePageModel/SecureWeb.dart';
// import 'package:untitled/homePageModel/Secure_and_Safety_Screen.dart';
import 'package:untitled/homePageModel/mainHomeScreen.dart';
import 'package:untitled/homePageModel/recordScreen.dart';
import 'package:untitled/homePageModel/FamilyScreen.dart';

//main() ==> HomeScreen()
class HomeScreen extends StatefulWidget {
  //constructor
  const HomeScreen({Key? key}) : super(key: key);
  @override //Must override
  State<HomeScreen> createState() => _HomeStateful();
}

class _HomeStateful extends State<HomeScreen> with SingleTickerProviderStateMixin {
  //check State of availability
  int _selectedIndexBN = 0; //注:此數字不可存在於超出(Screens、NavigationBar)最大數-1[like index of Array]

  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  Stream<List<CurrentUser>> readProfile() => FirebaseFirestore.instance
      .collection('Groups_List')
      .snapshots()
      .map((snapshot) =>
      snapshot.docs.map((doc) => CurrentUser.fromJson(doc.data())).toList(),
  );
  Future<CurrentUser?> ProfileDetail(String id) async {
    final test = await FirebaseFirestore.instance.collection('Users_Profile').doc(id).get();
    if (test.exists) {
      return CurrentUser.fromJson(test.data()!);
    }
  }
  Future<CurrentUser?> AccountDetail() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Users_Profile')
        .doc(FirebaseAuth.instance.currentUser!.email.toString()).get();
    if (snapshot.exists) {
      return CurrentUser.fromJson(snapshot.data()!);
    }
  }

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(vsync: this, duration: Duration(milliseconds: 450));
  }

  //Bodys(配合底部導覽進行轉換)
  final Screens = [
    /*Normal widget or Pages()*/
    /*主頁*/
    mainHome(),
    /*家庭*/
    FGroupScreen(),
    /*記錄*/
    RecordScreen(),
    /*數據*/
    AnalysisScreen(),
    /*安全*/
    // SSScreen(),
    Web(),
    // HealthScreen(),
  ];

  double _Size = 0;
  bool _Extended = false;          // Hide
  double _HeaderSizeValue = 220.0; // initialize
  late AnimationController _animationController;
  final CardDecor = BoxDecoration(
    border: Border.all(
      color: Color.fromRGBO(48, 92, 84, 100),
    ),
    borderRadius: BorderRadius.circular(12),
  );
  Future OpenUserCard() async {
    _HeaderSizeValue = 500.0;
    _Size = 100;
    _animationController.forward();
    _Extended = true;
  }
  Future LeaveUserCard() async { // WHENEVER
    _HeaderSizeValue = 220.0;
    _Size = 0;
    _animationController.reverse();
    _Extended = false;
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!; //當前登入帳戶for info
    return FutureBuilder<CurrentUser?>(
      // read Current User Profile
      future: AccountDetail(),
      builder: (context, snapshot) {
        final CurUser = snapshot.data;
        String? photo = CurUser?.picpath;
        String? display = CurUser?.name;
        String? mandarinGen = CurUser?.gender.toString();
        (display == null) ? display = user.email! : null;
        (mandarinGen == 'Male') ? mandarinGen = '男性' : mandarinGen = '女性';

        return Scaffold(
          key: _scaffoldKey,
          body: SafeArea(
            child: Stack(
              children: [
                Screens[_selectedIndexBN],
                Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: 10, horizontal: 5), //ceiling
                  child: IconButton(
                    //show SideBar without (TOP)AppBar
                    alignment: Alignment.bottomRight,
                    icon: Icon(
                      Icons.menu,
                      color: Colors.black,
                      size: 37,
                    ),
                    onPressed: () => _scaffoldKey.currentState?.openDrawer(),
                  ),
                ),
                Padding(
                  padding:
                      EdgeInsets.symmetric(vertical: 20), //Not touch ceiling
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Text(
                      'Take Care',
                      style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color.fromRGBO(48, 92, 84, 100),),
                    ),
                  ),
                ),
              ],
            ),
          ),
          drawer: Drawer(
            //SideBar
            child: ListView(
              children: [
                AnimatedContainer(
                  height: _HeaderSizeValue, // 220 or 500
                  duration: Duration(milliseconds: 450), // _animateDuration,
                  child: DrawerHeader(
                    padding: EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 15,
                    ),
                    decoration: BoxDecoration(
                      //Only PageWidget(Container)背景
                      gradient: LinearGradient(
                        //漸層色
                        colors: [
                          Colors.orange, //begin
                          Colors.deepOrangeAccent,
                          Colors.redAccent,
                          Colors.blueAccent.shade400,
                          Colors.lightBlueAccent, //end
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Card(
                      elevation: 5,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5,),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              '當前用戶',
                              style: const TextStyle(fontSize: 20),
                            ),
                            SizedBox(width: 10),
                            Center(
                              child: GestureDetector(
                                child: CircleAvatar(
                                  minRadius: 16,
                                  maxRadius: 32,
                                  child: (photo == '' || photo == null)
                                      ? Icon(
                                    Icons.manage_accounts_outlined,
                                    size: 50,
                                  )
                                      : ClipRRect(
                                    child: Image.network(
                                      photo,
                                    ),
                                    borderRadius: BorderRadius.circular(50),
                                  ),
                                  backgroundColor: Colors.white,
                                ),
                                onTap: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (context) => Picture(),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(width: 10),
                            Text(
                              display,
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            IconButton(
                              icon: AnimatedIcon(
                                size: 24,
                                icon: AnimatedIcons.menu_close,
                                progress: _animationController,
                              ),
                              onPressed: () {
                                setState(() {
                                  if (_Extended==false) {
                                    OpenUserCard();
                                  } else {
                                    LeaveUserCard();
                                  }
                                });
                              },
                            ),
                            /////////////個資//////////////
                            Expanded(
                              flex: 80,
                              child: Container(
                                padding: EdgeInsets.all(3),
                                decoration: CardDecor,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 20,
                                      child: AnimatedContainer(
                                        width: double.infinity, height: _Size,
                                        padding: EdgeInsets.symmetric(horizontal: 10,),
                                        duration: Duration(milliseconds: 450), // _animateDuration,
                                        child: Row(
                                          children: [
                                            Expanded(flex:4,
                                              child: Container(
                                                decoration: CardDecor,
                                                // BoxDecoration(
                                                //   // color: ThemeColor,
                                                //   color: Colors.blueAccent,
                                                //   // border: Border.all(
                                                //   //   color: Color.fromRGBO(48, 92, 84, 100),
                                                //   // ),
                                                //   borderRadius: BorderRadius.circular(10),
                                                //   boxShadow: [BoxShadow(
                                                //     color: Colors.black38,
                                                //     offset: Offset(-3.0, 3.0),
                                                //     blurRadius: 0,
                                                //     spreadRadius: 0,
                                                //   )],
                                                // ),
                                                // color: Colors.lightBlue,
                                                child: TextField(
                                                  enabled: false,
                                                  decoration: InputDecoration(
                                                    hintStyle: TextStyle(color: Colors.black),
                                                    hintText: '性別：$mandarinGen',
                                                    border: InputBorder.none,
                                                  ),
                                                ),
                                              ),
                                            ), // blue_Accent
                                            Expanded(flex: 1,child: SizedBox()),
                                            Expanded(flex:5,
                                              child: Container(
                                                decoration: CardDecor,
                                                // BoxDecoration(
                                                //   // color: ThemeColor,
                                                //   color: Colors.greenAccent,
                                                //   boxShadow: [BoxShadow(
                                                //     color: Colors.black38,
                                                //     offset: Offset(-3.0, 3.0),
                                                //     blurRadius: 0,
                                                //     spreadRadius: 0,
                                                //   )],
                                                // ),
                                                // color: Colors.lightBlueAccent,
                                                child: TextField(
                                                  enabled: false,
                                                  decoration: InputDecoration(
                                                      hintStyle: TextStyle(color: Colors.black),
                                                      hintText: '年紀：${CurUser?.age.toString()} 歲',
                                                      border: InputBorder.none
                                                  ),
                                                ),
                                              ),
                                            ), // green_Accent
                                          ],
                                        ),
                                      ),
                                    ), // First
                                    Expanded(
                                      flex: 20,
                                      child: AnimatedContainer(
                                        width: double.infinity, height: _Size,
                                        padding: EdgeInsets.symmetric(horizontal: 10,),
                                        duration: Duration(milliseconds: 450), // _animateDuration,
                                        // color: Colors.red,
                                        child: Row(
                                          children: [
                                            Expanded(flex:36,
                                              child: Container(
                                                decoration: CardDecor,
                                                // BoxDecoration(
                                                //   // color: ThemeColor,
                                                //   color: Colors.pinkAccent,
                                                //   boxShadow: [BoxShadow(
                                                //     color: Colors.black38,
                                                //     offset: Offset(-3.0, 3.0),
                                                //     blurRadius: 0,
                                                //     spreadRadius: 0,
                                                //   )],
                                                // ),
                                                // color: Colors.lightBlue,
                                                child: TextField(
                                                  enabled: false,
                                                  decoration: InputDecoration(
                                                    hintStyle: TextStyle(color: Colors.black),
                                                    hintText: 'BMI${CurUser?.bmi.toString()}',
                                                    border: InputBorder.none,
                                                  ),
                                                ),
                                              ),
                                            ), // pink_Accent
                                            Expanded(flex: 64,
                                              child: Container(
                                                decoration: CardDecor,
                                                // BoxDecoration(
                                                //   // color: ThemeColor,
                                                //   color: Colors.purpleAccent,
                                                //   boxShadow: [BoxShadow(
                                                //     color: Colors.black38,
                                                //     offset: Offset(-3.0, 3.0),
                                                //     blurRadius: 0,
                                                //     spreadRadius: 0,
                                                //   )],
                                                // ),
                                                // color: Colors.lightBlueAccent,
                                                child: TextField(
                                                  enabled: false,
                                                  decoration: InputDecoration(
                                                      hintStyle: TextStyle(color: Colors.black),
                                                      hintText: '身高/體重：${CurUser?.height.toString()}/${CurUser?.weight.toString()}',
                                                      border: InputBorder.none
                                                  ),
                                                ),
                                              ),
                                            ), // purple_Accent
                                          ],
                                        ),
                                      ),
                                    ), // Second
                                    Expanded(
                                      flex: 20,
                                      child: AnimatedContainer(
                                        width: double.infinity,height: _Size,
                                        duration: Duration(milliseconds: 450), // _animateDuration,
                                        child: Container(
                                          decoration: CardDecor,
                                          // BoxDecoration(
                                          //   // color: ThemeColor,
                                          //   color: Colors.redAccent,
                                          //   boxShadow: [BoxShadow(
                                          //     color: Colors.black38,
                                          //     offset: Offset(-3.0, 3.0),
                                          //     blurRadius: 0,
                                          //     spreadRadius: 0,
                                          //   )],
                                          // ),
                                          child: TextField(
                                            enabled: false,
                                            decoration: InputDecoration(
                                              hintStyle: TextStyle(color: Colors.black,fontSize: 14),
                                              hintText: '電子信箱：${CurUser?.mail.toString()}',
                                              border: InputBorder.none,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ), // redAccent - Third
                                    Expanded(
                                      flex: 20,
                                      child: AnimatedContainer(
                                        width: double.infinity,height: _Size,
                                        duration: Duration(milliseconds: 450), // _animateDuration,
                                        child: Container(
                                          decoration: CardDecor,
                                          // BoxDecoration(
                                          //   // color: ThemeColor,
                                          //   color: Colors.yellowAccent,
                                          //   boxShadow: [BoxShadow(
                                          //     color: Colors.black38,
                                          //     offset: Offset(-3.0, 3.0),
                                          //     blurRadius: 0,
                                          //     spreadRadius: 0,
                                          //   )],
                                          // ),
                                          child: TextField(
                                            enabled: false,
                                            decoration: InputDecoration(
                                              hintStyle: TextStyle(color: Colors.black,fontSize: 14),
                                              hintText: '電話號碼：${CurUser?.phone.toString()}',
                                              border: InputBorder.none,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ), // yellowAccent - Fourth
                                  ],
                                ),
                              ),
                            ),
                            /////////////個資//////////////
                            Expanded(
                              flex: 20,
                              child: Padding(
                                padding: EdgeInsets.zero,
                                child: ElevatedButton(
                                  onPressed: () {
                                    LeaveUserCard();
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (context) => ManageAccount(),
                                      ),
                                    );
                                  },
                                  child: Text('個人設定',style: TextStyle(color: Colors.black,),),
                                  style: ElevatedButton.styleFrom(
                                    primary: Colors.white, // background color
                                  ),
                                ),
                              ),
                            ), // BOTTOM-Button
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                // Divider(
                //   // color: ThemeColor,
                //   thickness: 20,
                // ),
                ListTile(
                  // leading: Icon(Icons.settings_accessibility_sharp),
                  title: Text("身體指數計算機"),
                  onTap: () {
                    setState(() {
                      LeaveUserCard();
                    });
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => BMI(),
                      ),
                    );
                  }
                ), // BMI Calculator
                // ListTile(
                //   // leading: Icon(Icons.settings_accessibility_sharp),
                //   title: Text('系統顏色設定'),
                //   onTap: () {
                //     setState(() {
                //       LeaveUserCard();
                //     });
                //     Navigator.of(context).push(
                //       MaterialPageRoute(
                //         builder: (context) => ColorBackView(),
                //       ),
                //     );
                //   }
                // ), // AppThemeColorPicker
                ListTile(
                  // leading: Icon(Icons.details),
                  title: Text("Q&A"),
                  onTap: () {
                    setState(() {
                      LeaveUserCard();
                    });
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => QandA(),
                      ),
                    );
                  }
                ), // FAQ
                ListTile(
                  title: Text("登出帳號"), //登出-->MainScreen() ==> return loginPage(),
                  onTap: () {
                    setState(() {
                      LeaveUserCard();
                    });
                    FirebaseAuth.instance.signOut();
                  }
                ), // Sign-Out
                // Divider(thickness: 2,),
              ],
            ),
          ),
          onDrawerChanged: (a) { // FORCE CLOSE RESET
            // whenever
            setState(() {
              LeaveUserCard();
            });
          },
          bottomNavigationBar: NavigationBarTheme(
            //底部導覽
            data: NavigationBarThemeData(
              height: 75,
              backgroundColor: Colors.transparent,
              indicatorColor:
                  Color.fromRGBO(45, 224, 213, 90), //shade50~900//淺色到深色
              // iconTheme: MaterialStateProperty.all(Icon),
              labelTextStyle: MaterialStateProperty.all(
                TextStyle(fontSize: 25),
              ),
            ),
            child: NavigationBar(
              selectedIndex: _selectedIndexBN,
              onDestinationSelected: (_selectedIndex) //onTap change index
                  =>
                  setState(() => this._selectedIndexBN = _selectedIndex),
              /*點擊選取(0.5秒)*/
              animationDuration: Duration(milliseconds: 500),
              labelBehavior:
                  NavigationDestinationLabelBehavior.onlyShowSelected,
              destinations: [
                NavigationDestination(
                  icon: Icon(Icons.home_outlined),
                  selectedIcon: Icon(Icons.home_sharp),
                  label: '首頁',
                ),
                NavigationDestination(
                  icon: Icon(Icons.favorite_border_sharp),
                  selectedIcon: Icon(Icons.favorite_sharp),
                  label: '家庭',
                ),
                NavigationDestination(
                  icon: Icon(Icons.add_box_outlined),
                  selectedIcon: Icon(Icons.add_box_sharp),
                  label: '紀錄',
                ),
                NavigationDestination(
                  icon: Icon(Icons.analytics_outlined),
                  selectedIcon: Icon(Icons.analytics_rounded),
                  label: '數據',
                ),
                NavigationDestination(
                  icon: Icon(Icons.shield_outlined),
                  selectedIcon: Icon(Icons.shield_sharp),
                  label: '安全',
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class CurrentUser {
  String? picpath; // Pic
  String? name; // title

  String? mail;
  String? phone;

  String? height;
  String? weight;

  String? age;
  String? gender;
  String? bmi;


  CurrentUser({
    this.picpath,
    this.phone,
    this.age,
    this.gender,
    this.bmi,
    this.height,
    this.weight,
    required this.name,
    required this.mail,
    // required this.Food,
  });

  Map<String, dynamic> toJson() => {
        'user_ID/account': phone,
        'user_phoneNumber': mail,
        'user_avatar': picpath,
        'user_gender': gender,
        'user_name': name,
        'user_age': age,
        'height': height,
        'weight': weight,
        'BMI': bmi,
      };

  static CurrentUser fromJson(Map<String, dynamic> json) => CurrentUser(
        picpath: json['user_avatar'],
        mail: json['user_ID/account'],
        phone: json['user_phoneNumber'],
        name: json['user_name'],
        age: json['user_age'],
        gender: json['user_gender'],
        bmi: json['BMI'],
        height: json['height'],
        weight: json['weight'],
      );
}
