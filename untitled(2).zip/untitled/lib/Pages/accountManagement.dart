import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ManageAccount extends StatefulWidget {
  const ManageAccount({Key? key}) : super(key: key);

  @override
  State<ManageAccount> createState() => _ManageAccountState();
}

class _ManageAccountState extends State<ManageAccount> {
  final _FullNameController = TextEditingController();
  final _AgeController = TextEditingController();
  final _HeiController = TextEditingController();
  final _WeiController = TextEditingController();
  // final _accountController = TextEditingController();
  final _phoneController = TextEditingController();

  final User = FirebaseAuth.instance.currentUser;

  Future<UserD?> checkdata() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Users_Profile').doc(User!.email.toString()).get();
    if (snapshot.exists) {
      return UserD.fromJson(snapshot.data()!);
    }
  }
  Future createRecord({required String phone,required String name,required String age,required String height,required String weight,}) async {
    final doc = FirebaseFirestore.instance.collection('Health').doc(FirebaseAuth.instance.currentUser!.email.toString());

    final data = UserD(
      user_phoneNumber: phone,
      user_age: name,
      weight: weight,
      height: height,
      user_name: name,
    );

    final json = data.toJson();
    await doc.set(json);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('基本資料與帳號管理'),
        backgroundColor: Colors.transparent,
      ),
      body: Stack(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 40,horizontal: 30),
            child: FutureBuilder<UserD?>(
              future: checkdata(),
              builder: (context,snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text(''),);
                } else if (snapshot.hasData) {
                  final data = snapshot.data!;

                  return ListView(
                    physics: NeverScrollableScrollPhysics(),
                    children: [
                      ListTile(
                        title: Text('個人資料'),
                      ),
                      Divider(thickness: 2),
                      TextFormField(
                        controller: _FullNameController..text = '${data.user_name}',
                        // initialValue: GetDetail("user_name"),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: '姓名',
                        ),
                      ),
                      SizedBox(height: 10,),
                      TextField(
                        controller: _AgeController..text = '${data.user_age}',
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: '年齡/出生日期',
                        ),
                      ),
                      SizedBox(height: 10,),
                      TextField(
                        controller: _HeiController..text = '${data.height}',
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: '身高',
                        ),
                      ),
                      SizedBox(height: 10,),
                      TextFormField(
                        controller: _WeiController..text = '${data.weight}',
                        // initialValue: User?.Weight,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: '體重',
                        ),
                      ),
                      Divider(thickness: 5,color: Colors.black,),
                      ListTile(
                        title: Text('用戶帳號資訊'),
                      ),
                      Divider(thickness: 2),
                      // TextFormField(
                      //   enabled: false,//重要帳號認證(不可變更No controller)
                      //   initialValue: 'Admin',
                      //   decoration: InputDecoration(
                      //     labelText: '使用者權限',
                      //     labelStyle: TextStyle(fontSize: 20),
                      //   ),
                      // ),
                      TextFormField(
                        enabled: false,//重要帳號認證(不可變更No controller)
                        initialValue: User?.email,
                        decoration: InputDecoration(
                          labelText: '電子信箱Email',
                          labelStyle: TextStyle(fontSize: 20),
                        ),
                      ),
                      TextFormField(
                        controller: _phoneController..text = '${data.user_phoneNumber}',
                        // initialValue: Datas.,
                        decoration: InputDecoration(
                          labelText: '電話',
                        ),
                      ),
                      SizedBox(height: 40,)
                    ],
                  );
                } else {
                  return Center(child: CircularProgressIndicator(),);
                }
              },
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              margin: EdgeInsets.all(10),
              width: double.infinity,
              child: ElevatedButton(
                child: Text('儲存'),
                onPressed: () => {
                  // Save/Edit
                  // print(User), print(Datas),print(Datas.get()),print(FirebaseFirestore.instance.collection('users').get()),//For Test
                  // UserDetailUpdate(),
                  Navigator.of(context).pop(),
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
  // Future UserDetailUpdate() async{
  //   try{
  //     await Datas.set({
  //       'user_ID/account': User?.email,
  //       'user_role': 'Admin',
  //       'user_name': _FullNameController.text.trim(),
  //       'user_brithday/age': _AgeController.text.trim(),
  //       'user_height': _HeiController.text.trim(),
  //       'user_weight': _WeiController.text.trim(),
  //       'user_phoneNumber': _phoneController.text.trim(),
  //     });
  //   } on FirebaseException catch(e){
  //     print(e);
  //   }
  // }
}

class UserD{
  final String user_name;
  final String user_age;
  final String height;
  final String weight;
  final String user_phoneNumber;
  UserD({
    required this.user_name,
    required this.user_age,
    required this.height,
    required this.weight,
    required this.user_phoneNumber,
  });
  Map<String,dynamic> toJson() => {
    'user_name':user_name,
    'user_age':user_age,
    'height':height,
    'weight':weight,
    'user_phoneNumber':user_phoneNumber,
    };
  static UserD fromJson(Map<String, dynamic> json) => UserD(
    user_name: json['user_name'],
    user_age: json['user_age'],
    height: json['height'],
    weight: json['weight'],
    user_phoneNumber: json['user_phoneNumber'],
  );
}