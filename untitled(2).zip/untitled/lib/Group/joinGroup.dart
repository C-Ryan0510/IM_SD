import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class joinGroup extends StatefulWidget {
  const joinGroup({Key? key}) : super(key: key);

  @override
  State<joinGroup> createState() => _joinGroupState();
}

class _joinGroupState extends State<joinGroup> {
  TextEditingController _groupId = TextEditingController();
  final userID = FirebaseAuth.instance.currentUser!.email.toString();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.withOpacity(0.8),
      body: Stack(
        children: [
          Center(
            child: Padding(
              padding: EdgeInsets.all(15),
              child: Container(width: double.infinity, height: 200, //color: Colors.grey,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  boxShadow: [BoxShadow(
                      color: Colors.black38,
                      offset: Offset(6.0, 6.0), //陰影y軸偏移量
                      blurRadius: 0, //陰影模糊程度
                      spreadRadius: 0 //陰影擴散程度
                  )],
                  borderRadius: BorderRadius.circular(18),
                  color: Colors.white, //
                ),
                child: Column(
                  children: [
                    // Padding(padding: EdgeInsets.all(20),
                    //   child: Row(
                    //     children: [BackButton()],
                    //   ),
                    // ),
                    Spacer(),
                    Padding(padding: EdgeInsets.all(20),
                      child: Container(
                        child: Column(
                          children: [
                            TextFormField(
                              controller: _groupId,
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.group),
                                hintText: 'The Group ID',
                              ),
                            ),
                            SizedBox(height: 15,),
                            RaisedButton(
                              color: Colors.blue[400],
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 50,),
                                child: Text('Join group',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                              onPressed: () {
                                JoinGroup(_groupId.text.trim(), userID);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 40),
            child: IconButton( //To put it on top of ListView so it can be onPressed
              alignment: Alignment.bottomCenter,
              icon: Icon(
                Icons.arrow_back_ios_new, color: Colors.black, size: 40,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
  Future JoinGroup(String groupId, String userId) async {
    List<String> members = []; // List();

    try{
      members.add(userId);
      await FirebaseFirestore.instance.collection('Groups_List').doc(groupId)
          .update({
        'members' : FieldValue.arrayUnion(members),
      });

      await FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser!.email.toString())
          .update({
        'group_id' : groupId,
      });

      await Future.delayed(Duration(seconds: 1));
      showDialog(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: Text('成功加入群組',),
          actions: [
            FlatButton(child: Text('確定'),
              onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
            ),
          ],
          elevation: 24,
        ),
        barrierDismissible: false, // tap outside of it to dismiss
      );

    } catch (e) {
      print(e);
    }
  }
}


