package cn.picksomething.drawlayouttest;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentTransaction;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;

public class MapButton extends DialogFragment {
    MyView mv ;
    ImageView img;
    int major = 3, minor = 3;
    String string;
    Handler hd = new Handler();
    Runnable r = new Runnable() {
        @Override
        public void run() {
            if (getArguments() != null) {
                major = getArguments().getInt("MAJOR_KEY");
                minor = getArguments().getInt("MINOR_KEY");
                Log.i("DIA_MAJOR",""+major);
                Log.i("DIA_MINOR",""+minor);
            }
            hd.postDelayed(this,1000);
        }
    };
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        View view = inflater.inflate(R.layout.map,container,false);
        DialogFragment mapFragment = new MapFragment();
        FragmentTransaction ft = getChildFragmentManager().beginTransaction();
        ft.add(R.id.child_fragment, mapFragment).commit();
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        setDialogsize();

    }

    @Override
    public void onResume() {
        super.onResume();
        hd.postDelayed(r,1000);
    }

    public void setDialogsize()
    {
        DisplayMetrics metrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int WindowW = metrics.widthPixels;
        int WindowH = metrics.heightPixels;
        getDialog().getWindow().setLayout((int)(WindowW),(int)(WindowH*.9));
    }
}