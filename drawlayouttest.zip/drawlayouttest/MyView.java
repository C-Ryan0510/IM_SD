package cn.picksomething.drawlayouttest;

import android.content.Context;
import android.util.AttributeSet;

import com.qozix.tileview.TileView;

//地圖展示 用到libs/tileview
public class MyView extends TileView {

	public MyView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public MyView(Context context, AttributeSet attrs) {
		this(context);
	}


	public void init() {
		setSize(1000, 1000);
		setBackgroundResource(R.drawable.list3_map);
	}

}
