/** ============================================================== */
package cn.picksomething.drawlayouttest.ScanedBeacon;
/** ============================================================== */

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.THLight.USBeacon.App.Lib.BatteryPowerData;
import com.THLight.USBeacon.App.Lib.USBeaconConnection;
import com.THLight.USBeacon.App.Lib.USBeaconData;
import com.THLight.USBeacon.App.Lib.USBeaconList;
import com.THLight.USBeacon.App.Lib.USBeaconServerInfo;
import com.THLight.USBeacon.App.Lib.iBeaconData;
import com.THLight.USBeacon.App.Lib.iBeaconScanManager;
import com.THLight.Util.THLLog;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** ============================================================== */
public class UIMain extends Activity implements iBeaconScanManager.OniBeaconScan, USBeaconConnection.OnResponse
{
	/** this UUID is generate by Server while register a new account. */
	final UUID QUERY_UUID		= UUID.fromString("660653BB-BD71-44C3-B88B-449298130A58");
	/** server http api url. */
	final String HTTP_API		= "http://www.usbeacon.com.tw/api/func";
	
	static String STORE_PATH	= Environment.getExternalStorageDirectory().toString()+ "/USBeaconSample/";
	
	final int REQ_ENABLE_BT		= 2000;
	final int REQ_ENABLE_WIFI	= 2001;
	
	final int MSG_SCAN_IBEACON			= 1000;
	final int MSG_UPDATE_BEACON_LIST	= 1001;
	final int MSG_START_SCAN_BEACON		= 2000;
	final int MSG_STOP_SCAN_BEACON		= 2001;
	final int MSG_SERVER_RESPONSE		= 3000;
	
	final int TIME_BEACON_TIMEOUT		= 30000;
	
	THLApp App		= null;
	THLConfig Config= null;

	/** scaner for scanning iBeacon around. */
	iBeaconScanManager miScaner	= null;
	
	/** USBeacon server. */
	USBeaconConnection mBServer	= new USBeaconConnection();
	
	USBeaconList mUSBList		= null;
	
	List<ScanediBeacon> miBeacons	= new ArrayList<ScanediBeacon>();

	int major, minor;




	/** ================================================ */
	Handler mHandler= new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			switch(msg.what)
			{
				case MSG_SCAN_IBEACON:
					{
						int timeForScaning		= msg.arg1;
						int nextTimeStartScan	= msg.arg2;
						
						miScaner.startScaniBeacon(timeForScaning);
						this.sendMessageDelayed(Message.obtain(msg), nextTimeStartScan);
					}
					break;

				case MSG_UPDATE_BEACON_LIST:
				{
					verifyiBeacons();
					initmBeaconList();
					mHandler.sendEmptyMessageDelayed(MSG_UPDATE_BEACON_LIST, 500);
				}
					break;
				
				case MSG_SERVER_RESPONSE:
					switch(msg.arg1)
					{
						case USBeaconConnection.MSG_NETWORK_NOT_AVAILABLE:
							break;
							
						case USBeaconConnection.MSG_HAS_UPDATE:
							mBServer.downloadBeaconListFile();
							Toast.makeText(UIMain.this, "HAS_UPDATE.", Toast.LENGTH_SHORT).show();
							break;
							
						case USBeaconConnection.MSG_HAS_NO_UPDATE:
							Toast.makeText(UIMain.this, "No new BeaconList.", Toast.LENGTH_SHORT).show();
							break;
							
						case USBeaconConnection.MSG_DOWNLOAD_FINISHED:
							break;
		
						case USBeaconConnection.MSG_DOWNLOAD_FAILED:
							Toast.makeText(UIMain.this, "Download file failed!", Toast.LENGTH_SHORT).show();
							break;
							
						case USBeaconConnection.MSG_DATA_UPDATE_FINISHED:
							{
								USBeaconList BList= mBServer.getUSBeaconList();

								if(null == BList)
								{
									Toast.makeText(UIMain.this, "Data Updated failed.", Toast.LENGTH_SHORT).show();
									THLLog.d("debug", "update failed.");
								}
								else if(BList.getList().isEmpty())
								{
									Toast.makeText(UIMain.this, "Data Updated but empty.", Toast.LENGTH_SHORT).show();
									THLLog.d("debug", "this account doesn't contain any devices.");
								}
								else
								{
									Toast.makeText(UIMain.this, "Data Updated("+ BList.getList().size()+ ")", Toast.LENGTH_SHORT).show();
									
									for(USBeaconData data : BList.getList())
								{
									THLLog.d("debug", "Name("+ data.name+ "), Ver("+ data.major+ "."+ data.minor+ ")");
								}
								}
							}
							break;
							
						case USBeaconConnection.MSG_DATA_UPDATE_FAILED:
							Toast.makeText(UIMain.this, "UPDATE_FAILED!", Toast.LENGTH_SHORT).show();
							break;
					}
					break;
			}
		}
	};
	
	/** ================================================ */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		/** ================================================ */
		App		= THLApp.getApp();
		Config	= THLApp.Config;
		
		/** create instance of iBeaconScanManager. */
		miScaner		= new iBeaconScanManager(this, this);
		mUSBList = new USBeaconList();


		/** create store folder. */
		File file= new File(STORE_PATH);
		if(!file.exists())
		{
			if(!file.mkdirs())
			{
				Toast.makeText(this, "Create folder("+ STORE_PATH+ ") failed.", Toast.LENGTH_SHORT).show();
			}
		}
		
		/** check network is available or not. */
		ConnectivityManager cm	= (ConnectivityManager)getSystemService(UIMain.CONNECTIVITY_SERVICE);
		if(null != cm)
		{
			NetworkInfo ni = cm.getActiveNetworkInfo();
			if(null == ni || (!ni.isConnected()))
			{
				dlgNetworkNotAvailable();
			}
			else
			{
				THLLog.d("debug", "NI not null");

				NetworkInfo niMobile= cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
				if(null != niMobile)
				{
					boolean is3g	= niMobile.isConnectedOrConnecting();
					
					if(is3g)
					{
						dlgNetwork3G();
					}
					else
					{
						USBeaconServerInfo info= new USBeaconServerInfo();
						
						info.serverUrl		= HTTP_API;
						info.queryUuid		= QUERY_UUID;
						info.downloadPath	= STORE_PATH;
						
						mBServer.setServerInfo(info, this);
						mBServer.checkForUpdates();
					}
				}
			}
		}
		else
		{
			THLLog.d("debug", "CM null");
		}

		mHandler.sendEmptyMessageDelayed(MSG_UPDATE_BEACON_LIST, 500);
	/** ================================================ */

	}
	/** ========================================================================================== */

	public void initmBeaconList()
	{
		USBeaconList BList= mBServer.getUSBeaconList();
		Bundle bundle = new Bundle();
		if (BList.getList().size() != 0 && !miBeacons.isEmpty() ) {
			for (int i = 0; i < miBeacons.size(); i++) {
				for (int j = 0; j < BList.getList().size(); j++) {
					if (miBeacons.get(i).macAddress.equals(BList.getList().get(j).macAddress))
						if (calculateAccuracy(miBeacons.get(i).rssi, miBeacons.get(i).oneMeterRssi) < 1.5) {
							Toast.makeText(UIMain.this, "" + BList.getList().get(j).major + "," + BList.getList().get(j).minor + ",\n"
									+ (BList.getList().get(j).DistData).get(USBeaconData.Dist.Near).description, Toast.LENGTH_SHORT).show();

							major = BList.getList().get(j).major;
							minor = BList.getList().get(j).minor;

							bundle.putInt("major",major);
							bundle.putInt("minor",minor);


						}
				}
			}
		}
	}

	public int getMajor()
	{
		return major;
	}
	public int getMinor()
	{
		return minor;
	}



	private double calculateAccuracy(double rssi, double txPower) {

		if(rssi == 0) {
			return -1.0D;
		} else {
			double ratio = (double)((float)rssi) / txPower;
			double accuracy = Math.pow(10.0D, ((double)rssi - txPower) / -32.5D);
			return accuracy;
		}
	}



	/** =================================================================================================================*/
	@Override
	public void onResume()
	{
		super.onResume();
	}
	
	/** ================================================ */
	@Override
	public void onPause()
	{
		super.onPause();
	}

	/** ================================================ */
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
	}
	
	/** ================================================ */
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
  	{
  		THLLog.d("DEBUG", "onActivityResult()");

  		switch(requestCode)
  		{
  			case REQ_ENABLE_BT:
	  			if(RESULT_OK == resultCode)
	  			{
				}
	  			break;
	  			
  			case REQ_ENABLE_WIFI:
  				if(RESULT_OK == resultCode)
	  			{
				}
  				break;
  		}
  	}

    /** ================================================ */
    /** implementation of {@link iBeaconScanManager#OniBeaconScan } */
	@Override
	public void onScaned(iBeaconData iBeacon)
	{
			addOrUpdateiBeacon(iBeacon);
	}
	/** ================================================ */
    /** implementation of {@link iBeaconScanManager#OniBeaconScan } */
	@Override
	public void onBatteryPowerScaned(BatteryPowerData batteryPowerData) {
		// TODO Auto-generated method stub
		Log.d("debug", batteryPowerData.batteryPower+"");
		for(int i = 0 ; i < miBeacons.size() ; i++)
		{
			if(miBeacons.get(i).macAddress.equals(batteryPowerData.macAddress))
			{
				ScanediBeacon ib = miBeacons.get(i);
				ib.batteryPower = batteryPowerData.batteryPower;
				miBeacons.set(i, ib);
			}
		}
	}
	
	/** ========================================================== */
	public void onResponse(int msg)
	{
		THLLog.d("debug", "Response("+ msg+ ")");
		mHandler.obtainMessage(MSG_SERVER_RESPONSE, msg, 0).sendToTarget();
	}
	
	/** ========================================================== */
	public void dlgNetworkNotAvailable()
	{
		final AlertDialog dlg = new AlertDialog.Builder(UIMain.this).create();
		
		dlg.setTitle("Network");
		dlg.setMessage("Please enable your network for updating beacon list.");

		dlg.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dlg.dismiss();
			}
		});
		
		dlg.show();
	}
	
	/** ========================================================== */
	public void dlgNetwork3G()
	{
		final AlertDialog dlg = new AlertDialog.Builder(UIMain.this).create();
		
		dlg.setTitle("3G");
		dlg.setMessage("App will send/recv data via 3G, this may result in significant data charges.");

		dlg.setButton(AlertDialog.BUTTON_POSITIVE, "Allow", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				Config.allow3G= true;
				dlg.dismiss();
				USBeaconServerInfo info= new USBeaconServerInfo();
				
				info.serverUrl		= HTTP_API;
				info.queryUuid		= QUERY_UUID;
				info.downloadPath	= STORE_PATH;
				
				mBServer.setServerInfo(info, UIMain.this);
				mBServer.checkForUpdates();
			}
		});
		
		dlg.setButton(AlertDialog.BUTTON_NEGATIVE, "Reject", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				Config.allow3G= false;
				dlg.dismiss();
			}
		});
	
		dlg.show();
	}

	/** ========================================================== */
	public void addOrUpdateiBeacon(iBeaconData iBeacon)
	{
		long currTime= System.currentTimeMillis();
		
		ScanediBeacon beacon= null;
		
		for(ScanediBeacon b : miBeacons)
		{
			if(b.equals(iBeacon, false))
			{
				beacon= b;
				break;
			}
		}
		
		if(null == beacon)
		{
			beacon= ScanediBeacon.copyOf(iBeacon);
			miBeacons.add(beacon);
		}
		else
		{
			beacon.rssi= iBeacon.rssi;
		}
		
		beacon.lastUpdate= currTime;
	}
	
	/** ========================================================== */
	public void verifyiBeacons() {
		{
			long currTime = System.currentTimeMillis();

			int len = miBeacons.size();
			ScanediBeacon beacon = null;

			for (int i = len - 1; 0 <= i; i--) {
				beacon = miBeacons.get(i);

				if (null != beacon && TIME_BEACON_TIMEOUT < (currTime - beacon.lastUpdate)) {
					miBeacons.remove(i);
				}
			}
		}
	}


}



