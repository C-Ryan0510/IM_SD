package cn.picksomething.drawlayouttest.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import cn.picksomething.drawlayouttest.R;

/**
 * Created by tt791_000 on 2016/7/11.
 */
public class FragmentList  extends android.support.v4.app.Fragment {
    private android.support.design.widget.TabLayout mTabs;
    private ViewPager mPager;
    private SamplePagerAdapter adapter;
    private ArrayList<CharSequence> aryTab;

    private android.support.v4.app.FragmentManager manager;

    int major = 4, minor = 4;

    private  android.support.v4.app.FragmentTransaction ft;

    Handler hd = new Handler();

    Runnable r = new Runnable() {
        @Override
        public void run() {
            if (getArguments() != null) {
                major = getArguments().getInt("MAJOR_KEY");
                minor = getArguments().getInt("MINOR_KEY");
            }
            Log.i("FRAL_MAJOR",""+major);
            Log.i("FRAL_MINOR",""+minor);

            hd.postDelayed(this,1000);
        }
    };

    Runnable r1 = new Runnable() {
        @Override
        public void run() {
            (fl.get(3).getArguments()).putInt("MAJOR_KEY", major);
            (fl.get(3).getArguments()).putInt("MINOR_KEY", minor);
            hd.postDelayed(this,1000);
        }
    };
    List<Fragment> fl=new ArrayList<Fragment>(); //填充要的Fragment頁卡

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.toolbar_list, container, false);


        mPager=(ViewPager)view.findViewById(R.id.list_pager);
        hd.postDelayed(r,1000);



        return view;
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initViewPager();

        Bundle bundle = new Bundle();
        bundle.putInt("MAJOR_KEY", major);
        bundle.putInt("MINOR_KEY", minor);
        fl.get(3).setArguments(bundle);
        hd.postDelayed(r1,1000);

        manager = getFragmentManager();

    }



    private void initViewPager() {
        mTabs = (android.support.design.widget.TabLayout) getView().findViewById(R.id.list_tabs);
        aryTab =  new ArrayList<>();
        mTabs.addTab(mTabs.newTab().setText("菜餚排序"));
        mTabs.addTab(mTabs.newTab().setText("食材排序"));
        mTabs.addTab(mTabs.newTab().setText("商品排序"));
        mTabs.addTab(mTabs.newTab().setText("檢視地圖"));

        for(int j = 0;j<mTabs.getTabCount();j++) {
            aryTab.add(mTabs.getTabAt(j).getText());
        }
        fl.add(new FragmentList1());
        fl.add(new FragmentList2());
        fl.add(new FragmentList3());
        fl.add(new FragmentList4());
        adapter = new SamplePagerAdapter(getFragmentManager(), fl , getActivity());

        if (mPager != null) {
            mPager.setAdapter(adapter);  //設定Adapter給viewPager
        }

        mTabs.setTabMode (TabLayout.MODE_FIXED);
        mTabs.setTabGravity(TabLayout.GRAVITY_FILL);
        mTabs.setupWithViewPager(mPager);
        mPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabs));
    }
    public SamplePagerAdapter getAdapter()
    {
        return adapter;
    }
    public class SamplePagerAdapter extends FragmentStatePagerAdapter {
        private Context context;

        List<Fragment> fragments; //切換頁面的Fragments
        private android.support.design.widget.TabLayout Tabs;
        public SamplePagerAdapter(FragmentManager fm , List<Fragment> f, Context context) {
            super(fm);
            this.context=context;

            fragments=f;
        }

        @Override
        public int getCount() { //頁卡數量
            return fragments.size();
        }

        @Override
        public Fragment getItem(int position) { //回傳Frament頁卡
            return fragments.get(position); //從上方List<Fragment> fragments取得
        }

        @Override
        public CharSequence getPageTitle(int position) { //在此回傳Tab title string
           if(position ==0 )
               return "菜餚排序";
            else if(position ==1 )
                return  "食材排序";
            else if(position ==2 )
                return  "商品排序";
            else
                return "地圖檢視";
        }

    }
    //點擊返回回到fregmantMain
    @Override
    public void onResume() {
        super.onResume();
        getFocus();
    }
    //主界面获取焦点
    private void getFocus() {
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    FragmentMain fm = new FragmentMain();
                    ft = manager.beginTransaction();
                    ft.replace(R.id.flContent, fm);
                    ft.addToBackStack(null);
                    ft.commit();
                    return true;
                }
                return false;
            }
        });
    }
}
