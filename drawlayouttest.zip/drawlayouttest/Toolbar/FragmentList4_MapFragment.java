package cn.picksomething.drawlayouttest.Toolbar;

import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.IllegalFormatCodePointException;
import java.util.List;

import cn.picksomething.drawlayouttest.Databases.DatabaseHelper;
import cn.picksomething.drawlayouttest.MyView;
import cn.picksomething.drawlayouttest.R;

/**
 * Created by Jenwei on 2016/9/12.
 */
public class FragmentList4_MapFragment extends DialogFragment {
    private DatabaseHelper myDB;
    MyView mv ;
    ImageView img_now, img_C1, img_C2, img_C3, img_C4, img_C5, img_C6, img_C7, img_C8, img_C9, img_C10, img_C11, img_C12, img_C13, img_C14, img_C15, img_C16, img_C17, img_C18, img_C19, img_C20;
    ArrayList<String> C = new ArrayList<>();
    String[] str = {"T1","T2","T3","T4","T5","T6","T7","T8","T9","T10","T11","T12","T13","T14","T15","T16","T17","T18","T19","T20"};

    int major = 2, minor = 2;
    String string;
    private ArrayList<ArrayList<String>> child=new  ArrayList<>();

    public FragmentList4_MapFragment(){
        Log. i("INFO", "FragmentList4_MapFragment non-parameter constructor" );
    }

    Handler hd = new Handler();
    Runnable r = new Runnable() {
        @Override
        public void run() {
            if (getParentFragment().getArguments() != null) {
                major = getParentFragment().getArguments().getInt("MAJOR_KEY");
                minor = getParentFragment().getArguments().getInt("MINOR_KEY");
            }
            showUserLocation();
            hd.postDelayed(this,1000);
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mv = new MyView(getContext());
        mv.init();
        init();
        hd.postDelayed(r,1000);
        getCategory();
        return mv;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDB = new DatabaseHelper(getActivity());
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.i("CURSOR",""+child+", "+C);
    }

    public void getCategory(){
        Cursor cursor = myDB.getshoppingOneClass();
        int rows_num = cursor.getCount();
        int columns_num = cursor.getColumnCount();
        int i =0;
        if (cursor!=null) {
            while (i < rows_num) {
                ArrayList<String> list = new ArrayList<>();
                for (int k = 0; k < columns_num; k++) {
                    if (cursor.getString(k) != null)
                        list.add(cursor.getString(k));
                }
                i++;
                child.add(list);
                cursor.moveToNext();
            }
        }
        Cursor cursor1 = myDB.getshoppingTwoClass();
        int rows_num1 = cursor1.getCount();
        int l = 0;
        if (cursor1!=null) {
            while (l < rows_num1) {
                C.add(cursor1.getString(0));
                l++;
                cursor1.moveToNext();
            }
        }
        showProductLocation();
    }
    public void showProductLocation(){
    ArrayList<String> hasexisted = new ArrayList<>();
        Log.i("EXISTED", ""+child.size()+", "+C.size());
        if (child!=null){
            for (int i = 0; i < child.size();i++) {
                if (child.get(i) != null) {
                    for (int j = 0; j < child.get(i).size(); j++) {
                        for (int k = 0; k < str.length; k++) {
                            if (child.get(i).contains(str[k]) && hasexisted.contains(str[k]) == false) {
                                hasexisted.add(str[k]);
                                addProductMarker(str[k]);
                            }
                        }
                    }
                }
            }
        }
        if (C!=null) {
            for (int l = 0; l < C.size(); l++) {
                for (int m = 0; m < str.length; m++) {
                    if (C.get(l).equals(str[m]) && hasexisted.contains(str[m]) == false) {
                        hasexisted.add(str[m]);
                        addProductMarker(str[m]);
                    }
                }

            }
        }
    }

    public void addProductMarker(String T)
    {
        if (T == "T1") {
            mv.addMarker(img_C1, 750,280);
        }
        else if (T == "T2"){
            mv.addMarker(img_C2, 820,280);
        }
        else if (T == "T3"){
            mv.addMarker(img_C3, 900,280);
        }
        else if (T == "T4"){
            mv.addMarker(img_C4, 700,50);
        }
        else if (T == "T5"){
            mv.addMarker(img_C5, 800,50);
        }
        else if (T == "T6"){
            mv.addMarker(img_C6, 880,50);
        }
        else if (T == "T7"){
            mv.addMarker(img_C7, 900,80);
        }
        else if (T == "T8"){
            mv.addMarker(img_C8, 900,130);
        }
        else if (T == "T9"){
            mv.addMarker(img_C9, 900,180);
        }
        else if (T == "T10"){
            mv.addMarker(img_C10, 800,150);
        }
        else if (T == "T11"){
            mv.addMarker(img_C11, 800,550);
        }
        else if (T == "T12"){
            mv.addMarker(img_C12, 900,600);
        }
        else if (T == "T13"){
            mv.addMarker(img_C13, 800,700);
        }
        else if (T == "T14"){
            mv.addMarker(img_C14, 160,130);
        }
        else if (T == "T15"){
            mv.addMarker(img_C15, 350,450);
        }
        else if (T == "T16"){
            mv.addMarker(img_C16, 200,450);
        }
        else if (T == "T17"){
            mv.addMarker(img_C17, 130,360);
        }
        else if (T == "T18"){
            mv.addMarker(img_C18, 50,450);
        }
        else if (T == "T19"){
            mv.addMarker(img_C19, 350,150);
        }
        else if (T == "T20"){
            mv.addMarker(img_C20, 600,150);
        }
    }


    public void showUserLocation()
    {
        Log.i("FRAL3C_MAJOR",""+major);
        Log.i("FRAL3C_MINOR",""+minor);
        if (major == 0)
        {
            if (minor == 0)
            {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 0,0);
            }
            if (minor ==1) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 800,850);
            }
            if (minor ==2) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 800, 630);
            }
            if (minor ==3) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 710, 430);
            }
            if (minor ==4) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 710, 150);
            }
        }
        else if (major ==1){
            if (minor ==1) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now,450, 150);
            }
            if (minor ==2) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 270, 150);
            }
            if (minor ==3) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 90, 150);
            }
            if (minor ==4) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 170, 400);
            }
        }
        else if (major == 2)
        {
            if (minor ==1) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now,450, 400);
            }
            if (minor ==2) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 450, 650);
            }
            if (minor ==3) {
                mv.removeMarker(img_now);
                mv.addMarker(img_now, 280, 790);
            }
        }
    }
    private void init() {
        img_now = new ImageView(getContext());
        img_now.setBackgroundResource(R.drawable.list3_now_onmap);
        img_C1 = new ImageView(getContext());
        img_C1.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C2 = new ImageView(getContext());
        img_C2.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C3 = new ImageView(getContext());
        img_C3.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C4 = new ImageView(getContext());
        img_C4.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C5 = new ImageView(getContext());
        img_C5.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C6 = new ImageView(getContext());
        img_C6.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C7 = new ImageView(getContext());
        img_C7.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C8 = new ImageView(getContext());
        img_C8.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C9 = new ImageView(getContext());
        img_C9.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C10 = new ImageView(getContext());
        img_C10.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C11 = new ImageView(getContext());
        img_C11.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C12 = new ImageView(getContext());
        img_C12.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C13 = new ImageView(getContext());
        img_C13.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C14 = new ImageView(getContext());
        img_C14.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C15 = new ImageView(getContext());
        img_C15.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C16 = new ImageView(getContext());
        img_C16.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C17 = new ImageView(getContext());
        img_C17.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C18 = new ImageView(getContext());
        img_C18.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C19 = new ImageView(getContext());
        img_C19.setBackgroundResource(R.drawable.list3_food_onmap);
        img_C20 = new ImageView(getContext());
        img_C20.setBackgroundResource(R.drawable.list3_food_onmap);
    }
}
