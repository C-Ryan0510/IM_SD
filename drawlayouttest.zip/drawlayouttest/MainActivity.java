package cn.picksomething.drawlayouttest;


import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.NavigationView;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.THLight.USBeacon.App.Lib.BatteryPowerData;
import com.THLight.USBeacon.App.Lib.USBeaconConnection;
import com.THLight.USBeacon.App.Lib.USBeaconList;
import com.THLight.USBeacon.App.Lib.iBeaconData;
import com.THLight.USBeacon.App.Lib.iBeaconScanManager;
import com.THLight.Util.THLLog;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import cn.picksomething.drawlayouttest.Databases.DatabaseHelper;
import cn.picksomething.drawlayouttest.ScanedBeacon.ScanediBeacon;
import cn.picksomething.drawlayouttest.ScanedBeacon.THLApp;
import cn.picksomething.drawlayouttest.ScanedBeacon.THLConfig;
import cn.picksomething.drawlayouttest.Toolbar.FragmentAboutus;
import cn.picksomething.drawlayouttest.Toolbar.FragmentCookbook;
import cn.picksomething.drawlayouttest.Toolbar.FragmentFavorite;
import cn.picksomething.drawlayouttest.Toolbar.FragmentHistory;
import cn.picksomething.drawlayouttest.Toolbar.FragmentList;
import cn.picksomething.drawlayouttest.Toolbar.FragmentMain;
import cn.picksomething.drawlayouttest.Toolbar.FragmentMember;


public class MainActivity extends AppCompatActivity implements iBeaconScanManager.OniBeaconScan{

    private Toolbar mToolbar;//側邊欄
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private NavigationView mNavigationView;

    private ViewPager adViewPager;
    private LinearLayout pagerLayout;
    private List<View> pageViews;
    private ImageView[] imageViews;
    private ImageView imageView;
    private AdPageAdapter adapter;
    private AtomicInteger atomicInteger = new AtomicInteger(0);
    private boolean isContinue = true;
//
    private ViewPager viewPager;
    private cn.picksomething.drawlayouttest.Databases.TestDatabaseHelper dbhelp;
    private cn.picksomething.drawlayouttest.Databases.DatabaseHelper myDB;
    static String STORE_PATH	= Environment.getExternalStorageDirectory().toString()+ "/USBeaconSample/";

    final int REQ_ENABLE_BT		= 2000;
    final int REQ_ENABLE_WIFI	= 2001;

    final int MSG_SCAN_IBEACON			= 1000;
    final int MSG_UPDATE_BEACON_LIST	= 1001;
    final int MSG_START_SCAN_BEACON		= 2000;
    final int MSG_STOP_SCAN_BEACON		= 2001;
    final int MSG_SERVER_RESPONSE		= 3000;

    final int TIME_BEACON_TIMEOUT		= 30000;

    THLApp App		= null;
    THLConfig Config= null;

    BluetoothAdapter mBLEAdapter= BluetoothAdapter.getDefaultAdapter();

    /** scaner for scanning iBeacon around. */
    iBeaconScanManager miScaner	= null;

    /** USBeacon server. */
    USBeaconConnection mBServer	= new USBeaconConnection();

    USBeaconList mUSBList		= null;

    List<ScanediBeacon> miBeacons	= new ArrayList<ScanediBeacon>();

    android.support.v4.app.Fragment fragment;


    int major = 0, minor = 0;

    Handler mHandler= new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_SCAN_IBEACON: {
                    int timeForScaning = msg.arg1;
                    int nextTimeStartScan = msg.arg2;

                    miScaner.startScaniBeacon(timeForScaning);
                    this.sendMessageDelayed(Message.obtain(msg), nextTimeStartScan);
                }
                break;

                case MSG_UPDATE_BEACON_LIST: {
                    verifyiBeacons();
                    initmBeaconList();
                    mHandler.sendEmptyMessageDelayed(MSG_UPDATE_BEACON_LIST, 500);
                }
                break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        myDB = new DatabaseHelper(this);
        initViewPager();
        findViews();
        setupToolbar();
        setupDrawerContent(mNavigationView);


        mToggle = setupDrawerToggle();
        // Tie DrawerLayout events to the ActionBarToggle
        mDrawerLayout.addDrawerListener(mToggle);

        View headerView = mNavigationView.getHeaderView(0);
        ImageView memberImg = (ImageView) headerView.findViewById(R.id.Member_img);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.bighead);
        memberImg.setImageBitmap(getRoundedCornerBitmap(bitmap, 10000.0f));
        memberImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                android.support.v4.app.Fragment fragment = new FragmentMember();
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.popBackStack();
                fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();
                mDrawerLayout.closeDrawers();
            }
        });

        showDefaultFragment();
/** ================================================ */
        App		= THLApp.getApp();
        Config	= THLApp.Config;

        /** create instance of iBeaconScanManager. */
        miScaner		= new iBeaconScanManager(this, this);
        mUSBList = new USBeaconList();


        if(!mBLEAdapter.isEnabled())
        {
            Intent intent= new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, REQ_ENABLE_BT);
        }
        else
        {
            Message msg= Message.obtain(mHandler, MSG_SCAN_IBEACON, 1000, 1100);
            msg.sendToTarget();
        }
        /** create store folder. */
        File file= new File(STORE_PATH);
        if(!file.exists())
        {
            if(!file.mkdirs())
            {
                Toast.makeText(this, "Create folder("+ STORE_PATH + ") failed.", Toast.LENGTH_SHORT).show();
            }
        }

        /** check network is available or not. */
//        ConnectivityManager cm	= (ConnectivityManager)getSystemService(MainActivity.CONNECTIVITY_SERVICE);
//        if(null != cm)
//        {
//            NetworkInfo ni = cm.getActiveNetworkInfo();
//            if(null == ni || (!ni.isConnected()))
//            {
//                dlgNetworkNotAvailable();
//            }
//            else
//            {
//                THLLog.d("debug", "NI not null");
//
//                NetworkInfo niMobile= cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
//                if(null != niMobile)
//                {
//                    boolean is3g	= niMobile.isConnectedOrConnecting();
//
//                    if(is3g)
//                    {
//                        dlgNetwork3G();
//                    }
//                    else
//                    {
//                        USBeaconServerInfo info= new USBeaconServerInfo();
//
//                        info.serverUrl		= HTTP_API;
//                        info.queryUuid		= QUERY_UUID;
//                        info.downloadPath	= STORE_PATH;
//
//                        mBServer.setServerInfo(info,MainActivity.this);
//                        mBServer.checkForUpdates();
//                    }
//                }
//            }
//        }
//        else
//        {
//            THLLog.d("debug", "CM null");
//        }

        mHandler.sendEmptyMessageDelayed(MSG_UPDATE_BEACON_LIST, 500);

        /** ================================================ */
    }


    /** ========================================================== */
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        THLLog.d("DEBUG", "onActivityResult()");

        switch(requestCode)
        {
            case REQ_ENABLE_BT:
                if(RESULT_OK == resultCode)
                {
                }
                break;

            case REQ_ENABLE_WIFI:
                if(RESULT_OK == resultCode)
                {
                }
                break;
        }
    }
    public void verifyiBeacons() {
        {
            long currTime = System.currentTimeMillis();

            int len = miBeacons.size();
            ScanediBeacon beacon = null;

            for (int i = len - 1; 0 <= i; i--) {
                beacon = miBeacons.get(i);

                if (null != beacon && TIME_BEACON_TIMEOUT < (currTime - beacon.lastUpdate)) {
                    miBeacons.remove(i);
                }
            }
        }
    }
    public void initmBeaconList()
    {
        USBeaconList BList= mBServer.getUSBeaconList();


        if (!miBeacons.isEmpty() ) {
            for (int i = 0; i < miBeacons.size(); i++) {
                if (calculateAccuracy(miBeacons.get(i).rssi, miBeacons.get(i).oneMeterRssi) < 1.5) {
//                    Toast.makeText(MainActivity.this, "" + miBeacons.get(i).major + "," + miBeacons.get(i).minor , Toast.LENGTH_SHORT).show();
                    major = miBeacons.get(i).major;
                    minor = miBeacons.get(i).minor;
                }
            }
        }
    }
    private double calculateAccuracy(double rssi, double txPower) {

        if(rssi == 0) {
            return -1.0D;
        } else {
            double ratio = (double)((float)rssi) / txPower;
            double accuracy = Math.pow(10.0D, ((double)rssi - txPower) / -32.5D);
            return accuracy;
        }
    }
    public void addOrUpdateiBeacon(iBeaconData iBeacon)
    {
        long currTime= System.currentTimeMillis();

        ScanediBeacon beacon= null;

        for(ScanediBeacon b : miBeacons)
        {
            if(b.equals(iBeacon, false))
            {
                beacon= b;
                break;
            }
        }

        if(null == beacon)
        {
            beacon= ScanediBeacon.copyOf(iBeacon);
            miBeacons.add(beacon);
        }
        else
        {
            beacon.rssi= iBeacon.rssi;
        }

        beacon.lastUpdate= currTime;
    }
    @Override
    public void onScaned(iBeaconData iBeacon)
    {
        addOrUpdateiBeacon(iBeacon);
    }

    @Override
    public void onBatteryPowerScaned(BatteryPowerData batteryPowerData) {
        // TODO Auto-generated method stub
        Log.d("debug", batteryPowerData.batteryPower+"");
        for(int i = 0 ; i < miBeacons.size() ; i++)
        {
            if(miBeacons.get(i).macAddress.equals(batteryPowerData.macAddress))
            {
                ScanediBeacon ib = miBeacons.get(i);
                ib.batteryPower = batteryPowerData.batteryPower;
                miBeacons.set(i, ib);
            }
        }
    }
    /** ========================================================== */
    private void findViews() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mNavigationView = (NavigationView) findViewById(R.id.nav_view);
    }//mDrawerLayout , mNavigationView 初始化

    private void setupToolbar() {
        // Set a Toolbar to replace the ActionBar.
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
    }//mToolbar初始化

    private void setupDrawerContent(NavigationView navigationView) {

        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {

                        selectDrawerItem(menuItem);//側邊欄item動作
                        menuItem.setChecked(true);
                        mDrawerLayout.closeDrawers();
                        return true;
                    }
                });
    }

    private ActionBarDrawerToggle setupDrawerToggle() {
        return new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar,
                R.string.drawer_open, R.string.drawer_close);
    }

    Runnable r1 = new Runnable() {
        @Override
        public void run() {
            (fragment.getArguments()).putInt("MAJOR_KEY", major);
            (fragment.getArguments()).putInt("MINOR_KEY", minor);
            hd.postDelayed(this,1000);
        }
    };//這個傳到購物清單

    private Bundle bundle = new Bundle();

    public void selectDrawerItem(MenuItem menuItem) {
        // Create a new fragment and specify the fragment to show based on nav item clicked
        fragment = new FragmentList();
        switch (menuItem.getItemId()) {

            case R.id.nav_second_fragment:

                    fragment = new FragmentFavorite();

                    bundle.putInt("MAJOR_KEY", major);
                    bundle.putInt("MINOR_KEY", minor);
                if (fragment.getArguments() == null)
                    fragment.setArguments(bundle);

                break;
            case R.id.nav_third_fragment:

                    fragment = new FragmentHistory();

                    bundle.putInt("MAJOR_KEY", major);
                    bundle.putInt("MINOR_KEY", minor);
                if (fragment.getArguments() == null)
                    fragment.setArguments(bundle);

                break;
            case R.id.nav_fourth_fragment:

                    fragment = new FragmentList();
                    bundle.putInt("MAJOR_KEY", major);
                    bundle.putInt("MINOR_KEY", minor);
                    fragment.setArguments(bundle);
                if (fragment.getArguments() == null)
                    hd.postDelayed(r1, 1000);

                break;
            case R.id.nav_sub_third_fragment:

                    fragment = new FragmentAboutus();

                    bundle.putInt("MAJOR_KEY", major);
                    bundle.putInt("MINOR_KEY", minor);
                if (fragment.getArguments() == null)
                    fragment.setArguments(bundle);


                break;
            case R.id.nav_sub_fourth_fragment:

                    fragment = new FragmentCookbook();

                    bundle.putInt("MAJOR_KEY", major);
                    bundle.putInt("MINOR_KEY", minor);
                if (fragment.getArguments() == null)
                    fragment.setArguments(bundle);

                break;
            default:

                fragment = new FragmentCookbook();

                    bundle.putInt("MAJOR_KEY", major);
                    bundle.putInt("MINOR_KEY", minor);
                    fragment.setArguments(bundle);

                break;
        }
        // Insert the fragment by replacing any existing fragment
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.popBackStack();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();
        // Highlight the selected item has been done by NavigationView
        menuItem.setChecked(true);
        // Set action bar title

        setTitle(menuItem.getTitle());
        // Close the navigation drawer
        mDrawerLayout.closeDrawers();
    }

    private void showDefaultFragment() {
        Fragment fragment = new FragmentMain();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.popBackStack();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();

    }


    @Override
    public void onBackPressed() {
        if (isNavDrawerOpen()) {
            closeNavDrawer();
        } else {
            super.onBackPressed();
        }
    }

    protected boolean isNavDrawerOpen() {
        return mDrawerLayout != null && mDrawerLayout.isDrawerOpen(GravityCompat.START);
    }

    protected void closeNavDrawer() {
        if (mDrawerLayout != null) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    // `onPostCreate` called when activity start-up is complete after `onStart()`
    // NOTE! Make sure to override the method with only a single `Bundle` argument
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggles
        mToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    DialogFragment mapButton = new MapButton();
    Handler hd = new Handler();

    Runnable r = new Runnable() {
        @Override
        public void run() {

//                Bundle bundle = new Bundle();
//                bundle.putInt("MAJOR_KEY", major);
//                bundle.putInt("MINOR_KEY", minor);

            (mapButton.getArguments()).putInt("MAJOR_KEY", major);
            (mapButton.getArguments()).putInt("MINOR_KEY", minor);
            hd.postDelayed(this,1000);
        }
    };//這個傳到浮窗地圖

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // The action bar home/up action should open or close the drawer.
        // ActionBarDrawerToggle will take care of this.

        // Handle action buttons
        switch (item.getItemId()) {
            case R.id.action_map:
                // create intent to perform web search for this planet
                Bundle bundle = new Bundle();
                bundle.putInt("MAJOR_KEY", major);
                bundle.putInt("MINOR_KEY", minor);
                mapButton.setArguments(bundle);

                hd.postDelayed(r,1000);

                mapButton.show(getSupportFragmentManager(),"dialog");

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }




        private void initViewPager() {

        //从布局文件中获取ViewPager父容器
        pagerLayout = (LinearLayout) findViewById(R.id.view_pager_content);
        //创建ViewPager
        adViewPager = new ViewPager(this);

        //获取屏幕像素相关信息
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        //根据屏幕信息设置ViewPager广告容器的宽高
        adViewPager.setLayoutParams(new ViewGroup.LayoutParams(dm.widthPixels* 5/5, dm.heightPixels * 5/ 10));

        //将ViewPager容器设置到布局文件父容器中
        pagerLayout.addView(adViewPager);

        initPageAdapter();
        initCirclePoint();

        adViewPager.setAdapter(adapter);
        adViewPager.setOnPageChangeListener(new AdPageChangeListener());

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    if (isContinue) {
                        viewHandler.sendEmptyMessage(atomicInteger.get());
                        atomicOption();
                    }
                }
            }
        }).start();
    }


    private void atomicOption() {
        atomicInteger.incrementAndGet();
        if (atomicInteger.get() > imageViews.length - 1) {
            atomicInteger.getAndAdd(-5);
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {

        }
    }

    /*
     * 每隔固定时间切换广告栏图片
     */
    private final Handler viewHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            adViewPager.setCurrentItem(msg.what);
            super.handleMessage(msg);
        }

    };

    public static Bitmap readBitMap(Context context, int resId){
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inPreferredConfig = Bitmap.Config.RGB_565;
        opt.inPurgeable = true;
        opt.inInputShareable = true;
        opt.inSampleSize = 1;
        //獲取資源圖片
        InputStream is = context.getResources().openRawResource(resId);
        return BitmapFactory.decodeStream(is,null,opt);
    }

    private void initPageAdapter() {
        pageViews = new ArrayList<View>();
//        Bitmap bm1 = readBitMap(this,R.drawable.ad1);
        ImageView img1 = new ImageView(this);
        img1.setImageResource(R.drawable.ad1);
        pageViews.add(img1);

        Bitmap bm2 = readBitMap(this,R.drawable.ad2);
        ImageView img2 = new ImageView(this);
        img2.setImageBitmap(bm2);
        pageViews.add(img2);

        Bitmap bm3 = readBitMap(this,R.drawable.ad3);
        ImageView img3 = new ImageView(this);
        img3.setImageBitmap(bm3);
        pageViews.add(img3);

        Bitmap bm4 = readBitMap(this,R.drawable.ad);
        ImageView img4 = new ImageView(this);
        img4.setImageBitmap(bm4);
        pageViews.add(img4);
        //要新的廣告 用相同格式下去加即可

        adapter = new AdPageAdapter(pageViews);
    }

    private void initCirclePoint(){
        ViewGroup group = (ViewGroup) findViewById(R.id.viewGroup);
        imageViews = new ImageView[pageViews.size()];
        //小圓點
        for (int i = 0; i < pageViews.size(); i++) {
            //创建一个ImageView
            imageView = new ImageView(this);
            imageView.setLayoutParams(new ViewGroup.LayoutParams(10,10));
            imageViews[i] = imageView;

            //初始值, 默认第0个选中
            if (i == 0) {
                imageViews[i]
                        .setBackgroundResource(R.drawable.point_focused);
            } else {
                imageViews[i]
                        .setBackgroundResource(R.drawable.point_unfocused);
            }
            //将小圆点放入到布局中
            group.addView(imageViews[i]);
        }
    }

    /**
     *	ViewPager 页面改变监听器
     */
    private final class AdPageChangeListener implements ViewPager.OnPageChangeListener {

        /**
         * 页面滚动状态发生改变的时候触发
         */
        @Override
        public void onPageScrollStateChanged(int arg0) {
        }

        /**
         * 页面滚动的时候触发
         */
        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        /**
         * 页面选中的时候触发
         */
        @Override
        public void onPageSelected(int arg0) {
            //获取当前显示的页面是哪个页面
            atomicInteger.getAndSet(arg0);
            //重新设置原点布局集合
            for (int i = 0; i < imageViews.length; i++) {
                imageViews[arg0]
                        .setBackgroundResource(R.drawable.point_focused);
                if (arg0 != i) {
                    imageViews[i]
                            .setBackgroundResource(R.drawable.point_unfocused);
                }
            }
        }
    }


    private final class AdPageAdapter extends PagerAdapter {
        private List<View> views = null;

        /**
         * 初始化数据源, 即View数组
         */
        public AdPageAdapter(List<View> views) {
            this.views = views;
        }

        /**
         * 从ViewPager中删除集合中对应索引的View对象
         */
        @Override
        public void destroyItem(View container, int position, Object object) {
            ((ViewPager) container).removeView(views.get(position));
        }

        /**
         * 获取ViewPager的个数
         */
        @Override
        public int getCount() {
            return views.size();
        }

        /**
         * 从View集合中获取对应索引的元素, 并添加到ViewPager中
         */
        @Override
        public Object instantiateItem(View container, int position) {
            ((ViewPager) container).addView(views.get(position), 0);
            return views.get(position);
        }

        /**
         * 是否将显示的ViewPager页面与instantiateItem返回的对象进行关联
         * 这个方法是必须实现的
         */
        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }
    }
    //會員圖片圓形化
    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap,float roundPx)
    {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }
protected  void onDestroy()
{
    super.onDestroy();
    System.exit(0);
    android.os.Process.killProcess(android.os.Process.myPid());

}


}

