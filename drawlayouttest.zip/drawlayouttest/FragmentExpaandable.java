package cn.picksomething.drawlayouttest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by tt791_000 on 2016/8/2.
 */
public class FragmentExpaandable  extends CustomExpandSelectedAdapterFavorite  {
    List<String> group = new ArrayList<>();
    List<List<String>> child = new ArrayList<>();
    Context context;

    public FragmentExpaandable(Context context, List<String> group, List<List<String>> child) {
        this.context = context;
        this.group = group;
        this.child = child;
    }

    @Override
    public int getGroupCount() {
        return group.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return child.get(groupPosition).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return group.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return child.get(groupPosition).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.fragment_layout_parent, parent, false);
            holder = new GroupHolder();
            holder.tv = (TextView) convertView.findViewById(R.id.heading_item);
            convertView.setTag(holder);
        } else {
            holder = (GroupHolder) convertView.getTag();
        }
        holder.tv.setText(group.get(groupPosition));
        return convertView;
    }

    class GroupHolder {
        TextView tv;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.fragment_layout_child, parent, false);
            holder = new ChildHolder();
            holder.tv = (TextView) convertView.findViewById(R.id.child_item);
            convertView.setTag(holder);
        } else {
            holder = (ChildHolder) convertView.getTag();
        }
        holder.tv.setText(child.get(groupPosition).get(childPosition));
        return convertView;
    }

    class ChildHolder {
        TextView tv;
    }

    public HashMap<String, ArrayList<String>> getCheckedItemName()
    {
        HashMap<String, ArrayList<String>> map = new HashMap<>();
        ArrayList<Boolean> ifchecked = getCheckeditem();
        int checkedPosition = 0;
        int temp = -1;

        for (int i = 0; i < group.size(); i++)
        {
            ArrayList<String> names = new ArrayList<>();
            for (int j = 0; j < child.get(i).size(); j++)
            {
                if (ifchecked.get(checkedPosition))
                {
                    names.add(child.get(i).get(j));

                    if(temp != i)
                    {
                        map.put(group.get(i), names);
                        temp = i;
                    }

                }
                checkedPosition++;
            }

        }

//        names.add(""+child.size());
//        names.add(""+group.size());

        return map;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

}
