import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class createGroup extends StatefulWidget {
  const createGroup({Key? key}) : super(key: key);

  @override
  State<createGroup> createState() => _createGroupState();
}

class _createGroupState extends State<createGroup> {
  TextEditingController _groupName = TextEditingController();
  final userID = FirebaseAuth.instance.currentUser!.email.toString();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange.shade300,
      body: Stack(
        children: [
          Center(
            child: Padding(
              padding: EdgeInsets.all(15),
              child: Container(width: double.infinity, height: 200, //color: Colors.grey,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  boxShadow: [BoxShadow(
                      color: Colors.black38,
                      offset: Offset(6.0, 6.0), //陰影y軸偏移量
                      blurRadius: 0, //陰影模糊程度
                      spreadRadius: 0 //陰影擴散程度
                  )],
                  borderRadius: BorderRadius.circular(18),
                  color: Colors.white, //
                ),
                child: Column(
                  children: [
                    // Padding(padding: EdgeInsets.all(20),
                    //   child: Row(
                    //     children: [BackButton()],
                    //   ),
                    // ),
                    Spacer(),
                    Padding(padding: EdgeInsets.all(20),
                      child: Container(
                        child: Column(
                          children: [
                            TextFormField(
                              controller: _groupName,
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.group),
                                hintText: 'Name of The Group',
                              ),
                            ),
                            SizedBox(height: 15,),
                            RaisedButton(
                              color: Colors.orangeAccent.shade400,
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 50,),
                                child: Text('Create Group',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                              onPressed: () {
                                CreateNewGroup(_groupName.text.trim(), userID);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 40),
            child: IconButton( //To put it on top of ListView so it can be onPressed
              alignment: Alignment.bottomCenter,
              icon: Icon(
                Icons.arrow_back_ios_new, color: Colors.black, size: 40,),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
  Future CreateNewGroup(String groupName, String userId) async {
    List<String> members = [];//List();
    try{
      members.add(userId);
      DocumentReference _DR = await FirebaseFirestore.instance.collection('Groups_List').add({
        'name' : groupName,
        'creator' : userId,
        'members' : members,
        'groupCreated' : Timestamp.now(),
      });

      await FirebaseFirestore.instance.collection('Users_Profile').doc(FirebaseAuth.instance.currentUser!.email.toString())
      .update({
        'group_id' : _DR.id,
      });

      await Future.delayed(Duration(seconds: 1));
      showDialog(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: Text('群組建立成功',),
          // content: Text('test'), // Image....
          actions: [
            FlatButton(child: Text('確定'),
              onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
            ),
          ],
          elevation: 24,
        ),
        barrierDismissible: false, // tap outside of it to dismiss
      );

    } catch (e) {
      print(e);
    }
  }
}
