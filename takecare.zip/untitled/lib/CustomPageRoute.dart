import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomPageRoute extends PageRouteBuilder {
  final Widget child;
  final AxisDirection direction;

  CustomPageRoute({
    required this.child,
    this.direction = AxisDirection.right, // default "right"
  }) : super(
      transitionDuration: Duration(milliseconds: 300), // 0.5 second
      reverseTransitionDuration: Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) => child
  );
  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
                          Animation<double> secondaryAnimation, Widget child) =>
    // ScaleTransition( // 放大轉場
    //   scale: animation,
    //   child: child,
    // ); 
    SlideTransition( // 滑動轉場
      position: Tween<Offset>( // animate<Offset>
        begin: getBeginOffset(),
        // begin: Offset(-1, 0), // 從左
        end: Offset.zero, // 到(右)
      ).animate(animation),
      child: child,
    );

  Offset getBeginOffset() {
    switch (direction) { // 往上|下|左|右
      case AxisDirection.up:
        return Offset(0, 1); // from bottom
      case AxisDirection.down:
        return Offset(0, -1); // from top
      case AxisDirection.left:
        return Offset(1, 0); // from right
      case AxisDirection.right:
        return Offset(-1, 0); // from left
    }
  }
}