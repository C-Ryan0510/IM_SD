import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Sleep extends StatefulWidget {
  const Sleep ({Key? key}) : super(key: key);

  @override
  State<Sleep> createState() => _SleepState();
}

// DocumentSnapshot snapshot; //Define snapshot

class _SleepState extends State<Sleep> {

  final ThisTypeCollection = FirebaseFirestore.instance
      .collection('Health').doc('Record_types')
      .collection('SleepTypes');

  // DropBox Default set text
  TextEditingController start_sleep = TextEditingController();
  TextEditingController end_sleep = TextEditingController();

  // DocumentSnapshot snapshot; //Define snapshot
  final decro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.circular(50),);
  final Errordecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.circular(50),);
  final UPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final ErrorUPdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight:Radius.circular(30)),);
  final DWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Color.fromRGBO(48, 92, 84, 100), width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);
  final ErrorDWdecro = OutlineInputBorder(borderSide: const BorderSide(color: Colors.redAccent, width: 2.0), borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight:Radius.circular(30)),);

  String DateNow = DateFormat('yyyy-MM-dd – kk:mm').format(DateTime.now());

  String YEAR = DateTime.now().year.toString();
  String MONTH = DateTime.now().month.toString();
  String DAY = DateTime.now().day.toString();

  var _curFType;

  // read Firestore Database
  Future createRecord({required String Time,required String Rest,required String Year,required String Month,required String Day,}) async {
    final doc = FirebaseFirestore.instance.collection('Health')
        .doc(FirebaseAuth.instance.currentUser!.email.toString())
        .collection('SleepRecord').doc(Year).collection(Month)
        .doc(Day);

    final data = SleepData(
      created: Time,
      RestTime: Rest,
      year: Year,
      month: Month,
      day: Day,
    );

    final json = data.toJson();
    await doc.set(json);
  }

  // read DOCs and make it to List
  Stream<List<SleepData>> readSleep() =>
      ThisTypeCollection
      .snapshots()
      .map((snapshot) => snapshot
      .docs.map((doc) =>
      SleepData.fromJson(doc.data())).toList()
  );

  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.transparent,
      body: StreamBuilder<List> (
        stream: readSleep(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong! ${snapshot}');
          } else if (snapshot.hasData) {
            final detail = snapshot.data;

            return detail == null ?
            Center(child: Text('NoData'),) :
            SizedBox(
              height: 500, // ????
              child: Container(//border
                decoration: BoxDecoration(
                  border: Border.all(width:2.5,color: Color.fromRGBO(48, 92, 84, 100),),
                  borderRadius: BorderRadius.only(topRight: Radius.circular(40),topLeft: Radius.circular(40),),
                ),
                child: Stack(
                  children: [
                    //title for this record widget
                    Positioned(child: Text('睡眠紀錄',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),top: 10,left: 18,),
                    Positioned(child: Text('紀錄時間',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 42,left: 24,),
                    Positioned(child: Text('休息時長',style: TextStyle(color: Color.fromRGBO(48, 92, 84, 100),fontSize: 16),),top: 135,left: 24,),
                    Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        // mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Expanded(flex: 7,child: SizedBox(),),
                          Expanded(
                            flex: 10,
                            child: TextFormField(enabled: false,
                            initialValue: DateNow,
                            decoration: InputDecoration(
                              // enabledBorder: decro,
                              // focusedBorder: decro,
                              disabledBorder: decro, // enabled FALSE
                              prefixIcon  : Padding(
                                padding: EdgeInsets.symmetric(horizontal: 10),
                                child: IconButton(
                                  icon: Icon(Icons.date_range_rounded,color: Colors.black,),
                                  color: Colors.black,
                                  onPressed: null,
                                ),
                              ),
                            ),
                          ),
                          ),
                          Expanded(flex: 1, child: SizedBox(),),
                          TextFormField(
                            controller: start_sleep,
                            decoration: InputDecoration(
                              enabledBorder: decro, //UPdecro,
                              focusedBorder: decro, //UPdecro,
                              disabledBorder: ErrorUPdecro,
                              prefixIcon  : Padding(
                                padding: EdgeInsets.symmetric(horizontal: 10),
                                child: IconButton(
                                  icon: Icon(Icons.bed_outlined,color: Colors.black,),
                                  color: Colors.black,
                                  onPressed: null,
                                ),
                              ),
                            ),
                            textInputAction: TextInputAction.next,
                          ),
                          // TextFormField(
                          //   controller: end_sleep,
                          //   decoration: InputDecoration(
                          //     enabledBorder: DWdecro,
                          //     focusedBorder: DWdecro,
                          //     disabledBorder: ErrorDWdecro,
                          //     prefixIcon  : Padding(
                          //       padding: EdgeInsets.symmetric(horizontal: 10),
                          //       child: IconButton(
                          //         icon: Icon(Icons.accessibility,color: Colors.black,),
                          //         color: Colors.black,
                          //         onPressed: null,
                          //       ),
                          //     ),
                          //   ),
                          //   textInputAction: TextInputAction.done,
                          // ),
                          Expanded(flex: 20,child: SizedBox(),),
                          Expanded(
                            flex: 6,
                            child: Container(width: double.infinity,
                              child: ElevatedButton(
                                child: const Text('儲存紀錄'),
                                onPressed: () => { // null
                                  createRecord(
                                    Time: DateNow,
                                    Year: YEAR,
                                    Month: MONTH,
                                    Day: DAY,
                                    Rest: start_sleep.text.trim(),
                                  ),
                                  Navigator.pop(context),
                                },
                              ),
                            ),
                          ),
                          SizedBox(height: 10,),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
            // : buildF(detail);
          } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }
}

class SleepData {
  String RestTime;
  String year;
  String month;
  String day;
  String created; // DateTime

  SleepData({
    required this.created,
    required this.RestTime,
    required this.year,
    required this.month,
    required this.day,
  });

  Map<String, dynamic> toJson() => {
    'year': year,
    'month': month,
    'day': day,
    'RestTime': RestTime,
    'created': created,
  };

  static SleepData fromJson(Map<String, dynamic> json) => SleepData(
    created: json['created'],
    // (json['date'] as Timestamp).toDate(),
    RestTime: json['RestTime'],
    year: json['year'],
    month: json['month'],
    day: json['day'],
  );
}
