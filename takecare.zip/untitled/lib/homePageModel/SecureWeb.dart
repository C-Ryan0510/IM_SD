import 'package:flutter/material.dart';
import 'package:untitled/Pages/splash.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import 'package:untitled/main.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main(){
  runApp(MaterialApp(
    home: Web(),
  ));
}

class Web extends StatefulWidget{
  const Web({Key? key}) : super(key: key);
  @override
  _WebState createState() => _WebState();
}

class _WebState extends State<Web>{
  @override
  Widget build(BuildContext context){
    return Padding(
        padding:const EdgeInsets.only(top:65),
        child: SafeArea(
          child: WebView(
            initialUrl:"  http://192.168.0.218:63708/",
            javascriptMode: JavascriptMode.unrestricted,
          ),
        )
    );
  }
}